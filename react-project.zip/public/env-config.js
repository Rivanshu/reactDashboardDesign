window._env_ = {
    DEP_TYPE: "prod",
    MULTILOCALE_ENABLE: false,
    ENABLE_CAPTCHA: false,
    CAPTCHA_KEY: "",
    I18N_API: "",

    API_GATEWAY_BASE_URL: "https://ess_api.espire.com/",
    USER_APP_API: "http://172.16.1.54:8443/users/api/v1.0/",
    ADMIN_APP_API: "https://172.187.226.194:9999/admin/api/v1.0/",
    PIPELINE_APP_API: "https://172.187.226.194:7443/pipeline/api/v1.0/",
    LOCATION_APP_API: "https://172.187.226.194:8443/location/api/v1.0/",
   
}