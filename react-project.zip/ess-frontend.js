const express = require("express");
const path = require("path");
const config = require('dotenv').config();
const basePath = '';
const app = express();
process.env['NODE_ENV'] = 'development';
console.log("Environment", process.env['NODE_ENV']);
app.use(basePath + "/", express.static(path.resolve(__dirname + "/build")));
app.get("*", (request, response) => {
    response.sendFile(path.resolve(__dirname + "/build/index.html"));
});
app.listen(80);