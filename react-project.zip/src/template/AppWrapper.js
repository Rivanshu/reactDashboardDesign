import React, { Fragment, useEffect, useState } from 'react';
import { Navigate, useLocation } from 'react-router-dom';
import { useSelector } from 'react-redux';
import { selectUser } from '../services/store/userSlice';
import { useCookies } from 'react-cookie';
import Menu from './AppMenu';
import { menuItems, routeChangeHandler } from '../services/common/states';
import AppSession from './AppSession';
import Application from './Application';
import Login from '../pages/user/login';
import properties from '../config/environmentProperties';
// SSO
import { useIsAuthenticated } from '@azure/msal-react';


const AppWrapper = () => {
    const user = useSelector(selectUser)
    const isAuthenticated = useIsAuthenticated();
    const [cookies, setCookie] = useCookies(['user']);
    const location = useLocation();
    const path = location.pathname;

    useEffect(() => {
        window.scrollTo(0, 0)
        menuItems.next(Menu);
    }, [location]);

    let session = useSelector(selectUser);
    // if (properties.currentEnvironment.enableSSO) {
    //     session = session && cookies && isAuthenticated;
    // } else {
    //     session = session && cookies;
    // }

    routeChangeHandler(location.pathname);

    switch (location.pathname) {
        case "/error":
        case "/feedback":
        case "/nopermission":
        case "/notfound":
            return <Application />; break;
        case "/login":
            return session ? <Application /> : <Login path="/login" />; break;
        case "/":
            return session ? <Application /> : <Navigate to="/login" />; break;
        default:
            return session ? <Application /> : <Navigate to="/login" />; break;
    }

}

export default AppWrapper;
