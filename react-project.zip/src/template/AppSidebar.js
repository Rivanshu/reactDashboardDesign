// SidebarMenu.js
import React from 'react';
import { Sidebar } from 'primereact/sidebar';
import { Menu } from 'primereact/menu';
import { Link } from 'react-router-dom';

const SidebarMenu = () => {
  const menuItems = [
    {
      label: 'Dashboard',
      icon: 'pi pi-home',
      to: '/dashboard',
    },
    {
      label: 'Other Page',
      icon: 'pi pi-info-circle',
      to: '/other',
    },
    // Add more menu items as needed
  ];

  return (
    <Sidebar visible={true}>
      <Menu model={menuItems} />
    </Sidebar>
  );
};

export default SidebarMenu;
