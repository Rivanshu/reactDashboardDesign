import React, { Fragment } from 'react';
import { Route, Router, Routes } from 'react-router-dom';

import { PageNotFound, NoPermission, UnAuthorized, Profile, ChangePassword, UserDashboard, Role, Permission, RolePermission, UserManager } from '../pages/extentions';
import { Home, Dashboard, Pipeline, Help, CreatePipeline, UserMaintenance, PipelineDashboard } from '../pages'
import { getFilteredMenus } from '../common/helpers/permissions';
import {
    USER_MAINTENANCE_MENU_VIEW
} from '../config/permissions';
import { APPLICATION_SUPER_ADMIN, APPLICATION_ADMIN, APPLICATION_EMPLOYEE } from '../config/roles';
import AddNewOrganization from '../pages/addOrganization/addOrganization';
const subRouteArray = [
    // { path: 'new', component: <EditPsaps module='new' />, parent: 'psaps' },
]

const routeArray = [
    { id: 'root', path: '/', component: <Home />, items: [] },
    // { id: 'home', path: '/home', component: <Home />, permissions: null },
    { id: 'dashboard', path: '/dashboard', component: <Dashboard /> },
    { id: 'pipeline', path: '/pipeline', component: <Pipeline /> },
    { id: 'create-pipeline', path: '/create-pipeline', component: <CreatePipeline /> },
    { id: 'usermaintenancee', path: '/usermaintenance', component: <UserMaintenance />, roles:[APPLICATION_EMPLOYEE] },
    { id: 'help', path: '/help', component: <Help /> },
    { id: 'pipelinedashboard', path: '/pipelinedashboard', component: <PipelineDashboard /> },
    // { id: 'addnew', path: '/addnew', component: <AddNew /> },
    { id: 'add-organization', path: '/addorg', component: <AddNewOrganization /> },
    { id: 'profile', path: '/profile', component: <Profile /> },
    { id: 'change-password', path: '/change-password', component: <ChangePassword /> },
    { id: 'user-maintenance', path: '/user-maintenance', component: <UserDashboard />, permissions: [USER_MAINTENANCE_MENU_VIEW] },
    { id: 'user-maintenance-user', path: '/user-maintenance/user', component: <userMaintenance />, permissions: [USER_MAINTENANCE_MENU_VIEW] },
    { id: 'user-maintenance-role', path: '/user-maintenance/role', component: <Role />, permissions: [USER_MAINTENANCE_MENU_VIEW] },
    { id: 'user-maintenance-permission', path: '/user-maintenance/permission', component: <Permission />, permissions: [USER_MAINTENANCE_MENU_VIEW] },
    { id: 'user-maintenance-role-permission', path: '/user-maintenance/role-permission', component: <RolePermission />, permissions: [USER_MAINTENANCE_MENU_VIEW] },
    { id: 'user-maintenance-user-manager', path: '/user-maintenance/user-manager', component: <UserManager />, permissions: [USER_MAINTENANCE_MENU_VIEW] }
]

const AppRoutes = () => {
    const filteredRoutes = getFilteredMenus(routeArray);
    const route = filteredRoutes.map((x) => {
        const item = subRouteArray
            .filter((el) => { return el.parent === x.id })
            .map((e) => { return (<Route path={e.path} element={e.component} />) })
        return (
            x.permission === null ? <Route path={x.path} element={x.component} /> :
                <Route path={x.path} element={x.component} />
        )
    })
    return (
        <div className='view-container'>
            <Routes >
                {route}
                <Route path="/nopermission" element={<NoPermission />} />
                <Route path="/notfound" element={<PageNotFound />} />
                <Route path="/:unavailablePath" element={<PageNotFound />} />
                <Route path="*" element={<PageNotFound />} />
            </Routes>

        </div>
    )
}

export default AppRoutes;