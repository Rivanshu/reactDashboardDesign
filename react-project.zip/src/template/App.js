import React, { Fragment, useEffect, useState } from "react";
import ProgressSpinner from "../components/spinner/progressSpinner";
import Notify from "../components/notify/notify";
import { loading$, isSidebarVisible } from "../services/common/states";
import AppFooter from "./AppFooter";
import AppRoutes from './AppRoutes';
import AppSidebar from './AppSidebar';
import AppToolbar from "./AppToolbar";


import './App.scss';
import './App.css';
import { classNames } from "primereact/utils";

const App = ({ profile, isLoading, cleanProfile, updateProfile }) => {
    const [processClass, setProcessClass] = useState('hide-spinner');
    const [menuVisible, setMenuVisible] = useState(true);

    useEffect(() => {
        loading$.subscribe(v => setProcessClass(v ? 'show-spinner' : 'hide-spinner'));
        isSidebarVisible.subscribe(v => setMenuVisible(v));
    }, [])

    const useWindowDimensions = () => {
        const hasWindow = typeof window !== "undefined"

        function getWindowDimensions() {
            const width = hasWindow ? window.innerWidth : null
            const height = hasWindow ? window.innerHeight : null
            return {
                width,
                height,
            }
        }

        const [windowDimensions, setWindowDimensions] = useState(
            getWindowDimensions()
        )

        useEffect(() => {
            if (hasWindow) {
                function handleResize() {
                    setWindowDimensions(getWindowDimensions())
                }

                window.addEventListener("resize", handleResize)
                return () => window.removeEventListener("resize", handleResize)
            }
        }, [hasWindow])

        return windowDimensions
    }

    const { height, width } = useWindowDimensions()
    const breakpoint = 1000

    return (
        <div>
            <Fragment>
                {isLoading ? <ProgressSpinner className={processClass} /> : null}
                {menuVisible ? <AppSidebar /> : null}
                <div className={classNames(menuVisible ? 'app-wrapper' : 'app-wrapper-wm')}>
                    <div className="p-grid">
                        <div className="col">
                            <AppToolbar />
                            <Notify />
                        </div>
                        <AppRoutes />
                    </div>
                    <AppFooter />
                </div>
            </Fragment>
        </div>

    );
}

export default App;