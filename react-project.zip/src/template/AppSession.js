import React, { useState, useEffect, useCallback, Fragment } from 'react';
import { useNavigate } from 'react-router-dom';
import appProperties from '../config/appProperties';
import { Button } from 'primereact/button';
import { Dialog } from 'primereact/dialog';
import { useDispatch } from 'react-redux';
import { logout } from '../services/store/userSlice';

let timer1;
const delay = appProperties.sessionTimeout;
const validate = () => {
    return appProperties.bypassSessionFrom.indexOf(window.location.pathname) === -1
}

const AlertDialog = (props) => {
    const [open, setOpen] = React.useState(false)
    const dispatch = useDispatch()
    const navigate = useNavigate()

    const handleClose = () => {
        dispatch(logout())
        navigate('/login')
        setOpen(false)
    }

    return (
        <div>
            <Dialog
                header="Header" modal
                visible={open}
                style={{ width: '50vw' }}
                draggable={false} resizable={false}>
                <p className="m-0">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco
                    laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.
                    Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
            </Dialog>

            {/* <Dialog open={open} onClose={handleClose} aria-labelledby="alert-dialog-title" aria-describedby="alert-dialog-description">
                <DialogTitle id="alert-dialog-title">{'MD Ally Session Expired'}</DialogTitle>
                <DialogContent>
                    <DialogContentText id="alert-dialog-description">
                        Your session has expired. You will have to re-login the application to start new session
                    </DialogContentText>
                </DialogContent>
                <DialogActions>
                    <Button onClick={handleClose}>OK</Button>
                </DialogActions>
            </Dialog> */}
        </div>
    )
}
const AppSession = () => {
    const [events] = useState(['click', 'load', 'scroll'])
    const [show, setShow] = useState(false)
    const dispatch = useDispatch()
    const navigate = useNavigate()
    const isAuthenticated = false

    useEffect(() => {
        if (validate()) {
            timer1 = setTimeout(() => signout, delay * 1000)
        }
        return () => { clearTimeout(timer1) }
    }, [isAuthenticated])

    const signout = () => {
        if (validate()) {
            setShow(true);
            dispatch(logout());
            navigate('/login')
        } else {
            resetTimer()
        }
        return <Fragment />
    }

    const resetTimer = useCallback(() => {
        setShow(false)
        clearTimeout(timer1)
        if (appProperties.bypassSessionFrom.indexOf(window.location.pathname) === -1) {
            timer1 = setTimeout(() => signout, delay * 1000)
        }
    }, [window.location.pathname])

    useEffect(() => {
        events.forEach((event) => {
            window.addEventListener(event, resetTimer)
        })
    }, [resetTimer])

    return (<React.Fragment>
        <AlertDialog />
        {show ? <Fragment /> : <></>}
    </React.Fragment>)
}

export default AppSession;
