import React, { Fragment, useEffect, useState } from "react";
import { useSelector, useDispatch } from "react-redux";
// import { selectUser, setRoles } from '../services/features/userSlice'
// import { roles } from '../common/constants/permissions'
// import { getUserData } from '../utils/oauthUtil'
// import { updateUser, cleanProfile, updateProfile, useProfile, } from '../services/profile'
import { loading$ } from "../services/common/states";
// import { getRolePermission } from '../common/utils/util'
import { selectUser } from "../services/store/userSlice";
import { useNavigate } from "react-router";

import App from "./App";

const Application = () => {
  const navigate = useNavigate();
  const user = useSelector(selectUser);
  const [isLoading, setIsLoading] = useState(false);
  useEffect(() => {
      navigate("/dashboard");
  }, []);

  return (
    <Fragment>
      <App/>
    </Fragment>
  );
};

export default Application;
