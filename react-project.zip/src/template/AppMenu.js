
const Menu = [
    // { label: 'Home', icon: 'pi-home', url: '/home', active: true },
    { label: 'Dashboard', icon: 'pi-th-large', url: '/dashboard' },
    { label: 'Migrate Pipe', icon: 'pi-list', url: '/pipeline' },
    { label: 'Pipeline-Dashboard', icon: 'pi-user', url: '/pipelinedashboard' },
    { label: 'Help', icon: 'pi-exclamation-circle', url: '/help' },

];

export default Menu;