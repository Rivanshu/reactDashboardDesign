import React, { useState, useEffect } from "react";
import { classNames } from "primereact/utils";
import { isSidebarVisible } from "../services/common/states";
import { useDispatch, useSelector } from 'react-redux';
import { selectUser } from '../services/store/userSlice';
import properties from '../config/environmentProperties';
import appProperties from "../config/appProperties";
import pkg from '../../package.json';
const AppFooter = () => {
    const [buildInfoVisible, setBuildInfoVisible] = useState(false);
    const [menuVisible, setMenuVisible] = useState(true);
    const user = useSelector(selectUser);
    const [roles, setRoles] = useState([]);

    useEffect(() => {
        isSidebarVisible.subscribe(v => setMenuVisible(v));
    }, []);

    useEffect(() => {
        try {
            let r = JSON.parse(localStorage.getItem('show_roles'));
            const roleList = r.map(e => { return (<strong className="footer-roles">{e}</strong>) })
            setRoles(roleList)
        } catch (error) { }
    }, [user]);

    const onBuildInfoClickHandler = () => { }

    return <div className={classNames(menuVisible ? 'layout-footer' : 'layout-footer-wm')}>
        <div className="clearfix" style={{ width: 'calc(100vw - 0px)' }}>
            <div className="grid">
                <div className="col">
                    <span onClick={onBuildInfoClickHandler} className="footer-text-left">{appProperties.appName} {pkg.version}</span>
                    <span>:   {properties.currentEnvironment.depType.toUpperCase()} </span>
                </div>
                <div className="col" style={{ textAlign: 'right' }}>
                    <span style={{fontWeight:'normal'}}>@2023, Espire Infolabs Pvt. Ltd.</span>
                    <span style={{fontWeight:'normal'}}> All Rights Reserved</span>
                </div>
            </div>
        </div>

    </div >
}

export default AppFooter;