import React, { Component } from 'react'
import AppErrorBoundry from './AppErrorBoundry';
class AppExceptionWrapper extends Component {
    state = {
        hasError: false,
    }
    constructor(props) {
        super(props)
        this.state = { hasError: false }
    }

    componentDidCatch(error, info) {
        if (error) {
            console.error('Runtime Exception', error)
        }
        if (info) {
            console.error('Runtime Information', info)
        }
        this.setState({ hasError: true })
    }

    render() {
        if (this.state.hasError) {
            return <AppErrorBoundry />
        }
        return this.props.children
    }
}

export default AppExceptionWrapper
