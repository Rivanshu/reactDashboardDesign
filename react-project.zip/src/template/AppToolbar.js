// AppToolbar.js
import React from 'react';
import { Menubar } from 'primereact/menubar';
import { Link } from 'react-router-dom';

const AppToolbar = () => {
  const start = (
    <Link to="/" className="logo">
      {/* Add your logo or app title here */}
      Your Logo
    </Link>
  );

  const end = (
    <React.Fragment>
      {/* Add your user profile icon or menu items on the right side */}
    </React.Fragment>
  );

  return <Menubar start={start} end={end} />;
};

export default AppToolbar;
