import React from 'react'

const AppErrorBoundry = () => {
    return (
        <div className="">
            <div className="col-6 banner">
                <div className="image"></div>
                <h1>All-in-one Workspace</h1>
                <p>
                    <em>Timesheet, Leaves, Payroll and get organized.</em>
                    <em><strong>ESS</strong> is all you need - in one tool</em>
                    <small>@2023, Espire Infolab Pvt. Ltd. All Rights Reserved</small>
                </p>
            </div>
        </div>
    )
}

export default AppErrorBoundry