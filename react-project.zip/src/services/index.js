// import FakeAuthService from "./fake/FakeAuthService";
// import EunicaService from './eunica/eunica_service';
// // import { db } from './opendb/connection';
// const eunicaService = new EunicaService();
// // Fake Services
// const fakeAuthService = new FakeAuthService();

// const fakeData = {
//     fakeAuthService
// }

// export {
//     fakeData, eunicaService
// }