import eucPortalAdminApi from '../../config/properties.js'

class CityService {

    async addCity(data) {
        return Promise.resolve(eucPortalAdminApi.post(`cities`, data));
    }

    async getAllCity(page = '1', size = '10') {
        const param = `page=${page}&size=${size}`
        return Promise.resolve(eucPortalAdminApi.get(`cities?${param}`));
    }

    async getCityById(id = '') {
        return Promise.resolve(eucPortalAdminApi.get(`cities/${id}`));
    }

    async updateCity(data, id = '') {
        return Promise.resolve(eucPortalAdminApi.put(`cities/${id}`, data));
    }

    async deleteCity(id = '') {
        return Promise.resolve(eucPortalAdminApi.delete(`cities/${id}`));
    }

}

export default new CityService();