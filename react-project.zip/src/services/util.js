import moment from "moment";
class UtilitiesService {
  show() {
    console.log("Hi");
  }

  initialCapital(str, startWithCapital = false, speceSeprator = false) {
    let text = str.replace(/ /g, "_");
    let words = text.split("_");
    let items = [];
    words.map((item) => {
      let newWord = item.toLowerCase();
      newWord = newWord.charAt(0).toUpperCase() + newWord.slice(1);
      items.push(newWord);
    });
    let result = items.join(speceSeprator ? " " : "");
    return startWithCapital
      ? result.charAt(0).toUpperCase() + result.slice(1)
      : result.charAt(0).toLowerCase() + result.slice(1);
  }

  key2Label(str, underscoreSeprator = false) {
    var result = str.replace(/([A-Z])/g, " $1");
    let words = result.split(" ");
    let newArray = [];
    words.map((x) => {
      newArray.push(x.charAt(0).toUpperCase() + x.slice(1));
    });
    return underscoreSeprator
      ? newArray.join("_").toLowerCase()
      : newArray.join(" ");
  }

  // getQueryVariable = (variable) => {
  //   var query = window.location.search.substring(1);
  //   var vars = query.split("&");
  //   for (var i = 0; i < vars.length; i++) {
  //     var pair = vars[i].split("=");
  //     if (pair[0] === variable) {
  //       return pair[1];
  //     }
  //   }
  //   return false;
  // };

  /* to use prevent whitespace at the start of char/int */
  charIntWhithoutSpace = (e) => {
    const re = e.charCode;
    if (re === 32 && e.target.value == 0) {
      e.preventDefault();
    }
  };
  /* to use prevent whitespace at the start of char/int */

  /* to use prevent char only */
  preventChar = (e) => {
    const re = e.charCode;
    if (re > 57 || re === 32) {
      e.preventDefault();
    }
  };
  /* to use prevent char only */

  /* User First name last Name Merge */
  titleCase = (str = "") => {
    let words = str.split(" ");
    words.forEach((w, i) => {
      w = w.substring(0, 1).toLocaleUpperCase() + w.substring(1);
      words[i] = w;
    });
    return words.join(" ");
  };
  /* User First name last Name Merge */

  /* to prevent char and minus on input box */
  preventCharWithMinus = (e) => {
    const re = e.charCode;
    if (e.code === "Minus" || re > 57 || re === 32) {
      e.preventDefault();
    }
  };
  /* to prevent char and minus on input box */

  /* to prevent paste char on input box only */
  preventPasteChar = (event) => {
    if (event.type == "paste") {
      var clipboardData = event.clipboardData || window.clipboardData;
      var pastedData = clipboardData.getData("Text");
      if (isNaN(pastedData)) {
        event.preventDefault();
      } else {
        return;
      }
    }
  };
  /* to prevent paste char on input box only */

  /* to prevent int with minus on input box only */sa
  preventIntWithMinusWhiteSpace = (e) => {
    const re = e.charCode;
    var keyCode = e.keyCode ? e.keyCode : e.which;
    if (
      e.code === "Minus" ||
      (keyCode > 47 && keyCode < 58) ||
      (re === 32 && e.target.value == 0)
    ) {
      e.preventDefault();
    }
  };
  /* to prevent int with minus on input box only */

  /* to prevent minus only */
  preventMinus = (e) => {
    const re = e.charCode;
    if (e.code === "Minus" || re > 57 || re === 32) {
      e.preventDefault();
    }
  };

  preventMorethan8 = (e) => {
    if (e.value > 8) {
      e.preventDefault();
    }
  };

  /* for change date format start */
  dateTimestampConverter = (str) => {
    let myDate = str.split("-");
    let newDate = new Date(myDate[2], myDate[1] - 1, myDate[0]);
    return newDate;
  };

  dateConverter = (str) => {
    var date = new Date(str),
      mnth = ("0" + (date.getMonth() + 1)).slice(-2),
      day = ("0" + date.getDate()).slice(-2);
    var year = date.getFullYear();
    return `${day}-${mnth}-${year}`;
  };

  /* for change date format May 01, 2023 */
  dateConverterUS = (str, time = false) => {
    if (time) {
      return moment(str).format("MMM DD, YYYY [at] hh:mm A");
    } else {
      return moment(str).format("MMM DD, YYYY");
    }
  };

  /* for change date format 01-Jun-2023 */
  dateConverterShort = (str) => {
    var date = new Date(str),
      mnth = ("0" + (date.getMonth() + 1)).slice(-2),
      day = ("0" + date.getDate()).slice(-2);
    var year = date.getFullYear();
    const dateStart = new Date(year, mnth - 1, day); // 2009-11-10
    const monthName = dateStart.toLocaleString("default", {
      month: "short",
    });
    return `${day}-${monthName}-${year}`;
  };

  dateConverterForAttendance = (str) => {
    var date = new Date(str),
      mnth = ("0" + (date.getMonth() + 1)).slice(-2),
      day = ("0" + date.getDate()).slice(-2);
    var year = date.getFullYear();
    return `${year}-${mnth}-${day}`;
  };

  getTimeFromDate = (str) => {
    let time = str.getHours() + ":" + str.getMinutes() + ":" + str.getSeconds();
    return time;
  };
  /* for change date format end */

  /* for change date format start */
  dateConverterToMonthDay = (str) => {
    var date = new Date(str),
      mnth = ("0" + (date.getMonth() + 1)).slice(-2),
      day = ("0" + date.getDate()).slice(-2);
    var year = date.getFullYear();
    return `${mnth}-${day}-${year}`;
  };
  /* for change date format end */

  /* for change date into short format start */
  dateConvertToShort = (str) => {
    const day = str.toLocaleString().split("-")[0];
    const month = str.toLocaleString().split("-")[1];
    const year = str.toLocaleString().split("-")[2];
    const dateStart = new Date(year, month - 1, day); // 2009-11-10
    const monthName = dateStart.toLocaleString("default", {
      month: "short",
    });
    return `${day}-${monthName}-${year}`;
  };
  /* for change date into short format end */

  /* for current monday week start */
  getMondayOfCurrentWeek = () => {
    const today = new Date();
    const first = today.getDate() - today.getDay() + 1;
    const monday = new Date(today.setDate(first));
    return monday;
  };
  /* for current monday week end */

  /* Add Days into date */
  addDays = (date, days) => {
    const dateCopy = new Date(date);
    dateCopy.setDate(date.getDate() + (days - 1));
    return dateCopy;
  };

  /* Past Days into date */
  pastDays = (date, days) => {
    const dateCopy = new Date(date);
    dateCopy.setDate(date.getDate() - (days - 1));
    return this.dateConverter(dateCopy);
  };
  /* Past Days into date */
  /* Add Days into date */

  convertBase64 = (file) => {
    return new Promise((resolve, reject) => {
      const fileReader = new FileReader();
      fileReader.readAsDataURL(file);

      fileReader.onload = () => {
        resolve(fileReader.result);
      };

      fileReader.onerror = (error) => {
        reject(error);
      };
    });
  };

  /*To export a file in Excel*/

  // exportExcel(data, fileName) {
  //   import("xlsx").then((xlsx) => {
  //     const worksheet = xlsx.utils.json_to_sheet(data);
  //     const workbook = { Sheets: { data: worksheet }, SheetNames: ["data"] };
  //     const excelBuffer = xlsx.write(workbook, {
  //       bookType: "xlsx",
  //       type: "array",
  //     });
  //     this.saveAsExcelFile(excelBuffer, fileName);
  //   });
  // }

  // saveAsExcelFile(buffer, fileName) {
  //   import("file-saver").then((module) => {
  //     if (module && module.default) {
  //       let EXCEL_TYPE =
  //         "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8";
  //       let EXCEL_EXTENSION = ".xlsx";
  //       const data = new Blob([buffer], {
  //         type: EXCEL_TYPE,
  //       });

  //       module.default.saveAs(
  //         data,
  //         fileName + "_export_" + new Date().getTime() + EXCEL_EXTENSION
  //       );
  //     }
  //   });
  // }

  /*To export a file in Excel*/

  /*Export a file in PDF */
  // exportPdf = (columns, data, fileName) => {
  //   // console.log(data, "datadata")
  //   var invoiceListing = [];
  //   data.map((item) => {
  //     let objInvoice = {
  //       ecn: item.ecn,
  //       name: this.invoiceBodyTemplate(item, "name"),
  //       designation: this.invoiceBodyTemplate(item, "designation"),
  //       bu: this.invoiceBodyTemplate(item, "bu"),
  //       client: this.invoiceBodyTemplate(item, "client"),
  //       projectCode: this.invoiceBodyTemplate(item, "projectCode"),
  //       projects: this.invoiceBodyTemplate(item, "project"),
  //       projectType: this.invoiceBodyTemplate(item, "projectType"),
  //       totalDays: this.invoiceBodyTemplate(item, "totalDays"),
  //       otHours: this.invoiceBodyTemplate(item, "otHours"),
  //       hours: this.invoiceBodyTemplate(item, "hours"),
  //       totalHours: this.invoiceBodyTemplate(item, "totalHours"),
  //       pm: this.invoiceBodyTemplate(item, "pm"),
  //       status: this.invoiceBodyTemplate(item, "status"),
  //     };
  //     invoiceListing.push(objInvoice);
  //   });

    // import("jspdf").then((jsPDF) => {
    //   import("jspdf-autotable").then(() => {
    //     // const doc = new jsPDF.default(0, 0);
    //     const doc = new jsPDF.default("portrait", "pt", "a4");
    //     doc.autoTable(columns, invoiceListing);
    //     doc.save(fileName + ".pdf");
    //   });
    // });
  };
  /*Export a file in PDF */

  /*Export a file in PDF for setting*/

  // exportAsPdf = (columns, data, fileName) => {
  //   import("jspdf").then((jsPDF) => {
  //     import("jspdf-autotable").then(() => {
  //       const doc = new jsPDF.default(0, 0);

  //       doc.autoTable(columns, data);

  //       doc.save(fileName + ".pdf");
  //     });
  //   });
  // };

  /*Export a file in PDF for setting*/

  /* Export CSV Start */
  // exportToCSV = (params) => {
  //   try {
  //     const mapItems = [...params.bodyData];
  //     // Sort Columns
  //     const sortedColumns = params.headersKey.concat(
  //       Object.keys(mapItems[0]).filter(
  //         (k) => k !== params.headersKey[0] && k !== params.headersKey[1]
  //       )
  //     );
  //     // Create new applicants in correct column order
  //     const newOrder = mapItems.map((a) => {
  //       let row = {};
  //       sortedColumns.forEach((c) => (row[c] = a[c]));
  //       return row;
  //     });
  //     let csvRow = [];
  //     let A = [];
  //     // Header
  //     A.push(["", ...params.headers]);
  //     // Body
  //     newOrder.forEach((e) => {
  //       let rowItem = [];
  //       Object.keys(e).forEach((key) => {
  //         if (params.headersKey.includes(key)) {
  //           rowItem.push(e[key]);
  //         }
  //       });
  //       A.push(rowItem);
  //     });
  //     let j = 0;
  //     A.forEach((e) => {
  //       csvRow.push(A[j].join(","));
  //       j++;
  //     });
  //     const csvString = csvRow.join("%0A");
  //     let doc2 = document.createElement("a");
  //     doc2.href = "data:text/csv;charset=utf-8" + csvString;
  //     doc2.target = "_Blank";
  //     doc2.download = params.fileName + ".csv";
  //     document.body.appendChild(doc2);
  //     doc2.click();
  //   } catch (error) { }
  // };
  /* Export CSV End */

  // invoiceBodyTemplate = (rowData, type) => {
  //   switch (type) {
  //     case "name":
  //       return rowData.firstName + " " + rowData.lastName;
  //     case "designation":
  //       return rowData.Designation.title;
  //     case "region":
  //       return rowData.Timesheets[0]?.timesheetProjects[0]?.projectDetails
  //         ?.customers?.code;
  //     case "bu":
  //       return rowData.Timesheets[0]?.timesheetProjects[0]?.projectDetails
  //         ?.businessUnits?.title;
  //     case "client":
  //       return rowData.Timesheets[0]?.timesheetProjects[0]?.projectDetails
  //         ?.customers?.title;
  //     case "projectCode":
  //       return rowData.Timesheets[0]?.timesheetProjects[0]?.projectDetails
  //         ?.code;
  //     case "projectType":
  //       return rowData.Timesheets[0]?.timesheetProjects[0]?.projectDetails
  //         ?.projectTypes?.title;
  //     case "pm":
  //       return (
  //         rowData.Timesheets[0]?.timesheetProjects[0]?.projectDetails?.pmDetails
  //           ?.firstName +
  //         " " +
  //         rowData.Timesheets[0]?.timesheetProjects[0]?.projectDetails?.pmDetails
  //           ?.lastName
  //       );
  //     case "project":
  //       let proName = [];
  //       rowData.Timesheets.map((el) => {
  //         el.timesheetProjects.map((e) => {
  //           proName.push(e.projectDetails.title);
  //         });
  //       });
  //       let proNameUnique = Array.from(new Set(proName));
  //       return proNameUnique.join("; ");
  //     case "status":
  //       const invoiceStatus = rowData.Timesheets.map((el) => {
  //         return el.status;
  //       });
  //       return invoiceStatus.includes("APPROVED") ? "UNLOCK" : "LOCK";
  //     case "totalDays":
  //       return rowData.Timesheets.length;
  //     case "hours":
  //       return (
  //         <div style={{ marginLeft: "15px" }}>
  //           <strong>{rowData.Timesheets[0].totalHours}</strong>
  //         </div>
  //       );
  //     case "totalHours":
  //       let total = 0;
  //       for (let i = 0; i < rowData.Timesheets.length; i++) {
  //         total += rowData.Timesheets[i].totalHours
  //           ? rowData.Timesheets[i].totalHours
  //           : 0;
  //       }
  //       return total;
  //     default:
  //       return "";
  //   }
  // };

  // activityItemBody = (el) => {
  //   return (
  //     <div>
  //       {" "}
  //       <span>{el.title}</span>
  //       {el.isBillable ? (
  //         <span
  //           style={{
  //             // marginLeft: "20px",
  //             height: "14px",
  //             color: "green",
  //             fontSize: "10px",
  //           }}
  //         >
  //           (Billable)
  //         </span>
  //       ) : (
  //         <span
  //           style={{
  //             // marginLeft: "20px",
  //             height: "14px",
  //             color: "red",
  //             fontSize: "10px",
  //           }}
  //         >
  //           (Non-Billable)
  //         </span>
  //       )}
  //     </div>
  //   );
  // };

  /*GET IP and Location Start */
  // generateIp = async () => {
  //   // const res = await axios.get('https://geolocation-db.com/json/');
  //   const response = await fetch(`https://geolocation-db.com/json/`);
  //   const data = await response.json();
  //   return data;
  // };
  /*GET IP and Location End */

  // validURL(str) {
  //   var pattern = new RegExp(
  //     "^(https?:\\/\\/)?" + // protocol
  //     "((([a-z\\d]([a-z\\d-]*[a-z\\d])*)\\.)+[a-z]{2,}|" + // domain name
  //     "((\\d{1,3}\\.){3}\\d{1,3}))" + // OR ip (v4) address
  //     "(\\:\\d+)?(\\/[-a-z\\d%_.~+]*)*" + // port and path
  //     "(\\?[;&a-z\\d%_.~+=-]*)?" + // query string
  //     "(\\#[-a-z\\d_]*)?$",
  //     "i"
  //   ); // fragment locator
  //   return !!pattern.test(str);
  // }

//   currentTimeInUtc() {
//     const now = new Date();
//     const year = now.getUTCFullYear();
//     const month = now.getUTCMonth() + 1;
//     const day = now.getUTCDate();
//     const hours = now.getUTCHours();
//     const minutes = now.getUTCMinutes();
//     const seconds = now.getUTCSeconds();
//     const milliseconds = now.getUTCMilliseconds();

//     let nowINUTC = `${year}-${month}-${day} 
// ${hours}:${minutes}:${seconds}.${milliseconds}`;

//     return nowINUTC;
//   }

  // projectBodyTemplate = (rowData) => {
  //   let proName = [];
  //   rowData.timesheetProjects.map((e) => {
  //     proName.push(e.projectDetails.title);
  //   });
  //   let proNameUnique = proName.filter((item, index) => proName.indexOf(item) === index);
  //   let proNameS = [];
  //   for (let p of proNameUnique) {
  //     proNameS.push(
  //       <Chip label={p} className="mr-2 mb-2" />
  //     );
  //   }
  //   return <span className="">{proNameS}</span>;
  // }



export default UtilitiesService;
