import eucPortalApi from '../../config/properties.js'

class PermissionService {

    async addPermission(data) {
        return Promise.resolve(eucPortalApi.post(`permissions`, data));
    }

    async getAllPermission(page = '1', size = '10') {
        const param = `page=${page}&size=${size}`
        return Promise.resolve(eucPortalApi.get(`permissions?${param}`));
    }

    async getPermissionById(id = '') {
        return Promise.resolve(eucPortalApi.get(`permissions/${id}`));
    }

    async updatePermission(data, id = '') {
        return Promise.resolve(eucPortalApi.put(`permissions/${id}`, data));
    }

    async deletePermission(id = '') {
        return Promise.resolve(eucPortalApi.delete(`permissions/${id}`));
    }

}

export default new PermissionService();