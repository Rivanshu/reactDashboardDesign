import erfLocalApi from '../axios/erfLocalApi';

class FakeAuthService {
    async login() {
        return Promise.resolve(erfLocalApi.get(`login.json`));
    }

    async getFormat() {
        return Promise.resolve(erfLocalApi.get(`formats.json`));
    }

    async getUserData() {
        return Promise.resolve(erfLocalApi.get(`userinfo.json`));
    }
    async getPieChartData() {
        return Promise.resolve(erfLocalApi.get(`pie-chart.json`));
    }

    async getHistory() {
        return Promise.resolve(erfLocalApi.get(`history.json`));
    }

    async getHints() {
        return Promise.resolve(erfLocalApi.get(`help.json`));
    }
}

export default FakeAuthService;