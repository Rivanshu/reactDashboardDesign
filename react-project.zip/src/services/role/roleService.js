import eucPortalApi from '../../config/properties.js'

class RoleService {

    async addRole(data) {
        return Promise.resolve(eucPortalApi.post(`roles`, data));
    }

    async getAllRole(page = '1', size = '10') {
        const param = `page=${page}&size=${size}`
        return Promise.resolve(eucPortalApi.get(`roles?${param}`));
    }

    async getRoleById(id = '') {
        return Promise.resolve(eucPortalApi.get(`roles/${id}`));
    }

    async updateRole(data, id = '') {
        return Promise.resolve(eucPortalApi.put(`roles/${id}`, data));
    }

    async deleteRole(id = '') {
        return Promise.resolve(eucPortalApi.delete(`roles/${id}`));
    }

}

export default new RoleService();