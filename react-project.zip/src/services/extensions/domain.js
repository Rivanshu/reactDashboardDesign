// import erfApi from '../axios/erfApi';

// class DomainService {
//     async getDomains() {
//         return Promise.resolve(erfApi.get('domains'))
//     }
// }

// export default DomainService