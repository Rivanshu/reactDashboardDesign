// import erfApi from '../axios/erfApi';

// class PermissionService {
//     async getPermissions() {
//         return Promise.resolve(erfApi.get('permission'))
//     }

//     async getRolePermission(id) {
//         return Promise.resolve(erfApi.get(`roles/${id}/permissions`))
//     }

//     async getDomainPermissions(domain) {
//         return Promise.resolve(erfApi.get(`domains/${domain}/permissions`));
//     }

//     async removePermission(roleId, permissionId) {
//         return Promise.resolve(erfApi.delete(`role/${roleId}/permission/${permissionId}`));
//     }

//     async createPermissions(reqBody) {
//         return Promise.resolve(erfApi.post('permission', reqBody))
//     }

//     async addRolePermission(reqBody) {
//         return Promise.resolve(erfApi.post('role/permissions', reqBody))
//     }
// }

// export default PermissionService