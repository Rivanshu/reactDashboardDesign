// import erfApi from "../axios/erfApi";

// class NotificationService {

//     async getNotification() {
//         return Promise.resolve(erfApi.get(`notification`));
//     }
//     async getNotificationById(reqBody) {
//         return Promise.resolve(erfApi.get(`notification/${reqBody}`));
//     }
//     async deleteNotification(id) {
//         return Promise.resolve(erfApi.delete(`notification/${id}`));
//     }
//     async deleteAllNotification(reqBody) {
//         return Promise.resolve(erfApi.post(`notification-All`, reqBody));
//     }
//     async filterNotificationAccordingToDate(reqBody) {
//         return Promise.resolve(erfApi.post(`notification-All-date`, reqBody));
//     }
// }

// export default NotificationService;