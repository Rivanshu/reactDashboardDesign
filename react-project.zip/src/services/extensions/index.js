// import User from "./user";
// import RoleService from "./role";
// import PermissionService from "./permission";
// import DomainService from "./domain";
// import NotificationService from "./notification";

// const userService = new User();
// const roleService = new RoleService();
// const permissionService = new PermissionService();
// const domainService = new DomainService();
// const notificationService = new NotificationService();

// export {
//     userService, roleService, permissionService, domainService, notificationService
// }