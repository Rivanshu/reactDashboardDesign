// import erfApi from "../axios/erfApi";

// class User {

//   async register(payload) {
//     return Promise.resolve(erfApi.post(`users`, payload));
//   }

//   async getUsers() {
//     return Promise.resolve(erfApi.get(`users`));
//   }

//   async getRoles() {
//     return Promise.resolve(erfApi.get(`roles`));
//   }

//   async getPermissions() {
//     return Promise.resolve(erfApi.get(`permissions`));
//   }

//   async getManagers() {
//     return Promise.resolve(erfApi.get(`/users/getall-user/MANAGER`));
//   }

//   async assignManagerToEmployee(param) {
//     return Promise.resolve(erfApi.post(`/users/assign-manager`, param));
//   }

//   async getDesignations() {
//     return Promise.resolve(erfApi.get(`/designation`));
//   }

//   async assignDesignationToEmployee(param) {
//     return Promise.resolve(erfApi.post(`/users/assign-designation`, param));
//   }

//   async searchUsers(payload) {
//     return Promise.resolve(erfApi.post(`users/user-by-filter`, payload));
//   }

//   async getDesignation() {
//     return Promise.resolve(erfApi.get(`designation`));
//   }

//   async getUserByFilter(reqBody) {
//     return Promise.resolve(erfApi.post(`/users/user-by-filter`, reqBody));
//   }

//   async getBusinessUnit() {
//     return Promise.resolve(erfApi.get(`business-unit`));
//   }

//   async assignBuToEmployee(param) {
//     return Promise.resolve(erfApi.post(`/users/assign-business-unit`, param));
//   }
//   async assignRoleToEmployee(param) {
//     return Promise.resolve(erfApi.post(`/user/assign-role`, param));
//   }

//   async getAllUsers() {
//     return Promise.resolve(erfApi.get(`/users/getall`));
//   }
// }

// export default User;