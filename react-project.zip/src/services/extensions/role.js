// import erfApi from "../axios/erfApi";

// class RoleService {
//   async getRoles() {
//     return Promise.resolve(erfApi.get("roles"));
//   }
//   async createRoles(reqBody) {
//     return Promise.resolve(erfApi.post("role", reqBody));
//   }
//   async deleteRole(id) {
//     return Promise.resolve(erfApi.delete(`deleteRoleById/${id}`));
//   }
// }

// export default RoleService;
