import eucPortalApi from "../axios/eunica-portal-api";

class LoginService {

    async login(data) {
        return Promise.resolve(eucPortalApi.post(`auth/login`, data));
    }

}

export default new LoginService();