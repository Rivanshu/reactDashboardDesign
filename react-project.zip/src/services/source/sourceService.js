import eucPortalPipelineApi from "../axios/eunica-pipeline-api";

class SourceService {

    async addSource(data) {
        return Promise.resolve(eucPortalPipelineApi.post(`sources`, data));
    }

    async getAllSource(page = '1', size = '10') {
        const param = `page=${page}&size=${size}`
        return Promise.resolve(eucPortalPipelineApi.get(`sources?${param}`));
    }

    async getSourceById(id = '') {
        return Promise.resolve(eucPortalPipelineApi.get(`sources/${id}`));
    }

    async updateSource(data, id = '') {
        return Promise.resolve(eucPortalPipelineApi.put(`sources/${id}`, data));
    }

    async deleteSource(id = '') {
        return Promise.resolve(eucPortalPipelineApi.delete(`sources/${id}`));
    }

}

export default new SourceService();