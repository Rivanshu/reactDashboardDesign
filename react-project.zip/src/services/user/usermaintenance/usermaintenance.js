import React from "react";
import { useState, useEffect, useRef } from "react";
import { Card } from 'primereact/card';
import { useNavigate } from 'react-router-dom';
import { Avatar } from 'primereact/avatar';
import "../style.scss";
import AddContact from "./addcontact";
import { FileUpload } from 'primereact/fileupload';
import { InputTextarea } from 'primereact/inputtextarea';
import { Tag } from 'primereact/tag';
import 'primeicons/primeicons.css';
import { Dialog } from "primereact/dialog";
import { Button } from "primereact/button";
import { ProgressBar } from 'primereact/progressbar';
import userservice from "../../services/usermaintenance/userservice";
import { Splitter, SplitterPanel } from 'primereact/splitter';
import { Dropdown } from 'primereact/dropdown';
import { InputText } from 'primereact/inputtext';
import { InputMask } from 'primereact/inputmask';

import './um.css'
import CreateOrganisation from "./createOrganisation";


const UserInfoForm = () => {
  const [username, SetUserName] = useState('');
  const [useremail, SetUserEmail] = useState('');
  const [userpassword, SetUserPassword] = useState('');
  const [usertype, SetUserType] = useState('');
  const fileUploadRef = useRef(null);
  const [totalSize, setTotalSize] = useState(0);
  const toast = useRef(null);
  const [rolesdata, setRolesData] = useState()
  const [selectedOption, setSelectedOption] = useState()


  useEffect(() => {
    getRoles();
  }, [])
  useEffect(() => {
    if (selectedOption != null) {
      const data = rolesdata.find((item) => item.name === selectedOption);
      setDropDownval(data)

    }
  }, [selectedOption])


  const handleSubmit = (e) => {
    e.preventDefault();
    // Perform form submission logic here
    console.log('First Name:', username);
    console.log('Last Name:', useremail);
    console.log('Description:', userpassword);
    console.log('Gender:', usertype);
    // Reset form fields
    SetUserName('');
    SetUserEmail('');
    SetUserPassword('');
    SetUserType('');
  };
  const onTemplateSelect = (e) => {
    let _totalSize = totalSize;
    e.files.forEach(file => {
      _totalSize += file.size;
    });

    setTotalSize(_totalSize);
  }

  const onTemplateUpload = (e) => {
    let _totalSize = 0;
    e.files.forEach(file => {
      _totalSize += (file.size || 0);
    });

    setTotalSize(_totalSize);
    toast.current.show({ severity: 'info', summary: 'Success', detail: 'File Uploaded' });
  }

  const onTemplateRemove = (file, callback) => {
    setTotalSize(totalSize - file.size);
    callback();
  }

  const onTemplateClear = () => {
    setTotalSize(0);
  }

  const headerTemplate = (options) => {
    const { className, chooseButton, uploadButton, cancelButton } = options;
    const value = totalSize / 10000;
    const formatedValue = fileUploadRef && fileUploadRef.current ? fileUploadRef.current.formatSize(totalSize) : '0 B';

    return (
      <div className={className} style={{ backgroundColor: 'transparent', display: 'flex', alignItems: 'center', height: '100px' }}>
        {chooseButton}
        {uploadButton}
        {cancelButton}
        <ProgressBar value={value} displayValueTemplate={() => `${formatedValue} / 1 MB`} style={{ width: '200px', height: '20px', marginLeft: 'auto' }}></ProgressBar>
      </div>
    );
  }

  const itemTemplate = (file, props) => {
    return (
      <div className="flex align-items-center flex-wrap">
        <div className="flex align-items-center" style={{ width: '40%' }}>
          <img alt={file.name} role="presentation" src={file.objectURL} width={100} />
          <span className="flex flex-column text-left ml-3">
            {file.name}
            <small>{new Date().toLocaleDateString()}</small>
          </span>
        </div>
        <Tag value={props.formatSize} severity="warning" className="px-3 py-2" />
        <Button type="button" icon="pi pi-times" className="p-button-outlined p-button-rounded p-button-danger ml-auto" onClick={() => onTemplateRemove(file, props.onRemove)} />
      </div>
    )
  }

  const emptyTemplate = () => {
    return (
      <div className="flex align-items-center flex-column">
        <i className="pi pi-image mt-3 p-5" style={{ 'fontSize': '5em', borderRadius: '50%', backgroundColor: 'var(--surface-b)', color: 'var(--surface-d)' }}></i>
        <span style={{ 'fontSize': '1.2em', color: 'var(--text-color-secondary)' }} className="my-5">Drag and Drop Image Here</span>
      </div>
    )
  }
  const [dropdownval, setDropDownval] = useState({})
  const getRoles = () => {

    userservice.getRoles().then((resp) => {
      setRolesData(resp.data.data)
    })
  }
  const handleOptionChange = (e) => {
    setSelectedOption(e.value);

  };



  const customBase64Uploader = async (event) => {
    // convert file to base64 encoded
    const file = event.files[0];
    const reader = new FileReader();
    let blob = await fetch(file.objectURL).then(r => r.blob()); //blob:url
    reader.readAsDataURL(blob);
    reader.onloadend = function () {
      const base64data = reader.result;
    }
  }

  const chooseOptions = { icon: 'pi pi-fw pi-images', iconOnly: true, className: 'custom-choose-btn p-button-rounded p-button-outlined ' };
  const uploadOptions = { icon: 'pi pi-fw pi-cloud-upload', iconOnly: true, className: 'custom-upload-btn p-button-success p-button-rounded p-button-outlined size' };
  const cancelOptions = { icon: 'pi pi-fw pi-times', iconOnly: true, className: 'custom-cancel-btn p-button-danger p-button-rounded p-button-outlined size' };

  return (

    <form onSubmit={handleSubmit} className="p-fluid">
      <div className="user-form" style={{ width: '400px' }}>

        <div className="field">
          {/* <span className="p-float-label">
            <InputText id="name" name="name" value={formik.values.name} onChange={formik.handleChange} autoFocus className={classNames({ 'p-invalid': isFormFieldValid('name') })} />
            <label htmlFor="name" className={classNames({ 'p-error': isFormFieldValid('name') })}>Name*</label>
          </span> */}
          {/* {getFormErrorMessage('name')} */}
        </div>
        <div className="form-group" style={{ marginTop: "10px" }}>
          <label htmlFor="user-email">User email</label>
          <InputText id="user-email" />
        </div>
        <div className="form-group" style={{ marginTop: "10px" }}>
          <label htmlFor="user-password">User password</label>
          <InputText id="user-password" />
        </div>
        <div className="form-group" style={{ marginTop: "10px" }}>
          <label htmlFor="dropdown">Select an option:</label>
          <Dropdown id="dropdown" options={rolesdata}
            value={selectedOption}
            onChange={handleOptionChange} optionLabel="name" optionValue="name" placeholder="Select" />
        </div>
        {selectedOption != null || selectedOption != undefined ?
          <div style={{ display: 'flex' }}>
            <div className="form-group" style={{ marginTop: "10px", marginLeft: '5px' }}>
              <label htmlFor="user-name">Id.</label>
              <InputText id="idname" value={dropdownval.id || ''}
                readOnly />
            </div>
            <div className="form-group" style={{ marginTop: "10px", marginLeft: '5px' }}>
              <label htmlFor="user-name">Name</label>
              <InputText id="nameid" value={dropdownval.name || ''}
                readOnly />
            </div>
            <div className="form-group" style={{ marginTop: "10px", marginLeft: '5px' }}>
              <label htmlFor="user-name">Description</label>
              <InputText id="descrip" value={dropdownval.description || ''}
                readOnly />
            </div>
          </div>
          : null}

        <div className="form-group" style={{ marginTop: "10px" }}>
          <label htmlFor="user-image">User Image</label>
          <FileUpload ref={fileUploadRef} name="demo[]" url="https://primefaces.org/primereact/showcase/upload.php" maxFileSize={1000000}


            onUpload={onTemplateUpload} onSelect={onTemplateSelect} onError={onTemplateClear} onClear={onTemplateClear}
            headerTemplate={headerTemplate} itemTemplate={itemTemplate} emptyTemplate={emptyTemplate}
            chooseOptions={chooseOptions} uploadOptions={uploadOptions} cancelOptions={cancelOptions} />

        </div>
        <Button label="Submit" />
      </div>

    </form>
  );
};

function UserMaintenance() {
  const [layout, setLayout] = useState('grid');
  const [users, setUsers] = useState([])
  const [showDialog, setShowDialog] = useState(false);
  const [showContact, setShowContact] = useState(false);
  const [showorg, setShoworg] = useState(false);
  const [usertypes, SetUserTypes] = useState();


  useEffect(() => {
    SetUserTypes(localStorage.getItem("userType"))
  }, [])
  //
  const showDialogBox = () => {
    setShowDialog(true);
  };

  const hideDialogBox = () => {
    setShowDialog(false);
  };


  ///
  const showContactbox = () => {
    setShowContact(true);
  };

  const hidecontactbox = () => {
    setShowContact(false);
  };

  ////
  const showOrganisation = () => {
    setShoworg(true);
  };

  const hideOrganisation = () => {
    setShoworg(false);
  };
  // useEffect(() => {
  //   getUserData();
  // }, []);

  // const getUserData = () => {
  //   fakeData.fakeAuthService.getUserData().then(resp => {
  //     setUsers(resp.data);
  //   });
  // }

  return (
    <div style={{ marginLeft: '20px' }} >
      <div style={{ display: 'flex', marginBottom: '20px', marginTop: '20px' }}>
        <h1 style={{ color: '#0066cc', width: '1300px' }}>User Maintenance Page</h1>



        {/*     create organisation   */}
        {usertypes === 'super_admin' ? <Button icon="pi pi-user" onClick={showOrganisation} style={{ marginLeft: '10px', background: 'none', color: 'blue', borderRadius: '40px', borderColor: 'white' }} />
          : <></>}
        <Dialog header="Add Organisation" visible={showorg} onHide={hideOrganisation}>
          <CreateOrganisation />
        </Dialog>

        {/*     create contact   */}
        {usertypes === 'admin' ? <Button icon="pi pi-user" onClick={showContactbox} style={{ marginLeft: '10px', background: 'none', color: 'blue', borderRadius: '40px', borderColor: 'white' }} />
          : <></>}

        <Dialog header="Add Contact" visible={showContact} onHide={hidecontactbox}>
          <AddContact />
        </Dialog>

        {/*     Add new User    */}




        {/* <Button icon="pi pi-users" onClick={showDialogBox} style={{ marginLeft: '10px', background: 'none', color: 'blue', borderRadius: '40px', borderColor: 'white' }} />
        <Dialog header="Add New User" icon="pi pi-user" visible={showDialog} onHide={hideDialogBox}>
          <UserInfoForm />
        </Dialog> */}

      </div>
      {/* <div style={{ display: 'flex', flexWrap: 'wrap', justifyContent: 'flex-start', gap: '20px' }}>
        {users.map((user) => (
          <Card key={user.id} >
            <div style={{ display: "flex", flex: ' 0 0 25%', height: '50px', width: '300px', alignItems: 'center' }} >
              <div style={{ alignItems: 'right' }}>
                <img style={{ height: '50px', width: '50px' }} src={`/assets/images/user/${user.userimage}`} alt="User" className="avatar" />
              </div>
              <div style={{ alignItems: 'left', marginLeft: '10px' }}>
                <span className="user-name"><b>{user.name}</b></span>
                <br />
                <span className="user-email">{user.description}</span>
              </div>
            </div>
          </Card>

        ))}


      </div> */}
    </div>
  );
};

export default UserMaintenance;