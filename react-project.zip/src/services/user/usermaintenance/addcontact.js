import React from 'react';
import { Formik, Form, Field, ErrorMessage } from 'formik';
import { useState, useEffect } from 'react';
import * as Yup from 'yup';
import axios from 'axios';
import { InputText } from 'primereact/inputtext';
import { Button } from 'primereact/button';
import { Dropdown } from 'primereact/dropdown';
import userservice from "../../services/";
import { FileUpload } from 'primereact/fileupload';

const AddContact = () => {
    const initialValues = {
        firstName: '',
        lastName: '',
        organisation: '',
        email: '',
        phone: '',
        jobTitle: '',
        profileImage: null,
    };
    const [users, setUsers] = useState([])
    const [org, setorg] = useState({})

    const [selectedOption, setSelectedOption] = useState()


    useEffect(() => {
        // getUserData();
        getOrganisation();
    }, []);

    // const getUserData = () => {
    //     fakeData.fakeAuthService.getUserData().then(resp => {
    //         setUsers(resp.data);
    //     });
    // }


    const getOrganisation = async () => {
        try {
            const response = await axios.get('http://172.16.1.54:9090/users/api/v1.0/organizations'); // Replace the URL with your API endpoint
            console.log("response of api", response)
            const data = response.data.data.map((x) => { return x.name })
            setorg(data);
        } catch (error) {
            console.error('Error fetching data:', error);
        }
        

        };
        const handleOptionChange = (e) => {
            setSelectedOption(e.value);
    }

        const validationSchema = Yup.object({
            firstName: Yup.string().required('First name is required'),
            lastName: Yup.string().required('Last name is required'),
            organisation: Yup.string().required('Organisation is required'),
            email: Yup.string().email('Invalid email format').required('Email is required'),
            phone: Yup.string().required('Phone number is required'),
            jobTitle: Yup.string().required('Job title is required'),
        });
        const handleEditClick = () => {
            <FileUpload
                id="profileImage"
                name="profileImage"
                mode="basic"
                accept="image/*"
                customUpload={false}
            />
        };

        const handleSubmit = (values) => {
            console.log('Form values:', values);
            // Perform form submission logic here
        };

        return (
            <form onSubmit={handleSubmit} className="p-fluid">
                <div className="user-form" style={{ width: '400px' }}>
                    <div>
                        <div className="form-group" >
                            <div className="image-container" >
                                <div className="image-wrapper" style={{ marginLeft: '150px' }}>
                                    <img style={{ height: '80px', width: '80px', background: 'smokewhite' }}
                                        src={`assets/images/user/users.png`}
                                        alt="User-Profile"
                                        className="profile-image"
                                    />
                                </div>
                            </div>
                        </div>
                    </div>
                    <div style={{ display: 'flex' }}>
                        <div className="form-group" style={{ marginTop: "10px" }}>
                            <label htmlFor="user-email">First Name</label>
                            <InputText style={{ backgroundColor: 'whitesmoke' }} id="user-email" />
                        </div>
                        <div className="form-group" style={{ marginTop: "10px", marginLeft: '10px' }}>
                            <label htmlFor="user-password">Last Name</label>
                            <InputText style={{ backgroundColor: 'whitesmoke' }} id="user-password" />
                        </div>
                    </div>

                    <div className="form-group" style={{ marginTop: "10px" }}>
                        <label htmlFor="dropdown">Select an option:</label>
                        <Dropdown style={{ backgroundColor: 'whitesmoke' }} id="organisation" options={org}
                            value={selectedOption}
                            onChange={handleOptionChange} placeholder="Select" />
                    </div>

                    <div className="form-group" style={{ marginTop: "10px" }}>
                        <label htmlFor="user-email">User e-mail</label>
                        <InputText style={{ backgroundColor: 'whitesmoke' }} id="user-email" />
                    </div>
                    <div className="form-group" style={{ marginTop: "10px" }}>
                        <label htmlFor="user-password">Phone</label>
                        <InputText style={{ backgroundColor: 'whitesmoke' }} id="user-password" />
                    </div>
                    <div className="form-group" style={{ marginTop: "10px" }}>
                        <label htmlFor="user-email">Job Title</label>
                        <InputText style={{ backgroundColor: 'whitesmoke' }} id="user-email" />
                    </div>

                    <Button style={{ marginTop: '20px' }} label="Add Contact" />
                </div>

            </form>
        );
    }

    export default AddContact;