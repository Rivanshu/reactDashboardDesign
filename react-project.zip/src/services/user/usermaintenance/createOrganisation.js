import React from 'react';
import { Formik, Form, Field, ErrorMessage } from 'formik';
import { useState, useEffect } from 'react';
import * as Yup from 'yup';
import { InputText } from 'primereact/inputtext';
import axios from 'axios';
import { Button } from 'primereact/button';
import { Dropdown } from 'primereact/dropdown';
import 'primeicons/primeicons.css';
import userservice from "../../services/usermaintenance/userservice";
// import { fakeData } from '../../services';
import { FileUpload } from 'primereact/fileupload';
import { InputTextarea } from 'primereact/inputtextarea';

const CreateOrganisation = () => {
    const initialValues = {
        firstName: '',
        lastName: '',
        organisation: '',
        email: '',
        phone: '',
        jobTitle: '',
        profileImage: null,
    };
    const [users, setUsers] = useState([])
    const [org, setorg] = useState({})
    
    const [selectedCity1, setSelectedCity1] = useState(null);
    const [selectedstate, setSelectedState] = useState(null);
    const [selectedcountry, setSelectedCountry] = useState(null);



    const cities = [
        { name: 'New York', code: 'NY' },
        { name: 'Rome', code: 'RM' },
        { name: 'London', code: 'LDN' },
        { name: 'Istanbul', code: 'IST' },
        { name: 'Paris', code: 'PRS' }
    ];

    const countries = [
        { name: 'Australia', code: 'AU' },
        { name: 'Brazil', code: 'BR' },
        { name: 'China', code: 'CN' },
        { name: 'Egypt', code: 'EG' },
        { name: 'France', code: 'FR' },
        { name: 'Germany', code: 'DE' },
        { name: 'India', code: 'IN' },
        { name: 'Japan', code: 'JP' },
        { name: 'Spain', code: 'ES' },
        { name: 'United States', code: 'US' }
    ];
    const statesforcity = [
        { name: 'Australia', code: 'AU' },
        { name: 'Brazil', code: 'BR' },
        { name: 'China', code: 'CN' },
        { name: 'Egypt', code: 'EG' },
        { name: 'France', code: 'FR' },
        { name: 'Germany', code: 'DE' },
        { name: 'India', code: 'IN' },
        { name: 'Japan', code: 'JP' },
        { name: 'Spain', code: 'ES' },
        { name: 'United States', code: 'US' }
    ];

    const [selectedOption, setSelectedOption] = useState();


    useEffect(() => {
   //     getUserData();
        getOrganisation();
    }, []);

    // const getUserData = () => {
    //     fakeData.fakeAuthService.getUserData().then(resp => {
    //         setUsers(resp.data);
    //     });
    // }

    const onCityChange = (e) => {
        setSelectedCity1(e.value);
    }
    const onStateChange = (e) => {
        setSelectedState(e.value);
    }
    const onCountryChange = (e) => {
        setSelectedCountry(e.value);
    }


    const fetchData = async () => {
        try {
          const response = await axios.get('http://172.16.1.54:9090/users/api/v1.0/organizations'); // Replace the URL with your API endpoint
          console.log("response of api", response)
          const data= response.data.data.map((x)=>{return x.name}) 
          setorg(data);
        } catch (error) {
          console.error('Error fetching data:', error);
        }
      };
    
    const getOrganisation = async () => {
        fetchData()
            // try {
            //   const response = await fetch('http://172.16.1.54:9090/users/api/v1.0/organizations'); // Replace the URL with your API endpoint
            // console.log("response", response)
            // //   if (!response.ok) {
            // //     throw new Error('Network response was not ok');
            // //   }
            // //   const data = await response.json();
            // //   setorg(data);
            // } catch (error) {
            //   console.error('Error fetching data:', error);
            // }
          
    }


    const handleOptionChange = (e) => {
        setSelectedOption(e.value);

    };

    const validationSchema = Yup.object({
        firstName: Yup.string().required('First name is required'),
        lastName: Yup.string().required('Last name is required'),
        organisation: Yup.string().required('Organisation is required'),
        email: Yup.string().email('Invalid email format').required('Email is required'),
        phone: Yup.string().required('Phone number is required'),
        jobTitle: Yup.string().required('Job title is required'),
    });
    const handleEditClick = () => {
        <FileUpload
            id="profileImage"
            name="profileImage"
            mode="basic"
            accept="image/*"
            customUpload={false}
        />
    };

    const handleSubmit = (values) => {
        console.log('Form values:', values);
        // Perform form submission logic here
    };
    const showOrganisation=()=>{
        console.log('test')
    }

    return (
        <form onSubmit={handleSubmit} className="p-fluid">
            <div className="user-form" style={{ width: '400px' }}>
                <div className="form-group" style={{ marginTop: "10px" }}>
                    <Dropdown style={{backgroundColor:'whitesmoke' }} id="organisation" options={org}
                        value={selectedOption}
                        onChange={handleOptionChange} placeholder="Select Organization" />
                </div>
                <div style={{display:'flex', marginBottom:'0px', backgroundColor:'whitesmoke'}}>
                    <Button icon="pi pi-language" onClick={showOrganisation} style={{marginLeft:'10px', background:'none', color:'black', borderRadius:'40px', borderColor:'white'}}/>
                    <Button icon="pi pi-file-import" onClick={showOrganisation} style={{marginLeft:'10px', background:'none', color:'black', borderRadius:'40px', borderColor:'white'}}/>
                    <Button icon="pi pi-paperclip" onClick={showOrganisation} style={{marginLeft:'10px', background:'none', color:'black', borderRadius:'40px', borderColor:'white'}}/>
                    <Button icon="pi pi-align-right" onClick={showOrganisation} style={{marginLeft:'10px', background:'none', color:'black', borderRadius:'40px', borderColor:'white'}}/>
                    <Button icon="pi pi-align-left" onClick={showOrganisation} style={{marginLeft:'10px', background:'none', color:'black', borderRadius:'40px', borderColor:'white'}}/>
                    <Button icon="pi pi-align-justify" onClick={showOrganisation} style={{marginLeft:'10px', background:'none', color:'black', borderRadius:'40px', borderColor:'white'}}/>
                    <Button icon="pi pi-align-center" onClick={showOrganisation} style={{marginLeft:'10px', background:'none', color:'black', borderRadius:'40px', borderColor:'white'}}/>
                </div>
                <div className="form-group" style={{ marginTop: "0px"}}>
                    <InputTextarea style={{height:'150px', backgroundColor:'whitesmoke' }} id="user-email" placeholder='Description'/>
                </div>
                <div className="form-group" style={{ marginTop: "10px" }}>
                    <Dropdown style={{backgroundColor:'whitesmoke' }} value={selectedcountry} options={countries} onChange={onCountryChange} optionLabel="name" placeholder="Country" />

                </div>
                <div className="form-group" style={{ marginTop: "10px" }}>
                    <Dropdown style={{backgroundColor:'whitesmoke' }} value={selectedstate} options={statesforcity} onChange={onStateChange} optionLabel="name" placeholder="Province/State" />

                </div>
                
                <div className="form-group" style={{ marginTop: "10px" }}>
                    <Dropdown style={{backgroundColor:'whitesmoke' }} value={selectedCity1} options={cities} onChange={onCityChange} optionLabel="name" placeholder="City" />

                </div>
                <div style={{display:'flex' }}>
                <Button style={{ marginTop: '20px', width:'100px' }} label="Save" />
                <Button style={{ marginTop: '20px', marginLeft:'20px' ,  width:'100px', background:'whitesmoke', color:'black', border:'none' }} label="Cancel" />
                </div>

            </div>

        </form>
    );
};

export default CreateOrganisation;
