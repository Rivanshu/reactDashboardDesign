import eucPortalApi from '../../config/properties.js'

class UserService {

    async addUser(data) {
        return Promise.resolve(eucPortalApi.post(`users`, data));
    }

    async getAllUser(page = '1', size = '10') {
        const param = `page=${page}&size=${size}`
        return Promise.resolve(eucPortalApi.get(`users?${param}`));
    }

    async getUserById(id = '') {
        return Promise.resolve(eucPortalApi.get(`users/${id}`));
    }

    async updateUser(data, id = '') {
        return Promise.resolve(eucPortalApi.put(`users/${id}`, data));
    }

    async deleteUser(id = '') {
        return Promise.resolve(eucPortalApi.delete(`users/${id}`));
    }

}

export default new UserService();