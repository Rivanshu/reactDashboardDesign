// import erfApi from "../axios/erfApi";
// import erfRawApi from "../axios/erfApi";


// class EunicaService {

//     async convert(param) {
//         return Promise.resolve(erfRawApi.post(`http://eunica:30600/rest/api/submit-job/eunica2sync`, param));
//     }

//     async getFiles(param) {
//         return Promise.resolve(erfApi.get(`getSource?ext=${param}`));
//     }

//     async getHistory() {
//         return Promise.resolve(erfApi.get(`history`));
//     }
//     async addHistory(param) {
//         return Promise.resolve(erfApi.post(`history`,param));
//     }

//     async updateHistory(param) {
//         return Promise.resolve(erfApi.put(`history`,param));
//     }
// }

// export default EunicaService;
