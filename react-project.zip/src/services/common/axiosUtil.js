
import LocalStorageService from './localstorageservice';
const localStorageService = new LocalStorageService();
const headers = {
    'Accept': 'application/json'
};

const reqHandler = (config) => {
    document.body.classList.add('loading-indicator');
    return config
}

const reqErrorHandler = (error) => {
    console.log("reqErrorHandler", "API Error", error);
    document.body.classList.remove('loading-indicator');
    Promise.reject(error)
}

const resHandler = (response) => {
    document.body.classList.remove('loading-indicator');
    // console.info("resHandler", "API Response", response);
    return response
}

const resErrorHandler = (error) => {
    console.error("resErrorHandler", "API Error", error);
    document.body.classList.remove('loading-indicator');
   
    return Promise.reject(error)
}


export {
    headers, reqErrorHandler, reqHandler, resErrorHandler, resHandler
}