import { BehaviorSubject } from 'rxjs';
import appMenuItems from '../../template/AppMenu'
const loading$ = new BehaviorSubject(false);
const isSidebarVisible = new BehaviorSubject(true);
const menuItems = new BehaviorSubject([]);
const doAttandence = new BehaviorSubject({});

function startLoading() {
  loading$.next(true);
}

function stopLoading() {
  loading$.next(false);
}

const routeChangeHandler = (url) => {
  const m = appMenuItems.map(x => {
    x['active'] = (x.url == url);
    return x;
  });
  menuItems.next(m);
}



export {
  startLoading, stopLoading, routeChangeHandler,
  loading$, isSidebarVisible, menuItems, doAttandence
}
