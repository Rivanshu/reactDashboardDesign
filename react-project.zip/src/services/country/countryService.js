import eucPortalAdminApi from '../../config/properties.js'

class CountryService {

    async addCountry(data) {
        return Promise.resolve(eucPortalAdminApi.post(`countries`, data));
    }

    async getAllCountry(page = '1', size = '10') {
        const param = `page=${page}&size=${size}`
        return Promise.resolve(eucPortalAdminApi.get(`countries?${param}`));
    }

    async getCountryById(id = '') {
        return Promise.resolve(eucPortalAdminApi.get(`countries/${id}`));
    }

    async updateCountry(data, id = '') {
        return Promise.resolve(eucPortalAdminApi.put(`countries/${id}`, data));
    }

    async deleteCountry(id = '') {
        return Promise.resolve(eucPortalAdminApi.delete(`countries/${id}`));
    }

}

export default new CountryService();