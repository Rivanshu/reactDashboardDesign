import eucPortalPipelineApi from "../axios/eunica-pipeline-api";

class PipelineService {

    async addPipeline(data) {
        return Promise.resolve(eucPortalPipelineApi.post(`pipelines`, data));
    }

    async getAllPipeline(page = '1', size = '10') {
        const param = `page=${page}&size=${size}`
        return Promise.resolve(eucPortalPipelineApi.get(`pipelines?${param}`));
    }

    async getPipelineById(id = '') {
        return Promise.resolve(eucPortalPipelineApi.get(`pipelines/${id}`));
    }

    async updatePipeline(data, id = '') {
        return Promise.resolve(eucPortalPipelineApi.put(`pipelines/${id}`, data));
    }

    async deletePipeline(id = '') {
        return Promise.resolve(eucPortalPipelineApi.delete(`pipelines/${id}`));
    }

}

export default new PipelineService();