import eucPortalApi from '../../config/properties.js'

class OrganizationService {

    async addOrganization(data) {
        return Promise.resolve(eucPortalApi.post(`organizations`, data));
    }

    async getAllOrganization(page = '1', size = '10') {
        const param = `page=${page}&size=${size}`
        return Promise.resolve(eucPortalApi.get(`organizations?${param}`));
    }

    async getOrganizationById(id = '') {
        return Promise.resolve(eucPortalApi.get(`organizations/${id}`));
    }

    async updateOrganization(data, id = '') {
        return Promise.resolve(eucPortalApi.put(`organizations/${id}`, data));
    }

    async deleteOrganization(id = '') {
        return Promise.resolve(eucPortalApi.delete(`organizations/${id}`));
    }

}

export default new OrganizationService();