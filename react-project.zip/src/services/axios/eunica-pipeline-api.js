import axios from "axios";
import properties from "../../config/properties";
import { headers, reqErrorHandler, reqHandler, resErrorHandler, resHandler } from "../common/axiosUtil";

const baseUrl = properties.eucPortalPipelineApi;

const eucPortalPipelineApi = axios.create({
    baseURL: baseUrl, headers
});

eucPortalPipelineApi.interceptors.request.use(reqHandler, reqErrorHandler);
eucPortalPipelineApi.interceptors.response.use(resHandler, resErrorHandler);

export default eucPortalPipelineApi;
