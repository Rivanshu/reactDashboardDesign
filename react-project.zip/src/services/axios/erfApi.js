// import axios from "axios";
// import { headers, reqErrorHandler, reqHandler, resErrorHandler, resHandler } from "../common/axiosUtil";
// import properties from '../../config/environmentProperties';

// const erfApi = axios.create({
//     baseURL: properties.currentEnvironment.esspRootUrl + properties.currentEnvironment.esspApi, headers
// });

// erfApi.interceptors.request.use(reqHandler, reqErrorHandler);
// erfApi.interceptors.response.use(resHandler, resErrorHandler);

// export default erfApi;
