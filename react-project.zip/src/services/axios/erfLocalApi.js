import axios from "axios";
import { headers, reqErrorHandler, reqHandler, resErrorHandler, resHandler } from "../common/axiosUtil";

const essLocalApi = axios.create({
    baseURL: "/assets/data", headers
});

essLocalApi.interceptors.request.use(reqHandler, reqErrorHandler);
essLocalApi.interceptors.response.use(resHandler, resErrorHandler);

export default essLocalApi;
