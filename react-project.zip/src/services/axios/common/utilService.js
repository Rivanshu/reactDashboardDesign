import moment from 'moment';
import appProperties from '../../config/appProperties';


const parseDate = (d, format = null) => {
    const dt = new Date(d);
    const frmt = format ? appProperties[format] : appProperties.dateFormat;
    return (moment(dt).format(frmt));
}


const parseDBDate = (d, format = null) => {
    const dt = new Date(d);
    const frmt = format ? appProperties[format] : appProperties.apiDateFormat;
    return (moment(dt).format(frmt));
}

export {
    parseDate, parseDBDate
}