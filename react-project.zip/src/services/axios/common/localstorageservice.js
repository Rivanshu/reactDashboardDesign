
class LocalStorageService {

    getService = () => {

    }

    getAccessToken = () => {
        let token = localStorage.getItem('token');
        if (token && token.includes(' ')) {
            token = token.split(' ')[1];
        }
        return token;
    }

    getRefreshToken() {
        let token = localStorage.getItem('token');
        if (token && token.includes(' ')) {
            token = token.split(' ')[1];
        }
        return token;
    }
}

export default LocalStorageService;