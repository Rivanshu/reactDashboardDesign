import axios from 'axios';
import properties from '../../config/environmentProperties';
import LocalStorageService from './localstorageservice';
import { toast } from 'react-toastify';
const localStorageService = new LocalStorageService();
const headers = {
    'Accept': 'application/json'
};

const reqHandler = (config) => {
    document.body.classList.add('loading-indicator');
    const token = localStorageService.getAccessToken();
    if (token) {
        config.headers['Authorization'] = 'Bearer ' + token
    }
    config.headers['Accept'] = 'application/json';
    config.headers['Content-Type'] = 'application/json';
    // console.info("reqHandler", "API Request", config);
    return config
}

const reqErrorHandler = (error) => {
    // console.log("reqErrorHandler", "API Error", error);
    document.body.classList.remove('loading-indicator');
    Promise.reject(error)
}

const resHandler = (response) => {
    document.body.classList.remove('loading-indicator');
    // console.info("resHandler", "API Response", response);
    return response
}

const resErrorHandler = (error) => {
    console.error("resErrorHandler", "API Error", error);
    document.body.classList.remove('loading-indicator');
    // if (error.response.data) {
    //     toast.error(error.response.data)
    // }
    // const originalRequest = error.config
    // if (
    //     error.response.status === 401 &&
    //     originalRequest.url === properties.esspTokenApi
    // ) {
    //     //   router.push('/login')
    //     return Promise.reject(error)
    // }

    // if (error.response.status === 401 && !originalRequest._retry) {
    //     originalRequest._retry = true
    //     const refreshToken = localStorageService.getRefreshToken()
    //     return axios
    //         .post('/auth/token', {
    //             refresh_token: refreshToken
    //         })
    //         .then(res => {
    //             if (res.status === 201) {
    //                 localStorageService.setToken(res.data)
    //                 axios.defaults.headers.common['Authorization'] =
    //                     'Bearer ' + localStorageService.getAccessToken()
    //                 return axios(originalRequest)
    //             }
    //         })
    // }
    return Promise.reject(error)
}


export {
    headers, reqErrorHandler, reqHandler, resErrorHandler, resHandler
}