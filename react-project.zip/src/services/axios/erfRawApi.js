import axios from "axios";
import { headers, reqErrorHandler, reqHandler, resErrorHandler, resHandler } from "../common/axiosUtil";
import properties from '../../config/environmentProperties';

const erfRawApi = axios.create({
    baseURL: '', headers
});

erfRawApi.interceptors.request.use(reqHandler, reqErrorHandler);
erfRawApi.interceptors.response.use(resHandler, resErrorHandler);

export default erfRawApi;
