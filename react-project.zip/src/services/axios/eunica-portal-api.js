import axios from "axios";
import properties from "../../config/properties";
import { headers, reqErrorHandler, reqHandler, resErrorHandler, resHandler } from "../common/axiosUtil";

const baseUrl = properties.eucPortalApi;

const eucPortalApi = axios.create({
    baseURL: baseUrl, headers
});

eucPortalApi.interceptors.request.use(reqHandler, reqErrorHandler);
eucPortalApi.interceptors.response.use(resHandler, resErrorHandler);

export default eucPortalApi;
