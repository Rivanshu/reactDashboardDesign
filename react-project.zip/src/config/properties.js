const properties = {
    eucBaseUrl: window._env_.API_GATEWAY_BASE_URL,
    eucPortalApi: window._env_.USER_APP_API,
    eucPortalAdminApi: window._env_.ADMIN_APP_API,
    eucPortalPipelineApi: window._env_.PIPELINE_APP_API,
    eucPortalLocationApi: window._env_.LOCATION_APP_API,
    localApi:window._env_.LOCAL_HOST_API_,
}
export default properties