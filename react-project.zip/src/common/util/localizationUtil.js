
const getLocalizationResource = () => {
    const _labels = require('../../localization/labels.json');
    const _messages = require('../../localization/messages.json');
    return (Object.assign(_labels, _messages))
}

const getDemoLocalizationResource = () => {
    return {}
}

export {
    getLocalizationResource, getDemoLocalizationResource
}

