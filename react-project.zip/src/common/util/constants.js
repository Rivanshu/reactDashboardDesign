export const notificationType = {
    TIMESHEET: 0,
    ALLOCATION: 1,
    LEAVE: 2,
    PAYROLL: 3,
    USER: 4,
    OTHERS: 5
};