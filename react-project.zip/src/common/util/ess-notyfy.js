import { notify } from "../../services/store/states";

const showNotify = (options) => {
    notify.next(options);
}

export default showNotify;