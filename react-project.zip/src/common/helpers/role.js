
const getFilteredMenusByRole = (menus = []) => {
    const result = [];
    let userRole = [];
    try {
        userRole = JSON.parse(localStorage.getItem('roles'))
    } catch (error) {
        console.log("Error on reading roles", error);
        userRole = [];
    }
    for (let m of menus) {
        if (m.roles && Array.isArray(m.roles)) {
            let hasRole = false;
            for (let p of m.roles) {
                if (Array.isArray(userRole) && userRole.includes(p) == true) {
                    hasRole = true;
                    break;
                }
            }
            if (hasRole) result.push(m)
        } else {
            result.push(m)
        }
    }
    return result;
}

const getFilteredOptionsByRole = (options = []) => {
    const result = [];
    let userRoles = [];
    try {
        userRoles = JSON.parse(localStorage.getItem('roles'))
    } catch (error) {
        console.log("Error on reading roles", error);
        userRoles = [];
    }
    for (let m of options) {
        if (m.roles && Array.isArray(m.roles)) {
            let hasRole = false;
            for (let p of m.roles) {
                if (userRoles.includes(p) == true) {
                    hasRole = true;
                    break;
                }
            }
            if (hasRole) result.push(m)
            if (m.roles.length == 0) result.push(m)
        } else {
            result.push(m)
        }
    }
    return result;
}

export { getFilteredMenusByRole, getFilteredOptionsByRole }