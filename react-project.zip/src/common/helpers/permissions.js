
const getFilteredMenus = (menus = []) => {
    const result = [];
    let userPermissions = [];
    try {
        userPermissions = JSON.parse(localStorage.getItem('permissions'))
    } catch (error) {
        console.log("Error on reading permission", error);
        userPermissions = [];
    }
    for (let m of menus) {
        if (m.permissions && Array.isArray(m.permissions)) {
            let hasPermission = false;
            for (let p of m.permissions) {
                if (Array.isArray(userPermissions) && userPermissions.includes(p) == true) {
                    hasPermission = true;
                    break;
                }
            }
            if (hasPermission) result.push(m)
        } else {
            result.push(m)
        }
    }
    return result;
}

const getFilteredOptions = (options = []) => {
    const result = [];
    let userPermissions = [];
    try {
        userPermissions = JSON.parse(localStorage.getItem('permissions'))
    } catch (error) {
        console.log("Error on reading permission", error);
        userPermissions = [];
    }
    for (let m of options) {
        if (m.permissions && Array.isArray(m.permissions)) {
            let hasPermission = false;
            for (let p of m.permissions) {
                if (userPermissions.includes(p) == true) {
                    hasPermission = true;
                    break;
                }
            }
            if (hasPermission) result.push(m)
            if (m.permissions.length == 0) result.push(m)
        } else {
            result.push(m)
        }
    }
    return result;
}

export { getFilteredMenus, getFilteredOptions }