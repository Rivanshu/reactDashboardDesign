import { BrowserRouter as Router, Routes, Route, useNavigate } from 'react-router-dom';
import UserLogin from '../src/pages/loginpage/user-login';
import Pipeline from '../src/pages/pipeline/pipeline'; // Replace with your Dashboard component
import { classNames } from 'primereact/utils';
import { loading$, isSidebarVisible } from "../src/services/common/states";
import UserMaintenance from '../src/pages/usermaintenance/usermaintenance';
import MenuBar from './pages/menubar/menubar';
import Source from './pages/source/source';
import AppToolbar from '../src/pages/apptoolbar/apptoolbar';
import React, { Fragment, useEffect, useState } from "react";
import CreatePipeline from './pages/pipeline/create-pipeline';
import CreateNewPipeline from './pages/newPipeline/create-new-pipeline';
import Dashboard from './pages/dashboard/dashboard';
import Destination from './pages/destination/destination';
import AddNewOrganization from './pages/addOrganization/addOrganization';
import AddNew from './pages/addnew/addnew';
// import ProgressSpinner from "../components/spinner/progressSpinner";
// import Notify from "../components/notify/notify";
// import { loading$, isSidebarVisible } from "../services/common/states";
// import AppFooter from "./AppFooter";
// import AppRoutes from './AppRoutes';
// import AppSidebar from './AppSidebar';


const App = () => {

  const [menuVisible, setMenuVisible] = useState(true);
  const [processClass, setProcessClass] = useState('hide-spinner');

  useEffect(() => {
    loading$.subscribe(v => setProcessClass(v ? 'show-spinner' : 'hide-spinner'));
    isSidebarVisible.subscribe(v => setMenuVisible(v));
  }, [])

  const navigate = useNavigate;
  const [sideMenuVisible, setSideMenuVisible] = useState(true);

  const handleSideMenuToggle = () => {
    setSideMenuVisible(!sideMenuVisible);
  };


  return (
    <Router>
      <div className="app-container" style={{ position: 'fixed', top: 0, left: 0, right: 0, bottom: 0 }}>
        <div>
        
          <div > <AppToolbar /></div>
        </div>

        <div style={{ display: 'flex', height: '100%' }}>
          <div style={{ background: 'white', width: '60px' }}>
            <MenuBar/>
          </div>
          <div className="content-container" style={{ }}>
            <Routes>
              <Route path="/" element={<UserLogin />} />
              <Route path="/dashboard" element={<Dashboard />} />
              <Route path="/pipeline" element={<Pipeline />} />
              <Route path="/create-pipeline" element={<CreatePipeline />} />
              <Route path="/usermaintenance" element={<UserMaintenance />} />
              <Route path="/create-new-pipeline" element={<CreateNewPipeline />} />
              <Route path="/source" element={<Source />} />
              <Route path="/destination" element={<Destination />} />
              <Route path="/addorganisation" element={<AddNewOrganization />} />
              <Route path="/adduser" element={<AddNew />} />

            </Routes>
          </div>
        </div>
      </div>
    </Router>
  );
};

export default App;