const https = require('https');
const fs = require('fs');
const app = require ('express')
const port = 443;

const options = {
  cert: fs.readFileSync('./eunica.crt'),
  key: fs.readFileSync('./eunica.p12'),
};

const server = https.createServer(options, app);

server.listen(port, () => {
  console.log(`Server running on port ${port}`);
});