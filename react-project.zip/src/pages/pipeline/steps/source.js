import React, { useState } from 'react';
import { DataView, DataViewLayoutOptions } from 'primereact/dataview';
import { Avatar } from 'primereact/avatar';
import "../style.scss";
function Source({ formats, onSelection }) {
    const [layout, setLayout] = useState('grid');
    // const [sortKey, setSortKey] = useState(null);
    // const [sortOrder, setSortOrder] = useState(null);
    // const [sortField, setSortField] = useState(null);
    // const sortOptions = [
    //     { label: 'Price High to Low', value: '!price' },
    //     { label: 'Price Low to High', value: 'price' },
    // ];
    // const onSortChange = (event) => {
    //     const value = event.value;
    //     if (value.indexOf('!') === 0) {
    //         setSortOrder(-1);
    //         setSortField(value.substring(1, value.length));
    //         setSortKey(value);
    //     } else {
    //         setSortOrder(1);
    //         setSortField(value);
    //         setSortKey(value);
    //     }
    // };


    const renderHeader = () => {
        return (
            <div className="grid grid-nogutter">
                <div className="col-6" style={{ textAlign: 'left' }}>
                    <h1 className="m-0">Standard Frameworks</h1>
                </div>
                <div className="col-6" style={{ textAlign: 'right' }}>
                    <DataViewLayoutOptions layout={layout} onChange={(e) => setLayout(e.value)} />
                </div>
            </div>
        );
    };

    
    const renderHeaders = () => {
        return (
            <div className="grid grid-nogutter">
                <div className="col-6" style={{ textAlign: 'left' }}>
                    <h1 className="m-0">COTS Products</h1>
                </div>
                {/* <div className="col-6" style={{ textAlign: 'right' }}>
                    <DataViewLayoutOptions layout={layout} onChange={(e) => setLayout(e.value)} />
                </div> */}
            </div>
        );
    };
    const renderHeaderss = () => {
        return (
            <div className="grid grid-nogutter">
                <div className="col-6" style={{ textAlign: 'left' }}>
                    <h1 className="m-0">Core Languages</h1>
                </div>
                {/* <div className="col-6" style={{ textAlign: 'right' }}>
                    <DataViewLayoutOptions layout={layout} onChange={(e) => setLayout(e.value)} />
                </div> */}
            </div>
        );
    };

    const renderListItem = (data) => {
        console.log("list ITEMS ", data)
        return (
            <div className="col-12">
                <div className="list-item grid">
                    <div className="image" style={{ display: 'inline-block' }}>
                        <a href="#" className="link" onClick={() => onSelection('source', data)}>
                            <img src={`/assets/images/formats/${data.image}`}
                                onError={(e) => (e.target.src = '/assets/images/formats/noicon.png')}
                            />
                        </a>
                    </div>
                    <div className="name col-3">
                        <a href="#" className="link text" onClick={() => onSelection('source', data)}>
                            {data.name}
                        </a>
                    </div>
                    <div className="name col text">{data.description}</div>
                </div>
            </div>
        );
    };
    const renderGridItem = (data) => {
        return (
            <div className="gridIcon col-12 md:col-3">
                <div className="grid-item card" style={{ margin: '25px' }}>
                    <div className="grid-item-content">
                       
                            <div className="image" >
                                <a href="#" className="link" onClick={() => onSelection('source', data)}>
                                    <Avatar
                                        image={`/assets/images/formats/${data.image}`}
                                        onError={(e) => (e.target.src = '/assets/images/formats/noicon.png')}
                                        className="mr-2"
                                        size="xlarge"
                                        shape="circle"
                                    />
                                </a>
                            </div>
                        <div className="name">
                            <a href="#" className="link" onClick={() => onSelection('source', data)}>
                                {data.name}
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        );
    };
    const itemTemplate = (product, layout) => {
        if (!product) {
            return;
        }
        if (layout === 'list') return renderListItem(product);
        else if (layout === 'grid') return renderGridItem(product);
    };
    const header = renderHeader();
    const secondHeader = renderHeaders ();
    const thirdHeader =renderHeaderss()
    return (
        <div className="card">
            <DataView value={formats} layout={layout} header={header} itemTemplate={itemTemplate}
                // paginator rows={18} sortOrder={sortOrder} sortField={sortField}
            />
            {/* <DataView value={formats} layout={layout} header={secondHeader} itemTemplate={itemTemplate} 
            // paginator rows={18} sortOrder={sortOrder} sortField={sortField}
            />
             <DataView value={formats} layout={layout} header={thirdHeader} itemTemplate={itemTemplate}
               // paginator rows={18} sortOrder={sortOrder} sortField={sortField}
            /> */}
        </div>
    );
}
export default Source;
