import React from 'react'
import { eunicaService } from '../../../services'
function Result(props) {

    const convertData = () => {
        let payload = {
            inputDir: "C:\\lab\\EUniCA\\QuadientOutput",
            outputDir: "vcs:\\\\",
            icmaddress: "eunica:30353",
            icmuser: "EunicaLogin",
            icmpassword: "••••••"
        }
        eunicaService.convert(payload).then(resp => {
            console.log("Response", resp.data);
        })
    }
    return (
        <div className=''>
            Result
        </div>
    )
}



export default Result
