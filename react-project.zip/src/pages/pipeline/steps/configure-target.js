import React, { useState } from 'react';
import { DataView, DataViewLayoutOptions } from 'primereact/dataview';
import { Dropdown } from 'primereact/dropdown';
import { Rating } from 'primereact/rating';
import { Button } from 'primereact/button';
import { Avatar } from 'primereact/avatar';
import "../style.scss";
import { Panel } from 'primereact/panel';
import { InputText } from 'primereact/inputtext';

const textboxClass = "text-base text-color surface-overlay p-2 border-1 border-solid surface-border border-round appearance-none outline-none focus:border-primary w-full";

function ConfigureTarget({ formats, onSelection, selectedFile, target }) {
    const [layout, setLayout] = useState('grid');
    const [selectedOption, setSelectedOption] = useState(null);
    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');
    const [databaseName, setDatabaseName] = useState('');
    const [apiEndpoint, setApiEndpoint] = useState('');
    const [apiKey, setApiKey] = useState('');
    const [path, setPath] = useState('');
    const [inputEntered, setInputEntered] = useState(false);

    const options = [
        { label: 'Database', value: 'Database' },
        { label: 'API', value: 'API' },
        { label: 'Location', value: 'Location' }
    ];

    const onDropdownChange = (e) => {
        setSelectedOption(e.value);
    };

    const handleInputChange = (event) => {
        const value = event.target.value;
        setInputEntered(value.trim() !== '');
    };

    const handleSubmit = () => {
        if (selectedOption === 'Database') {
            onSelection('target', {
                username: username,
                password: password,
                databaseName: databaseName
            });
        } else if (selectedOption === 'API') {
            onSelection('target', {
                apiEndpoint: apiEndpoint,
                apiKey: apiKey
            });
        } else if (selectedOption === 'Location') {
            onSelection('target', {
                path: path
            });
        }
    };


    return (
        <div className="card">
            <Panel className="exe-card" header="Conversion">
                <div className="center-content">
                    <div className="p-grid p-nogutter">
                        <div className="p-col-12 p-md-6">
                            <div style={{ display: 'flex', alignItems: 'center' }}>
                                <h2 style={{ textAlign: 'center', marginRight: '10px' }}>Selected Format: {selectedFile}</h2>
                                <img src={"\\assets\\images\\formats\\" + target.imageW} style={{ width: '40px' }} />
                            </div>
                        </div>
                        <div className="p-col-12 p-md-6">
                            <h3 style={{ textAlign: 'center' }}>Select Target Type:</h3>
                            <Dropdown
                                value={selectedOption}
                                options={options}
                                onChange={onDropdownChange}
                                placeholder="Select"
                                className={textboxClass}
                                style={{ width: '200px'}}
                            />
                        </div>
                    </div>
                </div>
                {selectedOption === 'Database' && (
                    <div className="p-grid p-nogutter mt-4">
                        <div className="p-col-12">
                            <h3>Database Configuration:</h3>
                            <div className="formgrid grid">
                                <div className="field col">
                                    <label htmlFor="username">Username</label>
                                    <InputText id="username" type="text" onChange={handleInputChange} className={textboxClass} />
                                </div>
                                <div className="field col">
                                    <label htmlFor="password">Password</label>
                                    <InputText id="password" type="password" onChange={handleInputChange} className={textboxClass} />
                                </div>
                                <div className="field col">
                                    <label htmlFor="databaseName">Database Name</label>
                                    <InputText id="databaseName" type="text" onChange={handleInputChange} className={textboxClass} />
                                </div>
                            </div>
                        </div>
                    </div>
                )}
                {selectedOption === 'API' && (
                    <div className="p-grid p-nogutter mt-4">
                        <div className="p-col-12">
                            <h3>API Configuration:</h3>
                            <div className="formgrid grid">
                                <div className="field col">
                                    <label htmlFor="apiEndpoint">API Endpoint</label>
                                    <InputText id="apiEndpoint" type="text" onChange={handleInputChange} className={textboxClass} />
                                </div>
                                <div className="field col">
                                    <label htmlFor="apiKey">API Key</label>
                                    <InputText id="apiKey" type="text" onChange={handleInputChange} className={textboxClass} />
                                </div>
                            </div>
                        </div>
                    </div>
                )}
                {selectedOption === 'Location' && (
                    <div className="p-grid p-nogutter mt-4">
                        <div className="p-col-12">
                            <h3>Location Configuration:</h3>
                            <div className="formgrid grid">
                                <div className="field col-6">
                                    <label htmlFor="path">Location path</label>
                                    <InputText id="path" type="text" onChange={handleInputChange} className={textboxClass} />
                                </div>
                            </div>
                        </div>
                    </div>
                )}

                <div className="p-grid p-nogutter mt-4">
                    <div className="p-col-12">
                        {selectedOption && (
                            <Button
                                label="Submit"
                                disabled={!inputEntered}
                                className="p-button-primary"
                                style={{ width: '120px' }}
                                onClick={handleSubmit}
                            />
                        )}
                    </div>
                </div>
            </Panel>
        </div>
    );
}



export default ConfigureTarget;
