import React, { useEffect, useState, useRef } from 'react';
import { useNavigate } from "react-router-dom";
import { Button } from 'primereact/button';
import { Panel } from 'primereact/panel';
import { DataTable } from 'primereact/datatable';
import { useLocation } from 'react-router-dom';
import { Column } from 'primereact/column';
import { fakeData, eunicaService } from '../../services';
import { Menu } from 'primereact/menu';
import moment from 'moment';
import Execution from './steps/execution';
import { actionMenu } from './helper';
import "../style.scss";
import { classNames } from 'primereact/utils';
import { PrimeIcons } from 'primereact/api';

function Pipeline() {
    const menu = useRef(null);
    const [pipelines, setPipelines] = useState([]);
    const [formats, setFormats] = useState([]);
    const navigate = useNavigate();
    
const location = useLocation();
const apiResponse = location.state?.response;
    useEffect(() => {
        getFormat();
       
    }, [])

    useEffect(()=>{
        if(apiResponse==='pass' || apiResponse==='fail'){
            getFormat()
        }
    },[apiResponse])


    const getHistory = (format) => {
        eunicaService.getHistory().then(resp => {
            let data = resp.data;
          
            data.sort((a, b) => parseFloat(b.id) - parseFloat(a.id))

            const history = data.map(x => {
                let obj = {
                    ...x,
                    source: format.find(e => { return e.id == x.sourceId }),
                    target: format.find(e => { return e.id == x.targetId }),
                };
                return obj;
            })
            setPipelines(history);
        })
       
    }
 

    const getFormat = () => {
        // fakeData.fakeAuthService.getFormat().then(resp => {
        //     setFormats(resp.data);
        //     getHistory(resp.data)
        // })
    }

   
    const item = (rowData, options) => {
        const d = rowData[options.field];
        let end = moment(new Date(rowData.end));
        var duration = moment.duration(end.diff(new Date(rowData.started)));
        var hours = duration.asMinutes().toFixed(2);
       
        return (
            <div className='grid'>
                <div className='' style={{ display: 'inline-block' }}>
                    <img src={`/assets/images/formats/${d.imageW}`} style={{ height: '50px' }} />
                </div>
                <div className='col' style={{ textAlign: 'left' }}>
                    <div><strong>{d.name}</strong></div>
                    <div><strong>
                        <span className='disabled'>{d.description}</span>
                        {options.field == 'source' && <span>Time taken: {hours} minutes</span>}
                    </strong></div>
                </div>
            </div>
        )
    }
    
    const statusBody = (rowData) => {
        let cname = 'secondary';
        switch (rowData.status) {
            case 'completed': cname = 'success'; break;
            case 'in-progress': cname = 'warning'; break;
            case 'blocked': cname = 'secondary'; break;
            case 'error': cname = 'danger'; break;
            default: cname = 'secondary'
        }
        return (<strong className={'p-button p-button-' + cname} style={{ display: 'block' }}>{rowData.status}</strong>)
    }
    const actionBody = (rowData) => {
        return (<>
            <Menu model={actionMenu} popup ref={menu} id={"popup_menu" + rowData.id} />
            <Button className="p-button-rounded p-button-text" icon="pi pi-ellipsis-v"
                onClick={(event) => menu.current.toggle(event)}
                aria-controls={"popup_menu" + rowData.id} aria-haspopup />
        </>)
    }

    // Generate a random color
    const getRandomColor = () => {
        const letters = '0123456789ABCDEF';
        let color = '#';
        for (let i = 0; i < 6; i++) {
            color += letters[Math.floor(Math.random() * 16)];
        }
        return color;
    };

    return (
        <div>
            <Panel>
                <Button label="New Conversion" iconPos="right" onClick={() => navigate('/create-pipeline')} />
            </Panel>
            <div className="datatable-templating-demo">
                <div className="card">
                    <DataTable value={pipelines} responsiveLayout="scroll">
                        <Column header="ID" field="id" body={(rowData) => <strong>#{rowData.id}</strong>} />
                        <Column field="source" header="Source" body={item} />
                        <Column
                            body={() => <i className={classNames('pi', 'pi-arrow-right')} style={{ color: 'black', fontSize: '1.5rem', transform: 'scaleX(1.5)', }}></i>}
                        />
                        <Column field="target" header="Target" body={item} />
                        <Column field="status" header="Status" className="capitalize" body={statusBody} headerStyle={{ textAlign: 'center', width: '150px' }} />
                        <Column field="" header="Actions" body={actionBody} />
                    </DataTable>
                </div>
            </div>


        </div>
    )
}

export default Pipeline