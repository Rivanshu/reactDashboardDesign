const items = [
    {
        label: 'Source',
        command: (event) => {
            // toast.current.show({ severity: 'info', summary: 'First Step', detail: event.item.label });
        }
    },
    {
        label: 'Configure Source',
        command: (event) => {
            // toast.current.show({ severity: 'info', summary: 'Second Step', detail: event.item.label });
        }
    },
    {
        label: 'Target',
        command: (event) => {
            // toast.current.show({ severity: 'info', summary: 'Seat Selection', detail: event.item.label });
        }
    },
    {
        label: 'Configure Target',
        command: (event) => {
            // toast.current.show({ severity: 'info', summary: 'Fourth Step', detail: event.item.label });
        }
    },
    {
        label: 'Execution',
        command: (event) => {
            // toast.current.show({ severity: 'info', summary: 'Pay with CC', detail: event.item.label });
        }
    }
    // {
    //     label: 'Result',
    //     command: (event) => {
    //         // toast.current.show({ severity: 'info', summary: 'Last Step', detail: event.item.label });
    //     }
    // }
];

const actionMenu = [
    {
        label: 'Options',
        items: [
            {
                label: 'Update',
                icon: 'pi pi-refresh',
                command: () => {

                }
            },
            {
                label: 'Delete',
                icon: 'pi pi-times',
                command: () => {

                }
            },
            {
                label: 'Download',
                icon: 'pi pi-download',
                command: () => {

                }
            }
        ]
    },
    {
        label: 'Navigate',
        items: [
            {
                label: 'React Website',
                icon: 'pi pi-external-link',
                url: 'https://reactjs.org/'
            },
            {
                label: 'Router',
                icon: 'pi pi-upload',
                command: (e) => {
                    window.location.hash = "/fileupload"
                }
            }
        ]
    }
];
export { items, actionMenu }