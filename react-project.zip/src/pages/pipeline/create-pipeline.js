import React, { useEffect, useState } from 'react';
import { Steps } from 'primereact/steps';
import { Panel } from 'primereact/panel';
import { useNavigate } from "react-router-dom";
import Source from './steps/source';
import Target from './steps/target';
import { Button } from 'primereact/button';
import Execution from './steps/execution';
import Result from './steps/Result';
import ConfigureSource from './steps/configure-source';
import ConfigureTarget from './steps/configure-target';
import { items } from './helper';
import { toast } from 'react-toastify';
import { fakeData } from '../../services';
import "../style.scss";

function CreatePipeline() {
    const [activeIndex, setActiveIndex] = useState(0);
    const [formats, setFormats] = useState([]);
    const [source, setSource] = useState({});
    const [target, setTarget] = useState({});
    const [sourceConfig, setSourceConfig] = useState({});
    const [targetConfig, setTargetConfig] = useState({});
    const navigate = useNavigate();
    useEffect(() => {
        setActiveIndex(0);
        getFormat();
    }, []);

    const getFormat = () => {
        // fakeData.fakeAuthService.getFormat().then(resp => {
        //     setFormats(resp.data);
        // });
    };


    const setFormat = (e, v) => {
        if (e === 'source') {
            setSource(v);
            setActiveIndex(1); // Move to the ConfigureSource step
        } else if (e === 'target') {
            setTarget(v);
            setActiveIndex(3); // Move to the ConfigureTarget step
        }
    };


    const [status, setStatus] = useState()
    const process = e => {
        if (e === 'success') {
            toast.success('Migration success....');
            setStatus('test')
            setActiveIndex(3); // Move to the Result step
        } else {

            setStatus('testfail')
            toast.error('Migration failed....');
        }
    };
    const onSelection = (step, config) => {
        if (step === 'source') {
            setSourceConfig(config);
            setActiveIndex(2); // Move to the Target step
        } else if (step === 'target') {
            setTargetConfig(config);
            setActiveIndex(4); // Move to the Execution step (or the next step after target)
        }
    };

    const handleSelect = (event) => {
        const selectedIndex = event.index;
        if (selectedIndex < activeIndex) {
            setActiveIndex(selectedIndex);
        } else {
            // The user is trying to select an upcoming step, so prevent it
        }
    };

    return (
        <div>
            <Panel>
                <h1 className='m-0'>
                    <Button label="Pipelines" iconPos="right" onClick={() => navigate('/pipeline')} />
                </h1>
            </Panel>
            <div className='e-card' style={{ background: '#fff', marginTop: '10px', paddingTop: '0px 20px', height: 'calc(100vh - 100px)' }}>
                <Steps model={items} activeIndex={activeIndex} onSelect={handleSelect} readOnly={false} />
                <div className='p-4'>
                    {activeIndex === 0 && <Source formats={formats} onSelection={setFormat} />}
                    {activeIndex === 1 && <ConfigureSource formats={formats} onSelection={onSelection} selectedFile={source.name} source={source} />}
                    {activeIndex === 2 && <Target formats={formats} onSelection={setFormat} />}
                    {activeIndex === 3 && <ConfigureTarget formats={formats} onSelection={onSelection} selectedFile={target.name} target={target} />}
                    {activeIndex === 4 && <Execution formats={formats} source={source} target={target} process={process} />}
                    {/* {activeIndex === 5 && <Result formats={formats} source={source} target={target} />} */}
                </div>
            </div>
        </div>
    );
}

export default CreatePipeline;
