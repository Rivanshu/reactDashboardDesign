import React, { useEffect, useState } from 'react';
import { InputText } from 'primereact/inputtext';
import axios from 'axios';
import { Button } from 'primereact/button';
import { useNavigate } from "react-router-dom";
import { useFormik } from 'formik';

const LoginPage = () => {
    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');
    const [responseData, setResponseMessage] = useState();
    const navigate = useNavigate();
    const INIT_FORM_VAL = { email: null, password: null, accept: false }


    const formik = useFormik({
        initialValues: INIT_FORM_VAL,
        validate: (data) => {
            let errors = {};
            return errors;
        },
        onSubmit: (data) => {
            handleFetchData(data);
        }
    });

    function savetoLocalDatabase() {
        localStorage.setItem('useremail', username)
        localStorage.setItem('password', password)
    }

    const isFormFieldValid = (name) => !!(formik.touched[name] && formik.errors[name]);
    const getFormErrorMessage = (name) => {
        return isFormFieldValid(name) && <small className="p-error">{formik.errors[name]}</small>;
    };
    const LoginWrapper = () => {
        return (

            <div className="login-container">
            <h1>Login</h1>
            <div className="login-form">
              <div className="p-field">
                <label htmlFor="username">Username</label>
                <InputText id="username" value={username} onChange={(e) => setUsername(e.target.value)} />
              </div>
              <div className="p-field">
                <label htmlFor="password">Password</label>
                <InputText id="password" type="password" value={password} onChange={(e) => setPassword(e.target.value)} />
              </div>
              <Button label="Login" onClick={handleFetchData} />
            </div>
          </div>



            // <div className="login-wrapper">
            //     <div className="login-form">
            //         <p>
            //             <img className="logo" src="/assets/images/logo.png" />
            //         </p>
            //             <form onSubmit={formik.handleSubmit} className="p-fluid">
            //                 <h3>Welcome</h3>
            //                 <p>Enter your credentials to access your account</p>
            //                 <div className="field">
            //                     <label className={classNames({ 'p-error': isFormFieldValid('tenant') })}>tenant</label>
            //                     <span className="p-float-label p-input-icon-right">
            //                         <i className="pi pi-user" />
            //                         <InputText name="tenant" value={formik.values.tenant} onChange={formik.handleChange}
            //                             className={classNames({ 'p-invalid': isFormFieldValid('tenant') })} placeholder="Enter tenant" />
            //                     </span>
            //                     {getFormErrorMessage('tenant')}
            //                 </div>
            //                 <div className="field">
            //                     <label className={classNames({ 'p-error': isFormFieldValid('email') })}>Email Address/Username</label>
            //                     <span className="p-float-label p-input-icon-right">
            //                         <i className="pi pi-envelope" />
            //                         <InputText name="email" value={formik.values.email} onChange={formik.handleChange}
            //                             className={classNames({ 'p-invalid': isFormFieldValid('email') })} placeholder="Enter your email address/username" />
            //                     </span>
            //                     {getFormErrorMessage('email')}
            //                 </div>
            //                 <div className="field">
            //                     <label className={classNames({ 'p-error': isFormFieldValid('password') })}>Password</label>
            //                     <span className="p-float-label">
            //                         <InputText name="password" value={formik.values.password} onChange={formik.handleChange} toggleMask feedback={false}
            //                             className={classNames({ 'p-invalid': isFormFieldValid('password') })} placeholder="Enter your password" />
            //                     </span>
            //                     {getFormErrorMessage('password')}
            //                 </div>
            //                 <Button type="submit" label="Login" className="mt-2" />
            //             </form>
            //     </div>
            //     <p><small style={{ textTransform: 'uppercase' }}>{'1.0.0'} V {'2.1'}</small></p>
            // </div>
        )
    }

    const handleFetchData = async () => {
        try {
            const requestBody = {
                email: username,
                password: password
            };

            const response = await axios.post('http://172.16.1.54:9090/users/api/v1.0/auth/login', requestBody);

            console.log("resp", response)
            if (response.status === 200) {
                navigate('/usermaintenance')
                savetoLocalDatabase()
            }
            else {
                console.log("you are not the user")
            }
        } catch (error) {
            console.error('Error fetching data:', error);
            setResponseMessage('Error fetching data. Please try again.');
        }
    };

    return (
        <div className="p-grid full-screen lg-screen">
            <div className="p-col-6 banner">
                <div className="image"></div>
                <h1>EUniCA Portal</h1>  
                <p>
                    <em>
                        <small style={{ textTransform: 'uppercase' }}>{'1.2.0'} V {'0'}</small>
                    </em>
                    <small>@2023, Espire Infolab Pvt. Ltd. All Rights Reserved</small>
                </p>
            </div>
            <div className="col-6 login-area">
                {LoginWrapper()}
            </div>
        </div>
    );
};
export default LoginPage;
