// const http = require('http');
// const https = require('https');
// const fs = require('fs');
// const path = require('path');

// const options = {
//   key: fs.readFileSync(path.join('../certfileDS/Eunica-2023-08-14-144434.pkey', 'server.key')),
//   cert: fs.readFileSync(path.join('../certfileDS/Eunica-2023-08-14-144434.cer', 'server.crt'))
// };

// const app = (req, res) => {
//   res.writeHead(200);
//   res.end('Hello, HTTPS World!');
// };

// const httpServer = http.createServer(app);
// const httpsServer = https.createServer(options, app);

// httpServer.listen(80, () => {
//   console.log('HTTP server listening on port 80');
// });

// httpsServer.listen(443, () => {
//   console.log('HTTPS server listening on port 443');
// });
