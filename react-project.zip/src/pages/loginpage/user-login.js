// Login.js

import React from 'react';
import { useState } from 'react';
import { InputText } from 'primereact/inputtext';
import { Password } from 'primereact/password';
import axios from 'axios';
import { Navigate, useNavigate } from 'react-router-dom';
import 'primereact/resources/themes/saga-blue/theme.css';
import 'primereact/resources/primereact.min.css';
import 'primeicons/primeicons.css';
import { Checkbox } from 'primereact/checkbox';
import { Button } from 'primereact/button';
import { useFormik } from 'formik';
import './styles.css';
import loginService from '../../services/login/loginService';

const INIT_FORM_VAL = { email: '', password: '', accept: false };

const UserLogin = () => {
  const formik = useFormik({
    initialValues: INIT_FORM_VAL,
    validate: (data) => {
      let errors = {};

      if (!data.email) {
        errors.email = 'Email/Username is required.';
      }

      if (!data.password) {
        errors.password = 'Password is required.';
      }
      return errors;
    },
    onSubmit: () => {
      handleFetchData();
    },
  });
  const [responseData, setResponseMessage] = useState();


  function savetoLocalDatabase() {
    localStorage.setItem('useremail', formik.values.email)
    localStorage.setItem('password', formik.values.password)
    
  }


  const isFormFieldValid = (fieldName) => { };
  const getFormErrorMessage = (fieldName) => { };
  const navigate = useNavigate()

  const handleFetchData = () => {
    try {
      const requestBody = {
        email: formik.values.email,
        password: formik.values.password
      };
      console.log("...........................", formik.values.email, formik.values.password)
      // const response = await axios.post(eucPortalApi+'auth/login', requestBody);
      loginService.login(requestBody).then(resp => {
        console.log("response of login", resp);
        if (resp.status===200) {
          navigate('/dashboard');
          savetoLocalDatabase();
          localStorage.setItem('userType', resp.data.data.roles.map((x) => {return x.name}))
          const usertype = resp.data.data.roles.map((x) => x.name);
        } else {
          console.log("you are not the user");
        }      })
  
     
    } catch (error) {
      console.error('Error fetching data:', error);
      setResponseMessage('Error fetching data. Please try again.');
    }
  };
  

  return (
    <div className="login-container">
      <div className="left-partition" style={{ marginBottom: '150px' }}>
        <div className="banner-image"></div>
        <div className="text-below-banner">
          <h1>EUniCA</h1>
          <p>
            <em>
              <small style={{ textTransform: 'uppercase' }}>1.2.0 V 1.0.0</small>
            </em>
            <br />
            <small>@2023, Espire Infolab Pvt. Ltd. All Rights Reserved</small>
          </p>
        </div>
      </div>
      <div className="right-partition" style={{ marginBottom: '150px' }}>
        <div className="login-card">
          <p>
            <img className="logo-image" src="/assets/images/logo.png" />
          </p>
          <div className="login-form">
            <form onSubmit={formik.handleSubmit} className="p-fluid">
              <div className="login-form-content">
                <h3>Welcome</h3>
                <p style={{ marginTop: '20px', marginBottom: '30px' }}>Enter your credentials to access your account</p>
              </div>
              <div className="field">
                <label className={isFormFieldValid('email') ? 'p-error' : ''}>Email Address/Username</label>
                <span className="p-float-label p-input-icon-right">
                  <i className="pi pi-envelope" />
                  <InputText
                    name="email"
                    value={formik.values.email}
                    onChange={formik.handleChange}
                    className={isFormFieldValid('email') ? 'p-invalid' : ''}
                    placeholder="Enter your email address/username"
                  />
                </span>
                {getFormErrorMessage('email')}
              </div>
              <div className="field">
                <label className={isFormFieldValid('password') ? 'p-error' : ''}>Password</label>
                <span className="p-float-label">
                  <Password
                    name="password"
                    value={formik.values.password}
                    onChange={formik.handleChange}
                    toggleMask
                    feedback={false}
                    className={isFormFieldValid('password') ? 'p-invalid' : ''}
                    placeholder="Enter your password"
                  />
                </span>
                {getFormErrorMessage('password')}
              </div>

              <div className="field-checkbox">
                <Checkbox
                  inputId="accept"
                  name="accept"
                  checked={formik.values.accept}
                  onChange={formik.handleChange}
                  className={isFormFieldValid('accept') ? 'p-invalid' : ''}
                />
                <label htmlFor="accept" className={isFormFieldValid('accept') ? 'p-error' : ''}>
                  Remember me
                </label>
              </div>

              <Button type="submit" label="Login" className="mt-2" />
            </form>
          </div>
        </div>
      </div>
    </div>
  );
};

export default UserLogin;
