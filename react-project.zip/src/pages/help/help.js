import React from 'react';
import { Button } from 'primereact/button';
import { Accordion, AccordionTab } from 'primereact/accordion';

function SupportPage() {
  const handleCallButtonClick = (phoneNumber) => {
    alert("Call Active")
    // Logic to handle call button click
    // You can pass the phoneNumber as an argument or use it to look up the corresponding action
  };

  return (
    <div className="support-page" style={{marginLeft:'20px'}}>
      <h1 className="support-title">Happy to help you !</h1>

      <Accordion multiple>
        <AccordionTab header="Contact Information">
          <div className="contact-info">
            <h4>General Inquiries</h4>
            <p>Email: info@espire.com</p>
            <p>Phone: +133-446-7390</p>
            <Button
              label="Call General Support"
              className="call-button"
              icon="pi pi-phone"
              onClick={() => handleCallButtonClick('+11234567890')}
            />
          </div>

          <div className="contact-info">
            <h4>Technical Support</h4>
            <p>Email: support@espire.com</p>
            <p>Phone: +1287-6543-3210</p>
            <Button
              label="Call Technical Support"
              className="call-button"
              icon="pi pi-phone"
              onClick={() => handleCallButtonClick('+19876543210')}
            />
          </div>
        </AccordionTab>

        <AccordionTab header="Frequently Asked Questions">
          <div className="faq-item">
            <h3>Question: What dashboard represents ?</h3>
            <p>Answer: Dashboard represents the pictorial representaion of the conversion data </p>
          </div>
          <div className="faq-item">
            <h3>Question: How to make a new conversion ?</h3>
            <p>Answer: After login, click on Migration Pipe tab and tap on new conversion button top of the page.</p>
          </div>
          {/* Add more FAQ items as needed */}
        </AccordionTab>
      </Accordion>
    </div>
  );
}

export default SupportPage;
