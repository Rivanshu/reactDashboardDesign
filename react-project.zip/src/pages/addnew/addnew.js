import React from 'react';
import { Formik, Form, Field, ErrorMessage } from 'formik';
import { useState, useEffect } from 'react';
import * as Yup from 'yup';
import { InputText } from 'primereact/inputtext';
import { Button } from 'primereact/button';
import { Dialog } from 'primereact/dialog';

import { Dropdown } from 'primereact/dropdown';
 //import userservice from "../../services/usermaintenance/userservice";
import { FileUpload } from 'primereact/fileupload';

const AddNew = () => {
    const initialValues = {
        firstName: '',
        lastName: '',
        organisation: '',
        email: '',
        phone: '',
        jobTitle: '',
        profileImage: null,
    };
    const [users, setUsers] = useState([])
    const [org, setorg] = useState({})

    const [selectedOption, setSelectedOption] = useState()
  
  
    // useEffect(() => {
    //     getUserData();
    //     getOrganisation();
    // }, []);

    // const getUserData = () => {
    //     fakeData.fakeAuthService.getUserData().then(resp => {
    //         setUsers(resp.data);
    //     });
    // }

    // const getOrganisation = () => {

    //     userservice.addOrganisation().then((resp) => {
    //         const data= resp.data.data.map((x)=>{return x.name})
    //         setorg(data)
    //     })
    //   }
    //   const handleOptionChange = (e) => {
    //     setSelectedOption(e.value);
    
    //   };

    const validationSchema = Yup.object({
        firstName: Yup.string().required('First name is required'),
        lastName: Yup.string().required('Last name is required'),
        organisation: Yup.string().required('Organisation is required'),
        email: Yup.string().email('Invalid email format').required('Email is required'),
        phone: Yup.string().required('Phone number is required'),
        jobTitle: Yup.string().required('Job title is required'),
    });
    const handleEditClick = () => {
        <FileUpload
            id="profileImage"
            name="profileImage"
            mode="basic"
            accept="image/*"
            customUpload={false}
        />
    };

    const handleSubmit = (values) => {
        console.log('Form values:', values);
        // Perform form submission logic here
    };

    return (
        <form onSubmit={handleSubmit} className="p-fluid">
            <div className="user-form" style={{ width: '400px' }}>
                <div>
                    <div className="form-group" >
                        <div className="image-container" >
                            <div className="image-wrapper" style={{ marginLeft: '150px' }}>
                                <img style={{ height: '80px', width: '80px', background: 'smokewhite' }}
                                    src={`assets/images/user/users.png`}
                                    alt="User-Profile"
                                    className="profile-image"
                                />
                            </div>
                        </div>
                    </div>
                </div>
                <div style={{ display: 'flex' }}>
                    <div className="form-group" style={{ marginTop: "10px" }}>
                        <label htmlFor="user-email">First Name</label>
                        <InputText style={{backgroundColor:'whitesmoke' }} id="user-email" />
                    </div>
                    <div className="form-group" style={{ marginTop: "10px", marginLeft: '10px' }}>
                        <label htmlFor="user-password">Last Name</label>
                        <InputText style={{backgroundColor:'whitesmoke' }} id="user-password" />
                    </div>
                </div>

                <div className="form-group" style={{ marginTop: "10px" }}>
                    <label htmlFor="dropdown">Select an option:</label>
                    <Dropdown style={{backgroundColor:'whitesmoke' }} id="organisation" options={org}
                        value={selectedOption}
                      placeholder="Select" />
                </div>
                
                <div className="form-group" style={{ marginTop: "10px" }}>
                    <label htmlFor="user-email">User e-mail</label>
                    <InputText style={{backgroundColor:'whitesmoke' }} id="user-email" />
                </div>
                <div className="form-group" style={{ marginTop: "10px" }}>
                    <label htmlFor="user-password">Phone</label>
                    <InputText style={{backgroundColor:'whitesmoke' }} id="user-password" />
                </div>
                <div className="form-group" style={{ marginTop: "10px" }}>
                    <label htmlFor="user-email">Job Title</label>
                    <InputText style={{backgroundColor:'whitesmoke' }} id="user-email" />
                </div>

                <Button style={{ marginTop: '20px' }} label="Add Contact" />
            </div>

        </form>
    );
};

function AddNewOrganization() {
  const [userName, setUserName] = useState('');
  const [email, setEmail] = useState('');
  const [visible, setVisible] = useState(false);

  const [showUserInfoForm, setShowUserInfoForm] = useState(false);

  const showDialog = () => {
      setVisible(true);
  };

  const hideDialog = () => {
      setVisible(false);
  };

  const handleToggleOrganizationInfoForm = () => {
      showDialog();
  };

  return (
      <div style={{ marginLeft: '20px' }} >
          <div style={{display:'flex', marginBottom:'20px', marginTop:'20px'}}></div>
          <Dialog header="Add New User" visible={visible} onHide={hideDialog}>
              <AddNew />
              {/* <Button label="Close" onClick={hideDialog} /> */}
          </Dialog>
          <Button onClick={handleToggleOrganizationInfoForm} icon="pi pi-plus" style={{ height: '40px', alignItems: 'center', backgroundColor: 'whitesmoke', color: 'blue', border: '2px' }} label="Add new User" className="p-button-raised p-button-rounded" />
      </div>
  );
};

export default AddNewOrganization;
