import React, { useState, useEffect } from 'react';
import { DataView, DataViewLayoutOptions } from 'primereact/dataview';
import { Avatar } from 'primereact/avatar';
import "../style.scss";
import { Card } from 'primereact/card';
import { Button } from 'primereact/button';
import { fakeData } from '../../services';

function NewPipeline({ formats, onSelection }) {
    const [layout, setLayout] = useState('grid');
    const [pipeline, setPipeline] = useState([]);

    useEffect(() => {
        getPipelineData();
    }, []);

    const getPipelineData = () => {
        fakeData.fakeAuthService.getPipelineData().then(resp => {
            setPipeline(resp.data);
        });
    }

    return (
        <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center'}}>
            <div>
                <div style={{ display: 'flex', alignItems: 'center', flexWrap: 'wrap', justifyContent: 'flex-start', gap: '20px' }}>
                    <div style={{ width: '500px', fontFamily: 'Poppins, sans-serif' }}>
                        <h2 style={{ color: '#007BFF' }}>PIPELINES</h2>
                        <h3>Move your data from any source to destination in Near Real-Time</h3>
                        <p>Get data in your destination in near real-time, easily manage schema drift with Auto Mapping, apply transformations and track progress.</p>
                        <Button label="CREATE PIPELINE" icon="pi pi-plus" style={{ backgroundColor: '#007BFF', color: 'white', border: 'none', height: '25px', marginTop: '10px' }} />
                    </div>

                    <div>
                        {pipeline.map((pipeline) => (
                            <div key={pipeline.id} style={{ display: 'flex', flexDirection: 'column', height: '100%', justifyContent: 'center' }}>
                                <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', marginBottom: '10px' }}>
                                    <img style={{ width: '500px', height: '500px', objectFit: 'contain', borderRadius: 'none' }} src={`/assets/images/pipeline/${pipeline.pipelineimage}`} alt="Pipeline" className="avatar-img" />
                                </div>
                            </div>
                        ))}
                    </div>
                </div>
            </div>
        </div >
    );
}

export default NewPipeline;
