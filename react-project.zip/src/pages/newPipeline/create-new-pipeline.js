import React, { useState, useEffect } from 'react';
import { Card } from 'primereact/card';
import { Button } from 'primereact/button';
import { fakeData } from '../../services';
import { Menu } from 'primereact/menu';
import { ProgressBar } from 'primereact/progressbar';
import "../style.scss";
import 'primereact/resources/themes/saga-blue/theme.css';
import 'primereact/resources/primereact.min.css';
import 'primeicons/primeicons.css';
import pipelineService from '../../services/pipeline/pipelineService';
import { useNavigate } from 'react-router-dom';

function CreateNewPipeline({ formats, onSelection }) {
    const navigate = useNavigate();
    const [pipeline, setPipeline] = useState([]);
    const [menuItems, setMenuItems] = useState([]);
    const [showMenu, setShowMenu] = useState(null);

    useEffect(() => {
        // fetchData();
        getPipelineData();
    }, []);

    const fetchData = async () => {
        try {
            const response = await fetch('/assets/data/pipe-images.json');
            const jsonData = await response.json();
            console.log("response ", jsonData)
            setPipeline(jsonData);
        } catch (error) {
            console.error('Error fetching data:', error);
        }
    };

    const getPipelineData = () => {
        try {
            pipelineService.getAllPipeline().then(resp => {
                if(resp.status == 200 ){
                    setPipeline(resp?.data?.data);
                }
                
            })
        } catch (error) {
            console.error('Error fetching data:', error);
        }
    };

    const createMenuItems = (pipeline) => [
        {
            label: 'Select',
            icon: 'pi pi-check',
            command: () => onSelection(pipeline)
        },
        // Add more menu items if needed
    ];

    const handleButtonClick = () => {
        navigate('/source');
    };

    return (
        <div style={{backgroundColor:'whitesmoke'}}>
            <div style={{ marginBottom: '10px', textAlign: 'end', marginRight: '5px' }}>
                <Button label="CREATE NEW" style={{ backgroundColor: '#007BFF', color: 'white', border: 'none', height: '30px', marginTop: '20px' }}
                    onClick={handleButtonClick} />
                <p style={{ marginBottom: '5px' }}>
                    Move data between any source and destination
                </p>
            </div>

            <div style={{ display: 'flex', flexWrap: 'wrap', gap: '10px', marginLeft: '80px' }}>
                {pipeline.map((pipeline) => (
                    <Card key={pipeline.id} style={{ width: '260px', height: '260px', marginBottom: '10px' }}>
                        <div style={{ display: 'flex', flexDirection: 'column', height: '100%', justifyContent: 'center' }}>
                            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                                <div style={{ display: 'flex', alignItems: 'center' }}>
                                    <img style={{ width: '30px', height: '30px', objectFit: 'contain', borderRadius: 'none' }} src={`/assets/images/pipeline/pipeline-img.png`} alt="Pipeline" className="avatar-img" />
                                    <div style={{ fontFamily: 'Poppins, sans-serif', marginLeft: '5px', fontSize: '1rem' }}>
                                        <b style={{ display: 'flex' }}>{pipeline.name}</b>
                                        <div style={{ fontSize: '0.8rem', marginTop: '2px' }}>src: excel target</div>
                                    </div>
                                </div>
                                <div className="ellipsis-icon" onClick={(event) => { setShowMenu(pipeline.id); setMenuItems(createMenuItems(pipeline)); }}>
                                    <i className="pi pi-ellipsis-h"></i>
                                </div>
                            </div>
                            <div style={{ fontFamily: 'Poppins, sans-serif', marginBottom: '5px' }}>
                                <div style={{ fontSize: '0.99rem', marginTop: '10px' }}>Lorem ipsum is simply dummy text of the printing and typesetting industry.</div>
                            </div>
                            <div style={{ display: 'flex', flexWrap: 'wrap', justifyContent: 'flex-start', gap: '20px', marginLeft: '45px' }}>
                                <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
                                    <img style={{ width: '40px', height: '40px', objectFit: 'contain', borderRadius: 'none' }} src={`/assets/images/file/${pipeline.source.name}`} alt="Pipeline" className="avatar-img-doc" />
                                </div>
                                <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center' }}>
                                    <i className='pi pi-sign-out' style={{ fontSize: '20px' }} />
                                </div>
                                <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
                                    <img style={{ width: '40px', height: '40px', objectFit: 'contain', borderRadius: 'none' }} src={`/assets/images/file/${pipeline.target.name}`} alt="Pipeline" className="avatar-img-doc" />
                                </div>
                            </div>
                            <div style={{ display: 'flex', flexDirection: 'column', marginTop: '5px' }}>
                                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                                    <label style={{ fontFamily: 'Poppins, sans-serif' }}>Progress</label>
                                    <div style={{ fontFamily: 'Poppins, sans-serif' }}>100 %</div>
                                </div>
                                <ProgressBar style={{ height: '5px', backgroundColor: '#4CAF50', marginTop: '5px' }} mode="determinate" />
                            </div>
                            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: '10px' }}>
                                <div style={{ display: 'flex', alignItems: 'center' }}>
                                    <i className="pi pi-clock" style={{ fontSize: '1rem', marginRight: '5px' }} />
                                    <span style={{ fontFamily: 'Poppins, sans-serif', fontSize: '0.8rem' }}>
                                        {new Date().toLocaleTimeString()} | {new Date().toLocaleDateString()}
                                    </span>
                                </div>
                                <div style={{ display: 'flex', justifyContent: 'flex-end' }}>
                                    <img
                                        style={{ width: '30px', height: '30px', objectFit: 'contain', borderRadius: 'none' }}
                                        src={`/assets/images/user/user6.png`}
                                        alt="Pipeline"
                                        className="avatar-img"
                                    />
                                </div>
                            </div>

                        </div>
                    </Card>
                ))}
                {showMenu !== null && (
                    <Menu
                        model={menuItems}
                        popup
                        onHide={() => { setShowMenu(null); setMenuItems([]); }}
                        ref={(el) => (showMenu !== null ? el && el.show() : null)}
                    />
                )}
            </div>
        </div>
    );
}

export default CreateNewPipeline;
