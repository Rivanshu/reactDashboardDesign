import React, { useState, useEffect } from 'react';
import { DataView, DataViewLayoutOptions } from 'primereact/dataview';
import { Avatar } from 'primereact/avatar';
import "../style.scss";
import { Card } from 'primereact/card';
import { Button } from 'primereact/button';
import { fakeData } from '../../services';
import 'primereact/resources/themes/saga-blue/theme.css';
import 'primereact/resources/primereact.min.css';
import 'primeicons/primeicons.css';
import { Checkbox } from 'primereact/checkbox';
import targetService from '../../services/target/targetService';

function Destination({ formats, onSelection }) {
    const [layout, setLayout] = useState('grid');
    const [file, setFile] = useState([]);

    useEffect(() => {
        getTargetFile();
    }, []);

    const fetchData = async () => {
        try {
            const response = await fetch('/assets/data/file.json'); // Valid path
            const jsonData = await response.json();
            setFile(jsonData);

        } catch (error) {
            console.error('Error fetching data:', error);
        }
    };

    const getTargetFile = () => {
        try {
            targetService.getAllTarget().then(resp => {
                if(resp.status == 200 ){
                    setFile(resp?.data?.data);
                }
            })
        } catch (error) {
            console.error('Error fetching data:', error);
        }
    };

    return (
        <div style={{ margin: 0, padding: 0 }}>
            <div style={{ textAlign: 'center', height: '40px' }}>
                <h3>Select your Destination</h3>
            </div>
            <div style={{ textAlign: 'center', height: '40px', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                <p style={{ display: 'flex', marginRight: '10px', marginBottom: '9px' }}>
                    Select the destination from the list to proceed
                </p>
                <Button label="CREATE NEW" style={{ backgroundColor: '#007BFF', color: 'white', border: 'none', height: '25px', marginTop: '10px' }} />
            </div>

            <div style={{ display: 'flex', flexWrap: 'wrap', marginTop: '20px', justifyContent: 'flex-start', gap: '20px', marginLeft: '100px' }}>
                {file.map((file) => (
                    <Card key={file.id} style={{ border: '1px ', borderRadius: '5px', width: '180px', height: '180px' }}>
                        <div style={{ display: 'flex', flexDirection: 'column', height: '50%', justifyContent: 'center' }}>
                            <div style={{ display: 'flex', alignItems: 'flex-start'}}>
                                <input type="checkbox" onClick={() => onSelection(file)} />
                            </div>
                            <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center' }}>
                                <img style={{ width: '80px', height: '80px', objectFit: 'contain', borderRadius: 'none' }} src={`/assets/images/file/${file.name}`} alt="File" className="avatar-img" />
                            </div>
                            <div style={{ textAlign: 'center', marginTop: '10px' }}>
                                <span className="user-name">{file.description}</span>
                            </div>
                        </div>
                    </Card>
                ))}
            </div>

        </div>
    );
}

export default Destination;
