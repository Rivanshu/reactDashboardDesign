import React from "react";
import { useState, useEffect } from "react";
import { Card } from 'primereact/card';
import { useNavigate } from 'react-router-dom';
import { Avatar } from 'primereact/avatar';
import "../style.scss";
import { Button } from "primereact/button";
import { Splitter, SplitterPanel } from 'primereact/splitter';
import { Dropdown } from 'primereact/dropdown';
import { InputText } from 'primereact/inputtext';
import { InputMask } from 'primereact/inputmask';

import 'primereact/resources/themes/saga-blue/theme.css';
import 'primereact/resources/primereact.min.css';
import 'primeicons/primeicons.css';

import './um.css'
import UserForm from "./userform";


const UserInfoForm = () => {
  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const [description, setDescription] = useState('');
  const [gender, setGender] = useState('');
  { console.log("test panel") }

  const handleSubmit = (e) => {
    e.preventDefault();
    // Perform form submission logic here
    console.log('First Name:', firstName);
    console.log('Last Name:', lastName);
    console.log('Description:', description);
    console.log('Gender:', gender);
    // Reset form fields
    setFirstName('');
    setLastName('');
    setDescription('');
    setGender('');
  };

  return (
    <form onSubmit={handleSubmit} className="p-fluid">
      <div className="p-field" style={{ marginTop: '10px' }}>
        <label htmlFor="firstName">First Name</label>
        <InputText
          id="firstName"
          value={firstName}
          onChange={(e) => setFirstName(e.target.value)}
        />
      </div>
      <div className="p-field" style={{ marginTop: '10px' }}>
        <label htmlFor="lastName">Last Name</label>
        <InputText
          id="lastName"
          value={lastName}
          onChange={(e) => setLastName(e.target.value)}
        />
      </div>
      <div className="p-field" style={{ marginTop: '10px' }}>
        <label htmlFor="description">Description</label>
        <InputText
          id="description"
          value={description}
          onChange={(e) => setDescription(e.target.value)}
        />
      </div>
      <div className="p-field" style={{ marginTop: '10px' }}>
        <label htmlFor="gender">Gender</label>
        <Dropdown
          id="gender"
          options={[
            { label: 'Male', value: 'male' },
            { label: 'Female', value: 'female' },
            { label: 'Other', value: 'other' },
          ]}
          value={gender}
          onChange={(e) => setGender(e.value)}
          placeholder="Select gender"
        />
      </div>
      <div className="p-field" style={{ marginTop: '10px' }}>
        <Button label="Submit" type="submit" />
      </div>
    </form>
  );
};

function UserMaintenance() {
  const [layout, setLayout] = useState('grid');
  const [users, setUsers] = useState([])

  const [showUserInfoForm, setShowUserInfoForm] = useState(false);

  const handleToggleUserInfoForm = () => {
    setShowUserInfoForm(!showUserInfoForm);
  };

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      const response = await fetch('/assets/data/userinfo.json'); 
      const jsonData = await response.json();
      setUsers(jsonData);
      
    } catch (error) {
      console.error('Error fetching data:', error);
    }
  };


  const [showForm, setShowForm] = useState(false);
  const [userData, setUserData] = useState(null);

  return (
    <div style={{ backgroundColor:'whitesmoke', marginLeft: '20px', marginTop:'20px' }} >
      <div style={{ display: 'flex', marginBottom: '10px'}}>
        <h2 style={{ color: '#0066cc', width: '1000px' }}>User Maintenance Page</h2>
      </div>
      <div style={{ display: 'flex', flexWrap: 'wrap', justifyContent: 'flex-start', gap: '20px' }}>
        {users.map((user) => (
          <Card key={user.id} >
            <div style={{ display: "flex", flex: ' 0 0 25%', height: '50px', width: '300px', alignItems: 'center' }} >
              <div style={{ alignItems: 'right' }}>
                <img style={{ height: '50px', width: '50px' }} src={`/assets/images/user/${user.userimage}`} alt="User" className="avatar" />
              </div>
              <div style={{ alignItems: 'left', marginLeft: '10px' }}>
                <span className="user-name"><b>{user.name}</b></span>
                <br />
                <span className="user-email">{user.description}</span>
              </div>
            </div>
          </Card>

        ))}


      </div>
    </div>
  );
};

export default UserMaintenance;