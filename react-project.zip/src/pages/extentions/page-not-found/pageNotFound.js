import React from 'react'
import '../style.css';

function PageNotFound() {
    return (
        <div className="msgLbl">
            <div className="msg-secondary">
                <img src='assets/images/page-not-found.webp' />
                <span>Page Not Found</span>
            </div>
            {/* <div className="msg-primary">
                Page Not Found
            </div> */}
        </div>
    )
}

export default PageNotFound;