import React, { useState } from 'react';
import { useSelector } from 'react-redux';
import { selectUser } from '../../../services/store/userSlice';
import { SplitButton } from 'primereact/splitbutton';
import ContactInfo from './profile_contactInfo';
import ProfileHeading from './profile_heading';
import ProfileSkill from './profile_skills/skill';
import '../../extentions/style.css';
import { Dialog } from 'primereact/dialog';
import './style.css';
import ProfileCertification from './profile_certification/certification';
import ProfileEducation from './profile_education/education';
import ProfileProject from './profile_project/project';
import properties from '../../../config/environmentProperties';
import { professionalService } from '../../../services/profile';
import { useEffect } from 'react';
import { userService } from '../../../services/extensions';

const Profile = () => {
    const user = useSelector(selectUser);
    const [shareDia, setShareDia] = useState(false);
    const [heading, setHeading] = useState([]);
    const [allUsersEmail, setAllUsersEmail] = useState([]);
    // const [resumePath, setResumePath] = useState("");

    const resPath = properties.currentEnvironment.docPath + 'resumes/';
    let count = 0;

    const onShow = () => {
        setShareDia(true);
    }

    useEffect(() => {
        if (count === 0) {
            count++;
        }
    }, []);


    const item = [
        {
            label: 'Download Resume',
            icon: 'pi pi-file-pdf',
            command: () => {
            }
        }
    ];


    return (
        <div className='profile'>
            <h3 className='mb-3 ml-1'>My Profile</h3>
            <div className='col-12'>
                <ContactInfo user={user} />
            </div>
        </div>
    )
}

export default Profile;