import React, { useState, Fragment, useEffect } from "react";
import { useFormik } from "formik";
import { Button } from "primereact/button";
import { AutoComplete } from "primereact/autocomplete";
import { classNames } from "primereact/utils";

const SkillDialogForm = ({ save, onClose, skillData }) => {
  const [filteredSkills, setFilteredSkills] = useState(null);
  const formik = useFormik({
    initialValues: {
      skills: null,
    },
    validate: (data) => {
      let errors = {};
      if (!data.skills) {
        errors.skills = "Skill is required.";
      }
      return errors;
    },
    onSubmit: (data) => {
      save(data);
    },
  });

  const isFormFieldValid = (name) =>
    !!(formik.touched[name] && formik.errors[name]);
  const getFormErrorMessage = (name) => {
    return (
      isFormFieldValid(name) && (
        <small className="p-error">{formik.errors[name]}</small>
      )
    );
  };

  const searchSkill = (event) => {
    setTimeout(() => {
      let _filteredSkills;
      if (!event.query.trim().length) {
        _filteredSkills = [...skillData];
      } else {
        _filteredSkills = skillData.filter((p) => {
          if (p.title !== null) {
            return p.title.toLowerCase().startsWith(event.query.toLowerCase());
          }
        });
      }
      setFilteredSkills(_filteredSkills);
    }, 250);
  };

  const onCloseMethod = () => {
    onClose();
  };

  const myForm = (
    <React.Fragment>
      <form
        onSubmit={formik.handleSubmit}
        className="p-fluid p-grid"
        autoComplete="off"
      >
        <Fragment>
          <span>Skills:</span>
          <div className="p-fluid">
            <AutoComplete
              value={formik.values.skills}
              suggestions={filteredSkills}
              completeMethod={searchSkill}
              field="title"
              name="skills"
              multiple
              virtualScrollerOptions={{ itemSize: 38 }}
              onChange={formik.handleChange}
              placeholder="Enter your area of Expertise/Specialization"
              aria-label="Skills"
              dropdownAriaLabel="Select Skills"
              className={classNames({ 'p-invalid': isFormFieldValid('skills') })}
            />
            {getFormErrorMessage("skills")}
          </div>
        </Fragment>

        <div className="pt-3">
          <div className="grid" style={{ float: "right" }}>
            <div className="mr-2 mt-1">
              <Button
                label="Cancel"
                type="button"
                className="p-button-rounded p-button-secondary"
                onClick={(e) => onCloseMethod(e)}
              />
            </div>
            <div className="mt-1">
              <Button label="Save" type="submit" className="p-button-rounded" />
            </div>
          </div>
        </div>
      </form>
    </React.Fragment>
  );
  return <React.Fragment>{myForm}</React.Fragment>;
};

export default SkillDialogForm;