import React, { Fragment, useState } from "react";
import { Button } from "primereact/button";
import { Dialog } from "primereact/dialog";
import "../../../../template/App.css";
import { Chip } from "primereact/chip";
import { useEffect } from "react";
import { skillService } from "../../../../services/profile";
import SkillDialogForm from "./skill_form";
import { toast } from "react-toastify";
import { confirmDialog } from "primereact/confirmdialog";


function ProfileSkill() {
  const [skillDialog, setSkillDialog] = useState(false);
  const [skillData, setSkillData] = useState([]);
  const [skills, setSkills] = useState([]);
  const [selectedSkillId, setSelectedSkillId] = useState(null);
  const [skillListData, setSkillListData] = useState([]);

  let count = 0;

  useEffect(() => {
    if (count === 0) {
      count++;
    get_skills();
    getUserSkillList();
    getSkillsType();
    }
  }, []);

  const onHide = () => {
    setSkillDialog(false);
  };
  const saveData = (data) => {
    // console.log(data);
    var skillListing = [];
    data.skills.map((item) => {
      let objProject = {
        skillId: item.id,
      };
      skillListing.push(objProject);
    });
    let param = {
      skillListing,
    };
    try {
      skillService.addBulkSkills(param.skillListing).then((resp) => {
        getUserSkillList();
        setSkillDialog(false);         //close save popup
        setSelectedSkillId([]);
      });
    } catch (error) {
      console.log(error);
    }
  };

  const get_skills = () => {
    skillService.getSkills().then((resp) => {
      setSkillData(resp.data.data);
    });
  };
  const getUserSkillList = () => {
    skillService.getUserSkillsList().then((resp) => {
      setSkillListData(resp.data.data);
    });
  };
  /* Dialog Box for Add/Edit Form Start */
  const AddSkillDialog = () => {
    return (
      <Dialog
        header="Add Skills"
        visible={skillDialog}
        style={{ width: "500px" }}
        onHide={() => onHide()}
      >
        <SkillDialogForm
          save={(data) => saveData(data)}
          onClose={(e) => {
            setSkillDialog(false);
          }}
          skillData={skillData}
        />
      </Dialog>
    );
  };
  /* Dialog Box for Add/Edit  Form End */

  const getSkillsType = () => {
    try {
      skillService.getSkills().then((resp) => {
        setSkills(resp.data.data);
      });
    } catch (error) {
      console.log("Catch Error :", error);
    }
  };

  const deleteSkill = (id) => {
    confirmDialog({
      message: "Do you want to delete this record?",
      header: "Delete Confirmation",
      icon: "pi pi-info-circle",
      acceptClassName: "p-button-danger",
      accept: () => acceptFunc(id),
      reject,
    });
  };

  const acceptFunc = (id) => {
    try {
      // delete api call
      skillService.deleteSkill(id).then(
        (resp) => {
          getUserSkillList();
          toast.error("Skill deleted successfully...");
        },
        (err) => {
          toast.error("Unable to delete skill...");
        }
      );
    } catch (error) {
      // Util.handelResponse(error, 2);
    }
  };

  const reject = () => {
    setSkillListData([]);
    getUserSkillList();
  };



  return (
    <Fragment>
      {AddSkillDialog()}

      <div className="wrapper p-3">
        <div className="grid">
          <div className="col">
            <span className="heading">
              Skills
              <div className="heading-actions">
                <Button label="Add" disabled className="p-button-text" />
                <Button
                  icon="pi pi-plus"
                  type="button"
                  onClick={() => setSkillDialog(true)}
                  className="p-button-rounded p-button circle"
                  aria-label="Add"
                />
              </div>
            </span>
          </div>
        </div>

        <div className="align-items-center flex-wrap p-1">
          {skillListData.map((item) => (
            // <Chip label={item?.Skill?.title} className="mr-2 mb-2" removable />
            <Button
              type="button"
              label={item?.Skill?.title}
              className="p-button-rounded p-button-secondary mr-2"
            >
              <i
                className="pi pi-times-circle"
                style={{ fontSize: "1.2rem", marginLeft: "10px" }}
                onClick={() => {
                  deleteSkill(item.id);
                }}
              ></i>
            </Button>
          ))}
        </div>
      </div>
    </Fragment>
  );
}

export default ProfileSkill;