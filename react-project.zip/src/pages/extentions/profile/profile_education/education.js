import React, { Fragment } from 'react';
import { Button } from 'primereact/button';
import '../../../../template/App.css';
import { useState } from 'react';
import { Dialog } from 'primereact/dialog';
import { useEffect } from 'react';
import { educationalService } from '../../../../services/profile';
import { confirmDialog } from 'primereact/confirmdialog';
import EducationForm from './education_form';
import { Util } from '../../../../services';

function ProfileEducation() {
    const [eduData, setEduData] = useState([]);
    const [showNewForm, setShowNewForm] = useState(false);
    const [editData, setEditData] = useState({});

    useEffect(() => {
        get_educational();
    }, [])

    const get_educational = (data) => {
        educationalService.getEducational(data).then(resp => {
            setEduData(resp.data.data);
        });
    };

    const clearForm = () => {
        setEditData({});
    };

    const createForm = () => {
        setEditData({});
        setShowNewForm(true);
    };

    const editForm = (rowData) => {
        setEditData(rowData);
        setShowNewForm(true);
    };

    const add_educational = (data) => {
        educationalService.addEducational(data).then((resp) => {
            get_educational();
            setShowNewForm(false);
        });
    };

    const update_educational = (data) => {
        data = { ...data, id: editData.id };
        educationalService.updateEducational(data).then((resp) => {
            get_educational();
            setShowNewForm(false);
        });
    };

    const delete_educational = (e, row) => {
        confirmDialog({
            target: e.currentTarget,
            message: 'Are you sure you want to delete?',
            header: 'Delete Confirmation',
            icon: 'pi pi-exclamation-triangle',
            acceptLabel: 'No',
            rejectLabel: 'Yes',
            reject: () => {
                educationalService.deleteEducational(row.id).then(resp => {
                    get_educational();
                }, (error) => {
                })
            },
            accept: () => {
            }
        })
    }

    const EducationDialog = () => {
        return (
            <div className="flex align-items-center flex-column px-3">
                <Dialog
                    header={editData.id ? "Update Education" : "Add Education"}
                    visible={showNewForm}
                    style={{ width: '500px' }}
                    onHide={() => setShowNewForm(false)}
                >
                    <EducationForm
                        editData={editData}
                        closeForm={() => setShowNewForm(false)}
                        addEducation={(data) => add_educational(data)}
                        updateEducation={(data) => update_educational(data)}
                        clearForm={clearForm}
                    />
                </Dialog>
            </div>
        )
    }

    const SeeMore = ({ children }) => {
        const text = children;
        const [isSeeMore, setIsSeeMore] = useState(true);
        const toggleSeeMore = () => {
            setIsSeeMore(!isSeeMore);
        };
        return (
            <p>
                {isSeeMore ? text.slice(0, 255) : text}
                {text.length > 255 && (
                    <span onClick={toggleSeeMore} className="read-or-hide">
                        {isSeeMore ? <a href="#" style={{ textDecoration: 'none' }}>{text.length === 255 ? '' : ' ...see more'}</a> : <a href="#" style={{ textDecoration: 'none' }}>{text.length === 255 ? '' : ' ...show less'}</a>}
                    </span>
                )}
            </p>
        );
    };

    return (
        <Fragment>
            {EducationDialog()}
            < div className='wrapper p-3' >
                <div className='grid'>
                    <div className='col'>
                        <span className='heading'>
                            Education
                            <div className='heading-actions'>
                                <Button label="Add" disabled className="p-button-text" />
                                <Button icon="pi pi-plus" onClick={() => createForm()}
                                    className="p-button-rounded p-button circle" aria-label="Add" />
                            </div>
                        </span>
                    </div>
                </div>

                {eduData.map(item =>
                    <div className='project-wrapper'>
                        <div style={{ float: 'right' }}>
                            <Button
                                icon="pi pi-pencil"
                                className="p-button-rounded p-button-outlined ml-2"
                                style={{ border: 'none', backgroundColor: 'rgb(246 246 246)', marginTop: '-4px', padding: '8px', borderRadius: '50%', margin: '1px' }}
                                onClick={() => editForm(item)}
                                aria-label="Edit" />
                            <Button
                                icon="pi pi-trash"
                                className="p-button-rounded p-button-outlined ml-2"
                                style={{ border: 'none', backgroundColor: 'rgb(246 246 246)', marginTop: '-4px', padding: '8px', borderRadius: '50%', margin: '1px' }}
                                onClick={(e) => delete_educational(e, item)}
                                aria-label="Delete" />
                        </div>
                        <div className='profile-body'>{item.school}</div>
                        <div style={{ color: 'black' }} className='mb-1 mt-1'>{item.degree + ", " + item.field}</div>
                        <div>{Util.dateConverterUS(item.startDate)} to {Util.dateConverterUS(item.endDate)}</div>
                        <div className='mb-2 mt-2' style={{ color: 'black' }}><strong>Grade: </strong>{item.grade}</div>
                        <div className='mt-2' style={{ color: 'black' }}><SeeMore>{item.description}</SeeMore></div>
                    </div>
                )}
            </div>
        </Fragment>
    );
}

export default ProfileEducation;