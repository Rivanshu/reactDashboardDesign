import React, { Fragment } from 'react';
import { Button } from 'primereact/button';
import '../../../../template/App.css';
import { useState } from 'react';
import { useFormik } from 'formik';
import { InputText } from 'primereact/inputtext';
import { Calendar } from 'primereact/calendar';
import { classNames } from 'primereact/utils';
import { InputTextarea } from 'primereact/inputtextarea';
import moment from 'moment';

function EducationForm({ editData, closeForm, addEducation, updateEducation }) {
    const [showMessage, setShowMessage] = useState(false);
    const [formData, setFormData] = useState({});

    const formik = useFormik({
        initialValues: {
            school: editData ? editData.school : '',
            degree: editData ? editData.degree : '',
            field: editData ? editData.field : '',
            startDate: editData.startDate ? new Date(editData.startDate) : '',
            endDate: editData.endDate ? new Date(editData.endDate) : '',
            grade: editData ? editData.grade : '',
            description: editData ? editData.description : ''
        },
        validate: (data) => {
            let errors = {};
            if (!data.school) { errors.school = 'School is required.'; }
            if (!data.degree) { errors.degree = 'Degree is required.'; }
            if (!data.field) { errors.field = 'Field is required.'; }
            if (!data.startDate) { errors.startDate = 'Start date is required.'; }
            if (!data.endDate) { errors.endDate = 'End date is required.'; }
            if (data.endDate && data.startDate) {
                if (moment(data.startDate) > moment(data.endDate)) {
                    errors.endDate = "End Date is must be above than start date";
                }
            }
            if (!data.grade) { errors.grade = 'Grade is required.'; }
            if (!data.description) { errors.description = 'Description is required.'; }

            return errors;
        },
        onSubmit: (data) => {
            setFormData(data);
            setShowMessage(true);

            if (editData && editData.id) {
                let dataobj = {
                    id: editData.id,
                    school: data.school,
                    degree: data.degree,
                    field: data.field,
                    startDate: data.startDate,
                    endDate: data.endDate,
                    grade: data.grade,
                    description: data.description
                }
                updateEducation(dataobj);
            } else {
                let dataobj = {
                    school: data.school,
                    degree: data.degree,
                    field: data.field,
                    startDate: data.startDate,
                    endDate: data.endDate,
                    grade: data.grade,
                    description: data.description
                }
                addEducation(dataobj);
            }
            formik.resetForm();
        }
    });

    const isFormFieldValid = (name) => !!(formik.touched[name] && formik.errors[name]);
    const getFormErrorMessage = (name) => {
        return isFormFieldValid(name) && <small className="p-error">{formik.errors[name]}</small>;
    };

    const handleDateChange = (date) => {
        formik.setFieldValue("startDate", date);
        formik.setFieldValue("endDate", "");
    };


    const educationForm = (
        <React.Fragment>
            <form onSubmit={formik.handleSubmit} className="p-fluid p-grid" >
                <div className='p-field'>
                    <span>
                        <label htmlFor="school">School:</label>
                        <InputText
                            id="school"
                            name="school"
                            value={formik.values.school}
                            onChange={formik.handleChange}
                            placeholder="Enter school name"
                            className={classNames({ 'p-invalid': isFormFieldValid('school') })} />
                    </span>
                    {getFormErrorMessage('school')}
                </div>
                <div className='p-field'>
                    <span>
                        <label htmlFor="degree">Degree:</label>
                        <InputText
                            id="degree"
                            name="degree"
                            value={formik.values.degree}
                            onChange={formik.handleChange}
                            placeholder="Enter degree"
                            className={classNames({ 'p-invalid': isFormFieldValid('degree') })} />
                    </span>
                    {getFormErrorMessage('degree')}
                </div>
                <div className='p-field'>
                    <span>
                        <label htmlFor="field">Field:</label>
                        <InputText
                            id="field"
                            name="field"
                            value={formik.values.field}
                            onChange={formik.handleChange}
                            placeholder="Enter field"
                            className={classNames({ 'p-invalid': isFormFieldValid('field') })} />
                    </span>
                    {getFormErrorMessage('field')}
                </div>
                <div className="grid">
                    <div className="p-field col-6">
                        <span>
                            <label htmlFor="startDate">Start Date:</label>
                            <Calendar
                                id="startDate"
                                name="startDate"
                                dateFormat="dd/mm/yy"
                                value={formik.values.startDate}
                                onChange={(e) => handleDateChange(e.target.value)}
                                // minDate={new Date()}
                                showIcon
                                placeholder="Select start date"
                                className={classNames({ 'p-invalid': isFormFieldValid('startDate') })} />
                        </span>
                        {getFormErrorMessage('startDate')}
                    </div>
                    <div className="p-field col-6">
                        <span>
                            <label htmlFor="endDate">End Date:</label>
                            <Calendar
                                id="endDate"
                                name="endDate"
                                dateFormat="dd/mm/yy"
                                value={formik.values.endDate}
                                onChange={formik.handleChange}
                                minDate={new Date(formik.values.startDate)}
                                disabled={!formik.values.startDate}
                                showIcon
                                placeholder="Select end date"
                                className={classNames({ 'p-invalid': isFormFieldValid('endDate') })} />
                        </span>
                        {getFormErrorMessage('endDate')}
                    </div>
                </div>
                <div className='p-field'>
                    <span>
                        <label htmlFor="grade">Grade:</label>
                        <InputText
                            id="grade"
                            name="grade"
                            value={formik.values.grade}
                            onChange={formik.handleChange}
                            placeholder="Enter grade"
                            className={classNames({ 'p-invalid': isFormFieldValid('grade') })} />
                    </span>
                    {getFormErrorMessage('grade')}
                </div>
                <div className='p-field'>
                    <span>
                        <label htmlFor="description">Description:</label>
                        <InputTextarea
                            id="description"
                            name="description"
                            autoResize
                            value={formik.values.description}
                            onChange={formik.handleChange}
                            placeholder="Enter description"
                            className={classNames({ 'p-invalid': isFormFieldValid('description') })} />
                    </span>
                    {getFormErrorMessage('description')}
                </div>
                <div className='pt-3'>
                    <div className='grid' style={{ float: 'right' }}>
                        <div className='mr-2'>
                            <Button type="button" label="Cancel" className="p-button-rounded p-button-secondary" onClick={closeForm} />
                        </div>
                        <div >
                            <Button type="submit" label="Save" className="p-button-rounded" />
                        </div>
                    </div>
                </div>
            </form>
        </React.Fragment>
    )

    return (
        <Fragment>
            {educationForm}
        </Fragment>
    );
}

export default EducationForm;