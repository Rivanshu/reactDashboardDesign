const shareFile = [
    {
        label: 'Download PDF',
        icon: 'pi pi-file-pdf'
    },
    {
        label: 'Download Word',
        icon: 'pi pi-file-word'
    }
];

const profileLink = [
    { name: "Radhika Sharma" },
    { name: "Shivani Tomar" },
    { name: "Bhagya Jain" },
    { name: "Aditya Panwar" },
    { name: "Prabhu Jain" },
    { name: "Swati Singh" },
    { name: "Rima Das" }
]

export { shareFile, profileLink };