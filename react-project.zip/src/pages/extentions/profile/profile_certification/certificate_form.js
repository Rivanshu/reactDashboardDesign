import React, { Fragment } from 'react';
import { Button } from 'primereact/button';
import '../../../../template/App.css';
import { useState } from 'react';
import { useFormik } from 'formik';
import { InputText } from 'primereact/inputtext';
import { Calendar } from 'primereact/calendar';
import { InputTextarea } from 'primereact/inputtextarea';
import { Checkbox } from 'primereact/checkbox';
import { classNames } from 'primereact/utils';
import { Util } from '../../../../services';
import moment from 'moment';

function CertificationForm({ editData, addCertificate, updateCertificate, closeForm, clearForm }) {
    const [showMessage, setShowMessage] = useState(false);
    const [formData, setFormData] = useState({});
    const [checked, setChecked] = useState(false);
    const [endDateDisabled, setEndDateDisabled] = useState(false);

    const formik = useFormik({
        initialValues: {
            title: editData ? editData.title : '',
            issuingOrganization: editData ? editData.issuingOrganization : '',
            isNotExpire: editData ? editData.isNotExpire : '',
            issueDate: editData.issueDate ? new Date(editData.issueDate) : '',
            expirationDate: editData.expirationDate ? new Date(editData.expirationDate) : '',
            credentialId: editData ? editData.credentialId : '',
            credentialUrl: editData ? editData.credentialUrl : '',
            description: editData ? editData.description : ''
        },
        validate: (data) => {
            let errors = {};
            if (!data.title) { errors.title = 'Certificate title is required.'; }
            if (!data.issuingOrganization) { errors.issuingOrganization = 'Certificate issuing organization is required.'; }
            if (!data.issueDate) { errors.issueDate = 'Certificate issue date is required.'; }
            if (!checked) {
                if (!data.expirationDate) { errors.expirationDate = 'Expiration date is required.'; }
            }
            if (data.expirationDate && data.issueDate) {
                if (moment(data.issueDate) > moment(data.expirationDate)) {
                    errors.expirationDate = "Issue Date is must be above than expiration date";
                }
            }
            if (!data.credentialId) { errors.credentialId = 'Credential id is required.'; }
            if (!data.credentialUrl) { errors.credentialUrl = 'Credential url is required.'; }
            else if (!Util.validURL(data.credentialUrl)) { errors.credentialUrl = 'Invalid credential url. E.g. www.example.com'; }
            if (!data.description) { errors.description = 'Description is required.'; }

            return errors;
        },
        onSubmit: (data) => {
            setFormData(data);
            setShowMessage(true);

            if (editData && editData.id) {
                let dataobj = {
                    id: editData.id,
                    title: data.title,
                    issuingOrganization: data.issuingOrganization,
                    isNotExpire: data.isNotExpire,
                    issueDate: data.issueDate,
                    expirationDate: !data.isNotExpire ? data.expirationDate : null,
                    credentialId: data.credentialId,
                    credentialUrl: data.credentialUrl,
                    description: data.description
                }
                updateCertificate(dataobj);
            } else {
                let dataobj = {
                    title: data.title,
                    issuingOrganization: data.issuingOrganization,
                    isNotExpire: data.isNotExpire,
                    issueDate: data.issueDate,
                    expirationDate: !data.isNotExpire ? data.expirationDate : null,
                    credentialId: data.credentialId,
                    credentialUrl: data.credentialUrl,
                    description: data.description
                }
                addCertificate(dataobj);
            }
            formik.resetForm();
        }
    });

    const isFormFieldValid = (name) => !!(formik.touched[name] && formik.errors[name]);
    const getFormErrorMessage = (name) => {
        return isFormFieldValid(name) && <small className="p-error">{formik.errors[name]}</small>;
    };

    const handleDateChange = (date) => {
        formik.setFieldValue("issueDate", date);
        formik.setFieldValue("expirationDate", "");
    };


    function handleCheckboxChange(event) {
        setChecked(event.target.checked);
        setEndDateDisabled(event.target.checked);
    }

    const certificateForm = (
        <React.Fragment>
            <form onSubmit={formik.handleSubmit} className="p-fluid p-grid" >
                <div className='p-field'>
                    <span>
                        <label htmlFor="title">Title:</label>
                        <InputText
                            id="title"
                            name="title"
                            value={formik.values.title}
                            onChange={formik.handleChange}
                            placeholder="Enter title"
                            className={classNames({ 'p-invalid': isFormFieldValid('title') })} />
                    </span>
                    {getFormErrorMessage('title')}
                </div>
                <div className='p-field'>
                    <span>
                        <label htmlFor="issuingOrganization">Issuing Organization:</label>
                        <InputText
                            id="issuingOrganization"
                            name="issuingOrganization"
                            value={formik.values.issuingOrganization}
                            onChange={formik.handleChange}
                            placeholder="Enter issuing organization"
                            className={classNames({ 'p-invalid': isFormFieldValid('issuingOrganization') })} />
                    </span>
                    {getFormErrorMessage('issuingOrganization')}
                </div>
                <div className='p-field-checkbox mt-2'>
                    <span>
                        <Checkbox
                            id="isNotExpire"
                            name="isNotExpire"
                            value={formik.values.isNotExpire}
                            onChange={(e) => { formik.handleChange(e); handleCheckboxChange(e) }}
                            checked={checked} />
                        <label htmlFor="isNotExpire"> isNot Expire</label>
                    </span>
                </div>
                <div className="grid">
                    <div className="p-field col-6">
                        <span>
                            <label htmlFor="issueDate">Issue Date:</label>
                            <Calendar
                                id="issueDate"
                                name="issueDate"
                                dateFormat="dd/mm/yy"
                                value={formik.values.issueDate}
                                onChange={(e) => handleDateChange(e.target.value)}
                                showIcon
                                placeholder="Select issue date"
                                className={classNames({ 'p-invalid': isFormFieldValid('issueDate') })} />
                        </span>
                        {getFormErrorMessage('issueDate')}
                    </div>
                    {/* {!checked && ( */}
                    <div className="p-field col-6">
                        <span>
                            <label htmlFor="expirationDate">Expiration Date:</label>
                            <Calendar
                                id="expirationDate"
                                name="expirationDate"
                                dateFormat="dd/mm/yy"
                                value={formik.values.expirationDate}
                                onChange={formik.handleChange}
                                disabled={endDateDisabled}
                                minDate={new Date(formik.values.issueDate)}
                                showIcon
                                placeholder="Select expiration date"
                                className={classNames({ 'p-invalid': isFormFieldValid('expirationDate') })}
                            />
                        </span>
                        {getFormErrorMessage('expirationDate')}
                    </div>
                    {/* )} */}
                </div>
                <div className='p-field'>
                    <span>
                        <label htmlFor="credentialId">Credential ID:</label>
                        <InputText
                            id="credentialId"
                            name="credentialId"
                            value={formik.values.credentialId}
                            onChange={formik.handleChange}
                            placeholder="Enter credential id"
                            className={classNames({ 'p-invalid': isFormFieldValid('credentialId') })} />
                    </span>
                    {getFormErrorMessage('credentialId')}
                </div>
                <div className='p-field'>
                    <span>
                        <label htmlFor="credentialUrl">Credential URL:</label>
                        <InputText
                            id="credentialUrl"
                            name="credentialUrl"
                            value={formik.values.credentialUrl}
                            onChange={formik.handleChange}
                            placeholder="Enter credential url"
                            className={classNames({ 'p-invalid': isFormFieldValid('credentialUrl') })} />
                    </span>
                    {getFormErrorMessage('credentialUrl')}
                </div>
                <div className='p-field'>
                    <span>
                        <label htmlFor="description">Description:</label>
                        <InputTextarea
                            id="description"
                            name="description"
                            autoResize
                            value={formik.values.description}
                            onChange={formik.handleChange}
                            placeholder="Enter description"
                            className={classNames({ 'p-invalid': isFormFieldValid('description') })} />
                    </span>
                    {getFormErrorMessage('description')}
                </div>
                <div className='pt-3'>
                    <div className='grid' style={{ float: 'right' }}>
                        <div className='mr-2'>
                            <Button type="button" label="Cancel" className="p-button-rounded p-button-secondary" onClick={closeForm} />
                        </div>
                        <div>
                            <Button type="submit" label="Save" className="p-button-rounded" />
                        </div>
                    </div>
                </div>
            </form>
        </React.Fragment>
    )

    return (
        <Fragment>
            {certificateForm}
        </Fragment >
    );
}

export default CertificationForm;