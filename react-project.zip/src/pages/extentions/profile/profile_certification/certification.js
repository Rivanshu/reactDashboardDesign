import React, { Fragment } from 'react';
import { Button } from 'primereact/button';
import { useState } from 'react';
import { Dialog } from 'primereact/dialog';
import { useEffect } from 'react';
import { certificateService } from '../../../../services/profile';
import { confirmDialog } from 'primereact/confirmdialog';
import CertificationForm from './certificate_form';
import { Util } from '../../../../services';

function ProfileCertification() {
    const [certificateData, setCertificateData] = useState([]);
    const [showNewForm, setShowNewForm] = useState(false);
    const [editData, setEditData] = useState({});

    useEffect(() => {
        get_certificate();
    }, [])

    const get_certificate = (data) => {
        certificateService.getCertificate(data).then(resp => {
            setCertificateData(resp.data.data);
        });
    };

    const clearForm = () => {
        setEditData({});
    };

    const createForm = () => {
        setEditData({});
        setShowNewForm(true);
    };

    const editForm = (rowData) => {
        setEditData(rowData);
        setShowNewForm(true);
    };

    const add_certificate = (data) => {
        certificateService.addCertificate(data).then((resp) => {
            get_certificate();
            setShowNewForm(false);
        });
    };

    const update_certificate = (data) => {
        data = { ...data, id: editData.id };
        certificateService.updateCertificate(data).then((resp) => {
            get_certificate();
            setShowNewForm(false);
        });
    };

    const delete_certificate = (e, row) => {
        confirmDialog({
            target: e.currentTarget,
            message: 'Are you sure you want to delete?',
            header: 'Delete Confirmation',
            icon: 'pi pi-exclamation-triangle',
            acceptLabel: 'No',
            rejectLabel: 'Yes',
            reject: () => {
                certificateService.deleteCertificate(row.id).then(resp => {
                    get_certificate();
                }, (error) => {
                })
            },
            accept: () => {
            }
        })
    }

    const CertificateDialog = () => {
        return (
            <div className="flex align-items-center flex-column px-3">
                <Dialog
                    header={editData.id ? "Update Certification" : "Add Certification"}
                    visible={showNewForm}
                    style={{ width: '500px' }}
                    onHide={() => setShowNewForm(false)}
                >
                    <CertificationForm
                        editData={editData}
                        closeForm={() => setShowNewForm(false)}
                        addCertificate={(data) => add_certificate(data)}
                        updateCertificate={(data) => update_certificate(data)}
                        clearForm={clearForm}
                    />
                </Dialog>
            </div>
        )
    }

    return (
        <Fragment>
            {CertificateDialog()}
            < div className='wrapper p-3' >
                <div className='grid'>
                    <div className='col'>
                        <span className='heading'>
                            Certifications
                            <div className='heading-actions'>
                                <Button label="Add" disabled className="p-button-text" />
                                <Button icon="pi pi-plus" onClick={() => createForm()}
                                    className="p-button-rounded p-button circle" aria-label="Add" />
                            </div>
                        </span>
                    </div>
                </div>

                {certificateData.map(item =>
                    <div className='project-wrapper'>
                        <div style={{ float: 'right' }}>
                            <Button
                                icon="pi pi-pencil"
                                className="p-button-rounded p-button-outlined ml-2"
                                style={{ border: 'none', backgroundColor: 'rgb(246 246 246)', marginTop: '-4px', padding: '8px', borderRadius: '50%', margin: '1px' }}
                                onClick={() => editForm(item)}
                                aria-label="Edit" />
                            <Button
                                icon="pi pi-trash"
                                className="p-button-rounded p-button-outlined ml-2"
                                style={{ border: 'none', backgroundColor: 'rgb(246 246 246)', marginTop: '-4px', padding: '8px', borderRadius: '50%', margin: '1px' }}
                                onClick={(e) => delete_certificate(e, item)}
                                aria-label="Delete" />
                        </div>
                        <div className='profile-body'>{item.title}</div>
                        <div className='mb-2 mt-2' style={{ color: 'black' }}>{item.issuingOrganization}</div>
                        <div>Issued {item.issueDate ? Util.dateConverterUS(item.issueDate) : 'N/A'}</div>
                        <div className='mt-2'>
                            <a href={'http://' + item.credentialUrl}>{item.credentialUrl}</a>
                        </div>
                    </div>
                )}
            </div>
        </Fragment >
    );
}

export default ProfileCertification;