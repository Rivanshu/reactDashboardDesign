import React from "react";
import { useFormik } from "formik";
import { Button } from "primereact/button";
import { useState } from "react";
import { InputMask } from "primereact/inputmask";
import { classNames } from "primereact/utils";

function UpdateMobileNoForm({ updateMobileNumber, closeForm, clearForm, user }) {

    const formik = useFormik({
        initialValues: {
            phone: localStorage.getItem('phone') ? localStorage.getItem('phone') : user ? user.phone : ''
        },
        validate: (data) => {
            let errors = {};
            if (!data.phone) {
                errors.phone = "Update Mobile No.";
            } else if (
                !/^([+]?[\s0-9]+)?(\d{3}|[(]?[0-9]+[)])?([-]?[\s]?[0-9])+$/i.test(data.phone)
            ) {
                errors.phone = "Enter 10 digit phone no.";
            }

            return errors;
        },
        onSubmit: (data) => {
            // showPhoneForm(data);
            // setShowMessage(true);

            if (user && user.phone) {
                updateMobileNumber(data);
            }
            formik.resetForm();
        },
    });

    const isFormFieldValid = (name) =>
        !!(formik.touched[name] && formik.errors[name]);
    const getFormErrorMessage = (name) => {
        return (
            isFormFieldValid(name) && (
                <small className="p-error">{formik.errors[name]}</small>
            )
        );
    };

    const form = (
        <React.Fragment>
            <form onSubmit={formik.handleSubmit} className="p-fluid p-grid">
                <div className="p-field">
                    <span>
                        <label htmlFor="phone">Mobile Number:</label>
                        <InputMask
                            id="phone"
                            name="phone"
                            mask="999-999-9999"
                            placeholder="999-999-9999"
                            value={formik.values.phone}
                            onChange={formik.handleChange}
                            className={classNames({ 'p-invalid': isFormFieldValid('phone') })}
                        />
                    </span>
                    {getFormErrorMessage('phone')}
                </div>
                <div className="pt-3">
                    <div className="grid" style={{ float: "right" }}>
                        <div className="mr-2 mt-1">
                            <Button
                                type="button"
                                label="Cancel"
                                onClick={() => {
                                    closeForm();
                                    clearForm();
                                }}
                                className="p-button-rounded p-button-secondary"
                            />
                        </div>
                        <div className="mt-1">
                            <Button
                                type="submit"
                                label="Save"
                                className="p-button-rounded"
                            />
                        </div>
                    </div>
                </div>
            </form>
        </React.Fragment>
    )

    return (
        <React.Fragment>
            {form}
        </React.Fragment>
    );
}

export default UpdateMobileNoForm;