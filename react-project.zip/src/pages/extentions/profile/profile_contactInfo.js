import { useFormik } from "formik";
import { Button } from "primereact/button";
import { Dialog } from "primereact/dialog";
import { InputText } from "primereact/inputtext";
import { InputMask } from "primereact/inputmask";
import React, { Fragment } from "react";
import { useState } from "react";
import { contactService } from "../../../services/profile";
import { useEffect } from "react";
import { Util } from "../../../services";
import { classNames } from "primereact/utils";
import properties from "../../../config/environmentProperties";
import { Checkbox } from "primereact/checkbox";
import { InputTextarea } from "primereact/inputtextarea";
import { Tooltip } from "primereact/tooltip";
import { toast } from "react-toastify";
import { Dropdown } from "primereact/dropdown";
import UpdateMobileNoForm from "./updateMobileNoDialog";

function ContactInfo({ user }) {
  const [showMessage, setShowMessage] = useState(false);
  const [profileData, setProfileData] = useState([]);
  const [country, setCountry] = useState(null);
  const [states, setStates] = useState(null);
  const [showNewForm, setShowNewForm] = useState(false);
  const [showPhoneForm, setShowPhoneForm] = useState(false);
  const [editMobileData, setEditMobileData] = useState({});
  const [formData, setFormData] = useState({});
  const [editData, setEditData] = useState({});
  const [imagePath, setImagePath] = useState("");
  const [checked, setChecked] = useState(false);
  const [userPhoto, setUserPhoto] = useState(user?.photo);
  const [userPhone, setUserPhone] = useState(user?.phone);
  const imgPath = properties.currentEnvironment.docPath + "images/";

  const uploadImage = async (e) => {
    var imgType = e.target.files[0].name.split(".")[1];
    if (imgType === "png" || imgType === "jpg" || imgType === "jpeg") {
      const file = e.target.files[0];
      const base64 = await Util.convertBase64(file);
      const reqBody = { photo: base64 };
      updateProfile(reqBody);
    } else {
      toast.error("Invalid file format");
    }
  };

  const updateProfile = (data) => {
    contactService.updateProfile(data).then((resp) => {
      const imageUrl = imgPath + resp.data.data.photo;
      setUserPhoto(resp.data.data.photo);
      setImagePath(imageUrl);
    });
  };



  return (
    <Fragment>
      <div className="profile-card">
        <div className="grid">
          <div className="col profile-image-container">
            {userPhoto ? (
              <img src={imagePath} alt="" className="profile-image" />
            ) : (
              <span className="profile-image-name">
                {user.firstName.toUpperCase().substr(0, 1)}
                {user.lastName.toUpperCase().substr(0, 1)}
              </span>
            )}
            <span className="profile-image-change" style={{ display: 'none' }}>
              <a href="#" className="icon-link">
                <i className="pi pi-camera"></i>
              </a>
              <InputText type="file" accept=".png, .jpg, .jpeg" onChange={(e) => { uploadImage(e); }} />
            </span>
          </div>
          <div className="col pl-4 profile-info-container">
            <div style={{ float: "right" }}>

            </div>

            <h5>
              {user.firstName || ""} {user?.lastName || ""}{" "}
              <small>( {user?.ecn || ""} )</small>
            </h5>

            <p>
              <b>Role : </b>
              <span style={{ textTransform: 'capitalize' }}>{user?.Designation?.title || ""}</span>
            </p>

            {Util.dateConverterUS(user?.doj) === "" || Util.dateConverterUS(user?.doj) === null ? '' : <p><b>DoJ : </b>{Util.dateConverterUS(user?.doj) || ''}</p>}

            <p className="capitalize">
              <b>
                Reports to : <span style={{ textTransform: 'capitalize' }}>{user?.superior?.firstName || ""}{" "}
                  {user?.superior?.lastName || ""}</span>
              </b>{" "}
              ({user?.superior?.Designation?.title || ""})
            </p>

            <p className="links">
              <span>
                <i className="pi pi-phone" />
                <a href={localStorage.getItem('phone') ? localStorage.getItem('phone') : userPhone || ""} >
                  {localStorage.getItem('phone') ? localStorage.getItem('phone') : userPhone || ""}
                </a>{" "}
                <i className="custom-tooltip-btn pi pi-info-circle" />
                <Tooltip
                  target=".custom-tooltip-btn"
                  position="top">
                  <label>Update your mobile number</label>
                </Tooltip>
              </span>
              <span>
                <i className="pi pi-envelope" />
                {user.email || ""}
              </span>
              <span>
                {profileData.length > 0 ? (
                  <span>
                    <i className="pi pi-home" />
                    {profileData?.[0]?.currentAddress || ""}{" "}
                    {profileData?.[0]?.currentAddress1 || ""}{" "}
                    {profileData?.[0]?.currentCity || ""}{" "}
                    {profileData?.[0]?.currentState || ""}{" "}
                    {profileData?.[0]?.currentCountry || ""}{" "}
                    {profileData?.[0]?.currentPincode || ""}{" "}
                  </span>
                ) : (
                  ""
                )}
              </span>
            </p>

            <p className="links">
              <span>
                {profileData.length > 0 ? (
                  <span>
                    <i className="pi pi-envelope" />
                    <b>Alternate Email : </b>
                    {profileData?.[0]?.alternateEmail}
                  </span>
                ) : (
                  ""
                )}
              </span>
              <span>
                {profileData.length > 0 ? (
                  <span>
                    <i className="pi pi-phone" />
                    <b>Alternate Phone No. : </b>
                    {profileData?.[0]?.alternatePhone}
                  </span>
                ) : (
                  ""
                )}
              </span>
            </p>

            <p className="links">
              {profileData.length > 0 ? (
                <span>
                  <i className="pi pi-home" />
                  <b>Permanent Address : </b>
                  {profileData?.[0]?.permanentAddress || ""}{" "}
                  {profileData?.[0]?.permanentAddress1 || ""}{" "}
                  {profileData?.[0]?.permanentCity || ""}{" "}
                  {profileData?.[0]?.permanentState || ""}{" "}
                  {profileData?.[0]?.permanentCountry || ""}{" "}
                  {profileData?.[0]?.permanentPincode || ""}{" "}
                </span>
              ) : (
                ""
              )}
            </p>
          </div>
        </div>
      </div>
    </Fragment>
  );
}

export default ContactInfo;