import React, { Fragment, useEffect, useState } from 'react';
import { Button } from 'primereact/button';
import { Dialog } from 'primereact/dialog';
import { projectService } from '../../../../services/profile';
import { confirmDialog } from 'primereact/confirmdialog';
import ProjectForm from './project_form';
import '../../../../template/App.css';
import { Util } from '../../../../services';

function ProfileProject() {
    const [projectData, setProjectData] = useState([]);
    const [showNewForm, setShowNewForm] = useState(false);
    const [editData, setEditData] = useState({});

    useEffect(() => {
        get_projects();
    }, [])

    const get_projects = (data) => {
        projectService.getProjects(data).then(resp => {
            setProjectData(resp.data.data);
        });
    };

    const clearForm = () => {
        setEditData({});
    };

    const createForm = () => {
        setEditData({});
        setShowNewForm(true);
    };

    const editForm = (rowData) => {
        setEditData(rowData);
        setShowNewForm(true);
    };

    const add_project = (data) => {
        projectService.addProjects(data).then((resp) => {
            get_projects();
            setShowNewForm(false);
        });
    };

    const update_project = (data) => {
        data = { ...data, id: editData.id };
        projectService.updateProjects(data).then((resp) => {
            get_projects();
            setShowNewForm(false);
        });
    };

    const delete_project = (e, row) => {
        confirmDialog({
            target: e.currentTarget,
            message: 'Are you sure you want to delete?',
            header: 'Delete Confirmation',
            icon: 'pi pi-exclamation-triangle',
            acceptLabel: 'No',
            rejectLabel: 'Yes',
            reject: () => {
                projectService.deleteProjects(row.id).then(resp => {
                    get_projects();
                }, (error) => {
                })
            },
            accept: () => {
            }
        })
    }

    const ProjectDialog = () => {
        return (
            <div className="flex align-items-center flex-column px-3">
                <Dialog
                    header={editData.id ? "Update Project" : "Add Project"}
                    visible={showNewForm}
                    style={{ width: '500px' }}
                    onHide={() => setShowNewForm()}
                >
                    <ProjectForm
                        editData={editData}
                        closeForm={() => setShowNewForm(false)}
                        addProject={(data) => add_project(data)}
                        updateProject={(data) => update_project(data)}
                        clearForm={clearForm}
                    />
                </Dialog>
            </div>
        )
    }

    const SeeMore = ({ children }) => {
        const text = children;
        const [isSeeMore, setIsSeeMore] = useState(true);
        const toggleSeeMore = () => {
            setIsSeeMore(!isSeeMore);
        };
        return (
            <p>
                {isSeeMore ? text.slice(0, 255) : text}
                {text.length > 255 && (
                    <span onClick={toggleSeeMore} className="read-or-hide">
                        {isSeeMore ? <a href="#" style={{ textDecoration: 'none' }}>{text.length === 255 ? '' : ' ...see more'}</a> : <a href="#" style={{ textDecoration: 'none' }}>{text.length === 255 ? '' : ' ...show less'}</a>}
                    </span>
                )}
            </p>
        );
    };

    return (
        <Fragment>
            {ProjectDialog()}
            < div className='wrapper p-3' >
                <div className='grid'>
                    <div className='col'>
                        <span className='heading'>
                            Projects
                            <div className='heading-actions'>
                                <Button label="Add" disabled className="p-button-text" />
                                <Button icon="pi pi-plus" onClick={() => createForm()}
                                    className="p-button-rounded p-button circle" aria-label="Add" />
                            </div>
                        </span>
                    </div>
                </div>

                {projectData.map(item =>
                    <div className='project-wrapper'>
                        <div style={{ float: 'right' }}>
                            <Button
                                icon="pi pi-pencil"
                                className="p-button-rounded p-button-outlined ml-2"
                                style={{ border: 'none', backgroundColor: 'rgb(246 246 246)', marginTop: '-13px', padding: '8px', borderRadius: '50%', margin: '1px' }}
                                onClick={() => editForm(item)}
                                aria-label="Edit" />
                            <Button
                                icon="pi pi-trash"
                                className="p-button-rounded p-button-outlined ml-2"
                                style={{ border: 'none', backgroundColor: 'rgb(246 246 246)', marginTop: '-4px', padding: '8px', borderRadius: '50%', margin: '1px' }}
                                onClick={(e) => delete_project(e, item)}
                                aria-label="Delete" />
                        </div>
                        <div className='profile-body'>{item.title}</div>
                        <div className='mb-1 mt-1'>{Util.dateConverterUS(item.startDate)} to {Util.dateConverterUS(item.endDate)}</div>
                        <div style={{ color: 'black' }}><SeeMore>{item.description}</SeeMore></div>
                        <div style={{ color: 'black' }}><strong>Client: </strong>{item.client}</div>
                        <div style={{ color: 'black' }}><strong>Role: </strong>{item.role}</div>
                        <div style={{ color: 'black' }}><strong>Team Size: </strong>{item.teamSize}</div>
                        <div style={{ color: 'black' }}><strong>Skills: </strong>{item.skills}</div>
                    </div>
                )}
            </div >
        </Fragment >
    );
}

export default ProfileProject;