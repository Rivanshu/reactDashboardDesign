import React, { useState } from 'react';
import { Button } from 'primereact/button';
import { InputText } from 'primereact/inputtext';
import { useFormik } from 'formik';
import { InputTextarea } from 'primereact/inputtextarea';
import { Calendar } from 'primereact/calendar';
import { classNames } from 'primereact/utils';
import '../../../../template/App.css';
import { Util } from '../../../../services';
import moment from 'moment';

function ProjectForm({ editData, addProject, updateProject, closeForm, clearForm }) {
    const [showMessage, setShowMessage] = useState(false);
    const [count, setCount] = React.useState(1000);
    const [formData, setFormData] = useState({});

    const formik = useFormik({
        initialValues: {
            title: editData ? editData.title : '',
            url: editData ? editData.url : '',
            startDate: editData.startDate ? new Date(editData.startDate) : '',
            endDate: editData.endDate ? new Date(editData.endDate) : '',
            description: editData ? editData.description : '',
            client: editData ? editData.client : '',
            role: editData ? editData.role : '',
            skills: editData ? editData.skills : '',
            teamSize: editData ? editData.teamSize : ''
        },
        validate: (data) => {
            let errors = {};

            if (!data.title) { errors.title = 'Project title is required.'; }
            // if (!data.url) { errors.url = 'Project url is required.'; }
            // else if (!Util.validURL(data.url)) { errors.url = 'Invalid project url. E.g. www.example.com'; }
            if (!data.startDate) { errors.startDate = 'Start date is required.'; }
            if (!data.endDate) { errors.endDate = 'End date is required.'; }
            if (data.endDate && data.startDate) {
                if (moment(data.startDate) > moment(data.endDate)) {
                    errors.endDate = "End Date is must be above than start date";
                }
            }
            if (!data.description) { errors.description = 'Project description is required.'; }
            if (!data.client) { errors.client = 'Client is required.'; }
            if (!data.role) { errors.role = 'Role is required.'; }
            if (!data.skills) { errors.skills = 'Skills is required.'; }
            if (!data.teamSize) { errors.teamSize = 'Team size is required.'; }

            return errors;
        },
        onSubmit: (data) => {
            setFormData(data);
            setShowMessage(true);

            if (editData && editData.id) {
                updateProject(data);
            } else {
                addProject(data);
            }
            formik.resetForm();
        }
    });

    const isFormFieldValid = (name) => !!(formik.touched[name] && formik.errors[name]);
    const getFormErrorMessage = (name) => {
        return isFormFieldValid(name) && <small className="p-error">{formik.errors[name]}</small>;
    };

    const handleDateChange = (date) => {
        formik.setFieldValue("startDate", date);
        formik.setFieldValue("endDate", "");
    };

    const projectForm = (
        <React.Fragment>
            <form onSubmit={formik.handleSubmit} className="p-fluid p-grid" >
                <div className="p-field">
                    <span>
                        <label htmlFor="title">Project Title:</label>
                        <InputText
                            id="title"
                            name="title"
                            value={formik.values.title}
                            onChange={formik.handleChange}
                            placeholder="Enter project name here"
                            className={classNames({ 'p-invalid': isFormFieldValid('title') })} />
                    </span>
                    {getFormErrorMessage('title')}
                </div>
                <div className="p-field">
                    <span>
                        <label htmlFor="url">Project URL (Optional):</label>
                        <InputText
                            id="url"
                            name="url"
                            value={formik.values.url}
                            onChange={formik.handleChange}
                            placeholder="Enter project url" />
                    </span>
                </div>
                <div className="grid">
                    <div className="p-field col-6">
                        <span>
                            <label htmlFor="startDate">Start Date:</label>
                            <Calendar
                                id="startDate"
                                name="startDate"
                                dateFormat="dd/mm/yy"
                                value={formik.values.startDate}
                                onChange={(e) => handleDateChange(e.target.value)}
                                // minDate={new Date()}
                                showIcon
                                placeholder="Select start date"
                                className={classNames({ 'p-invalid': isFormFieldValid('startDate') })} />
                        </span>
                        {getFormErrorMessage('startDate')}
                    </div>
                    <div className="p-field col-6">
                        <span>
                            <label htmlFor="endDate">End Date:</label>
                            <Calendar
                                id="endDate"
                                name="endDate"
                                dateFormat="dd/mm/yy"
                                value={formik.values.endDate}
                                onChange={formik.handleChange}
                                minDate={new Date(formik.values.startDate)}
                                disabled={!formik.values.startDate}
                                showIcon
                                placeholder="Select end date"
                                className={classNames({ 'p-invalid': isFormFieldValid('endDate') })} />
                        </span>
                        {getFormErrorMessage('endDate')}
                    </div>
                </div>
                <div className="p-field">
                    <span>
                        <label htmlFor="description">Details of Project:</label>
                        <InputTextarea
                            id="description"
                            name="description"
                            maxLength={1000}
                            value={formik.values.description}
                            onChange={(e) => { formik.handleChange(e); setCount(e.target.value.length) }}
                            autoResize
                            placeholder="Enter project description"
                            className={classNames({ 'p-invalid': isFormFieldValid('description') })} />
                    </span>
                    {getFormErrorMessage('description')}
                    <span style={{ float: "right" }}>{count === 1000 ? 1000 : 1000 - count} Character(s) Left</span>
                </div>
                <div className="p-field mt-4">
                    <span>
                        <label htmlFor="client">Client:</label>
                        <InputText
                            id="client"
                            name="client"
                            value={formik.values.client}
                            onChange={formik.handleChange}
                            placeholder="Enter client name here"
                            className={classNames({ 'p-invalid': isFormFieldValid('client') })} />
                    </span>
                    {getFormErrorMessage('client')}
                </div>
                <div className="p-field">
                    <span>
                        <label htmlFor="role">Role:</label>
                        <InputText
                            id="role"
                            name="role"
                            value={formik.values.role}
                            onChange={formik.handleChange}
                            placeholder="Enter role of your project"
                            className={classNames({ 'p-invalid': isFormFieldValid('role') })} />
                    </span>
                    {getFormErrorMessage('role')}
                </div>
                <div className="p-field">
                    <span>
                        <label htmlFor="skills">Skills:</label>
                        <InputText
                            id="skills"
                            name="skills"
                            value={formik.values.skills}
                            onChange={formik.handleChange}
                            placeholder="Enter skills required in project"
                            className={classNames({ 'p-invalid': isFormFieldValid('skills') })} />
                    </span>
                    {getFormErrorMessage('skills')}
                </div>
                <div className="p-field">
                    <span>
                        <label htmlFor="teamSize">Team Size:</label>
                        <InputText
                            keyfilter="int"
                            id="teamSize"
                            name="teamSize"
                            maxLength={3}
                            value={formik.values.teamSize}
                            onChange={formik.handleChange}
                            placeholder="Enter team size of your project"
                            className={classNames({ 'p-invalid': isFormFieldValid('teamSize') })} />
                    </span>
                    {getFormErrorMessage('teamSize')}
                </div>
                <div className='pt-3'>
                    <div className='grid' style={{ float: 'right' }}>
                        <div className='mr-2 mb-5 mt-1'>
                            <Button type="button" label="Cancel" className="p-button-rounded p-button-secondary" onClick={closeForm} />
                        </div>
                        <div className='mt-1 mb-5'>
                            <Button type="submit" label="Save" className="p-button-rounded " />
                        </div>
                    </div>
                </div>
            </form>
        </React.Fragment>
    )

    return (
        <React.Fragment>
            {projectForm}
        </React.Fragment >
    );
}

export default ProjectForm;