import React, { Fragment, useState, useEffect } from 'react';
import { contactService } from '../../../services/profile';
import properties from '../../../config/environmentProperties';
import { Util } from '../../../services';

function Profile({ userECN }) {
    const [userProfileDetails, setUserProfileDetails] = useState({});
    const imgPath = properties.currentEnvironment.docPath + 'images/';

    useEffect(() => {
        userProfileInfo(userECN);
    }, [userECN]);

    const userProfileInfo = (ecn) => {
        let param = {
            "ecn": ecn
        }
        contactService.getUserByFilter(param).then(resp => {
            if (resp) {
                setUserProfileDetails(resp?.data?.data[0]);
            }
        })
    }

    return (
        <Fragment>
            <div className='profile-card' >
                <div className='grid'>
                    <div className='col profile-image-container ml-2'>
                        {userProfileDetails.photo === "" || userProfileDetails.photo === null ? <span className='user-profile ml-4'>{userProfileDetails.firstName?.toUpperCase().substring(0, 1)}{userProfileDetails.lastName?.toUpperCase().substring(0, 1)}</span> : <img src={imgPath + userProfileDetails?.photo} alt="" className='profile-image' />}
                    </div>
                    <div className='col pl-4 profile-info-container'>
                        <h5>
                            {userProfileDetails?.firstName || ''} {userProfileDetails?.lastName || ''}
                            <small>( {userProfileDetails?.ecn || ''} )</small>
                        </h5>

                        <p>
                            <b>Role : </b>{userProfileDetails?.Designation?.title || ''}
                        </p>

                        {Util.dateConverterUS(userProfileDetails?.doj) === "" || Util.dateConverterUS(userProfileDetails?.doj) === null ? '' : <p><b>DoJ : </b>{Util.dateConverterUS(userProfileDetails?.doj) || ''}</p>}

                        <p>
                            <b className='capitalize'>
                                Reports to : <span style={{ textTransform: 'capitalize' }}>{userProfileDetails?.superior?.firstName || ''} {userProfileDetails?.superior?.lastName || ''}</span>
                            </b>
                            ({userProfileDetails?.superior?.Designation?.title || ''})
                        </p>

                        <p className='links'>
                            <span>
                                <i className="pi pi-phone" />
                                {userProfileDetails?.phone || ''}
                            </span>
                            <span>
                                <i className="pi pi-envelope" />
                                {userProfileDetails?.email || ''}
                            </span>
                            <span>
                                {userProfileDetails.length > 0 ? (
                                    <span>
                                        <i className="pi pi-home" />
                                        {userProfileDetails?.[0]?.currentAddress || ""}{" "}
                                        {userProfileDetails?.[0]?.currentAddress1 || ""}{" "}
                                        {userProfileDetails?.[0]?.currentCity || ""}{" "}
                                        {userProfileDetails?.[0]?.currentState || ""}{" "}
                                        {userProfileDetails?.[0]?.currentCountry || ""}{" "}
                                        {userProfileDetails?.[0]?.currentPincode || ""}{" "}
                                    </span>
                                ) : (
                                    ""
                                )}
                            </span>
                        </p>

                        <p className="links">
                            <span>
                                {userProfileDetails.length > 0 ? (
                                    <span>
                                        <i className="pi pi-envelope" />
                                        <b>Alternate Email : </b>
                                        {userProfileDetails?.[0]?.alternateEmail}
                                    </span>
                                ) : (
                                    ""
                                )}
                            </span>
                            <span>
                                {userProfileDetails.length > 0 ? (
                                    <span>
                                        <i className="pi pi-phone" />
                                        <b>Alternate Phone No. : </b>
                                        {userProfileDetails?.[0]?.alternatePhone}
                                    </span>
                                ) : (
                                    ""
                                )}
                            </span>
                        </p>

                        <p className="links">
                            {userProfileDetails.length > 0 ? (
                                <span>
                                    <i className="pi pi-home" />
                                    <b>Permanent Address : </b>
                                    {userProfileDetails?.[0]?.permanentAddress || ""}{" "}
                                    {userProfileDetails?.[0]?.permanentAddress1 || ""}{" "}
                                    {userProfileDetails?.[0]?.permanentCity || ""}{" "}
                                    {userProfileDetails?.[0]?.permanentState || ""}{" "}
                                    {userProfileDetails?.[0]?.permanentCountry || ""}{" "}
                                    {userProfileDetails?.[0]?.permanentPincode || ""}{" "}
                                </span>
                            ) : (
                                ""
                            )}
                        </p>
                    </div>
                </div>
            </div>
        </Fragment>
    );
}

export default Profile;