import React, { Fragment, useState } from 'react'
import { useEffect } from 'react';
import { Util } from '../../../services';
import { professionalService } from '../../../services/profile';
import { skillService } from '../../../services/profile';
import { projectService } from '../../../services/profile';
import { educationalService } from '../../../services/profile';
import { certificateService } from '../../../services/profile';

const NewProfile = ({ getRowId }) => {
  const [heading, setHeading] = useState([]);
  const [skill, setSkill] = useState([]);
  const [project, setProject] = useState([]);
  const [edu, setEdu] = useState([]);
  const [certificate, setCertificate] = useState([]);
  let count = 0;

  useEffect(() => {
  
    if(count===0){
    getHeadingById(getRowId);
    get_skillsById(getRowId);
    get_projectsById(getRowId);
    get_educationalById(getRowId);
    get_certificateById(getRowId);
    count++;
  }
  }, [getRowId])

  // useEffect(() => {
  //   getHeadingById(getRowId);
  // }, [])

  // useEffect(() => {
  //   get_skillsById(getRowId);
  // }, []);

  // useEffect(() => {
  //   get_projectsById(getRowId);
  // }, []);

  // useEffect(() => {
  //   get_educationalById(getRowId);
  // }, [])

  // useEffect(() => {
  //   get_certificateById(getRowId);
  // }, [])

  const getHeadingById = (data) => {
    professionalService.getProfessionalById(data).then(resp => {
      setHeading(resp.data.data);
    });
  };


  const get_skillsById = (data) => {
    skillService.getSkillsById(data).then((resp) => {
      setSkill(resp.data.data);
    });
  };

  const get_projectsById = (data) => {
    projectService.getProjectsById(data).then(resp => {
      setProject(resp.data.data);
    });
  };

  const get_educationalById = (data) => {
    educationalService.getEducationalById(data).then(resp => {
      setEdu(resp.data.data);
    });
  };

  const get_certificateById = (data) => {
    certificateService.getCertificateById(data).then(resp => {
      setCertificate(resp.data.data);
    });
  };

  return (
    <Fragment>
      <div className='wrapper p-3 mt-3'>
        <div className='grid'>
          <div className='col'>
            <span className='heading'>
              Profile Heading
            </span>
          </div>
        </div>
        {heading.map(item =>
          <span style={{ color: 'black' }}>{item.heading}</span>
        )}
      </div>

      <div className='wrapper p-3 mt-3'>
        <div className='grid'>
          <div className='col'>
            <span className='heading'>
              Profile Summary
            </span>
          </div>
        </div>
        {heading.map(item =>
          <span style={{ color: 'black' }}>{item.summary}</span>
        )}
      </div>

      <div className='wrapper p-3 mt-3'>
        <div className='grid'>
          <div className='col'>
            <span className='heading'>
              Others
            </span>
          </div>
        </div>
        {heading.map(item =>
          <div>
            <div className='mb-2' style={{ color: 'black' }}>
              {item?.linkedinURL && <span>
                <strong>Linkedin URL: </strong>
                <a href={'http://' + item.linkedinURL}>{item.linkedinURL}</a><br />
              </span>}

              {item?.gitURL && <span>
                <strong>Git URL: </strong>
                <a href={'http://' + item.gitURL}>{item.gitURL}</a><br />
              </span>}

              {item?.websiteURL && <span>
                <strong>Website URL: </strong>
                <a href={'http://' + item.websiteURL}>{item.websiteURL}</a><br />
              </span>}

              {item?.otherURL && <span>
                <strong>Other URL: </strong>
                <a href={'http://' + item.otherURL}>{item.otherURL}</a><br />
              </span>}
            </div>
          </div>
        )}
      </div>

      <div className='wrapper p-3 mt-3'>
        <div className='grid'>
          <div className='col'>
            <span className='heading'>
              Skills
            </span>
          </div>
        </div>
        {skill.map(item =>
          <span style={{ color: 'black' }}>{item.title}</span>
        )}
      </div>

      <div className='wrapper p-3 mt-3'>
        <div className='grid'>
          <div className='col'>
            <span className='heading'>
              Projects
            </span>
          </div>
        </div>
        {project.map(item =>
          <div className='project-wrapper'>
            <div className='profile-body'>{item.title}</div>
            <div className='mb-1 mt-1'>{Util.dateConverterUS(item.startDate)} to {Util.dateConverterUS(item.endDate)}</div>
            <div style={{ color: 'black' }}>{item.description}</div>
            <div style={{ color: 'black' }}><strong>Client: </strong>{item.client}</div>
            <div style={{ color: 'black' }}><strong>Role: </strong>{item.role}</div>
            <div style={{ color: 'black' }}><strong>Team Size: </strong>{item.teamSize}</div>
            <div style={{ color: 'black' }}><strong>Skills: </strong>{item.skills}</div>
          </div>
        )}
      </div>

      <div className='wrapper p-3 mt-3'>
        <div className='grid'>
          <div className='col'>
            <span className='heading'>
              Education
            </span>
          </div>
        </div>
        {edu.map(item =>
          <div className='project-wrapper'>
            <div className='profile-body'>{item.school}</div>
            <div style={{ color: 'black' }} className='mb-1 mt-1'>{item.degree + ", " + item.field}</div>
            <div>{Util.dateConverterUS(item.startDate)} to {Util.dateConverterUS(item.endDate)}</div>
            <div className='mb-2 mt-2' style={{ color: 'black' }}><strong>Grade: </strong>{item.grade}</div>
            <div className='mt-2' style={{ color: 'black' }}>{item.description}</div>
          </div>
        )}
      </div>

      <div className='wrapper p-3 mt-3'>
        <div className='grid'>
          <div className='col'>
            <span className='heading'>
              Certification
            </span>
          </div>
        </div>
        {certificate.map(item =>
          <div className='project-wrapper'>
            <div className='profile-body'>{item.title}</div>
            <div className='mb-2 mt-2' style={{ color: 'black' }}>{item.issuingOrganization}</div>
            <div>Issued {item.issueDate ? Util.dateConverterUS(item.issueDate) : 'N/A'}</div>
            <div className='mt-2'>
              <a href={'http://' + item.credentialUrl}>{item.credentialUrl}</a>
            </div>
          </div>
        )}
      </div>
    </Fragment>
  )
}

export default NewProfile;