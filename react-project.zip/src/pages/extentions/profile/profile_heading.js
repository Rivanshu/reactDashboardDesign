import React, { Fragment, useState } from 'react';
import { Button } from 'primereact/button';
import { InputTextarea } from 'primereact/inputtextarea';
import { InputText } from 'primereact/inputtext';
import { Dialog } from 'primereact/dialog';
import { useFormik } from 'formik';
import { useEffect } from 'react';
import { professionalService } from '../../../services/profile';
import { classNames } from 'primereact/utils';
import { Util } from '../../../services';
import properties from '../../../config/environmentProperties';

function ProfileHeading() {
    const [headingData, setHeadingData] = useState([]);
    const [showNewForm, setShowNewForm] = useState(false);
    const [showMessage, setShowMessage] = useState(false);
    const [formData, setFormData] = useState({});
    const [editData, setEditData] = useState({});
    const [count1, setCount1] = React.useState(1000);
    const [count2, setCount2] = React.useState(1000);
    const [resumePath, setResumePath] = useState("");
    const [isHeading, setHeading] = useState(false);
    const [isSummary, setSummary] = useState(false);
    const [isOther, setOther] = useState(false);
    const [headerName, setHeaderName] = useState("");
    const resPath = properties.currentEnvironment.docPath + 'resumes/';

    const formik = useFormik({
        initialValues: {
            id: 0,
            heading: '',
            summary: '',
            linkedinURL: '',
            gitURL: '',
            websiteURL: '',
            otherURL: '',
            resume: ''
        },
        validate: (data) => {
            let errors = {};
            // if (!data?.heading) { errors.heading = 'Heading is required.'; }
            // if (!data?.summary) { errors.summary = 'Summary is required.'; }

            // if (!data?.linkedinURL) { errors.linkedinURL = 'Linkedin url is required.'; }
            // else if (!Util.validURL(data.linkedinURL)) { errors.linkedinURL = 'Invalid linkedin url. E.g. www.example.com'; }

            // if (!data?.gitURL) { errors.gitURL = 'Git url is required.'; }
            // else if (!Util.validURL(data.gitURL)) { errors.gitURL = 'Invalid git url. E.g. www.example.com'; }

            // if (!data.websiteURL) { errors.websiteURL = 'Website url is required.'; }
            // else if (!Util.validURL(data.websiteURL)) { errors.websiteURL = 'Invalid website url. E.g. www.example.com'; }

            // if (!data.otherURL) { errors.otherURL = 'Other url is required.'; }
            // else if (!Util.validURL(data.otherURL)) { errors.otherURL = 'Invalid other url. E.g. www.example.com'; }

            return errors;
        },
        onSubmit: async (data) => {
            setFormData(data);
            setShowMessage(true);
            let dataObj = { ...data }
            // In case of data found
            if (headingData.length > 0) {
                dataObj.id = editData.id;
                await update_heading(dataObj);
            } else {
                await add_heading(dataObj)
            }
            get_heading();
            //formik.resetForm();
        }
    });

    const isFormFieldValid = (name) => !!(formik.touched[name] && formik.errors[name]);
    const getFormErrorMessage = (name) => {
        return isFormFieldValid(name) && <small className="p-error">{formik.errors[name]}</small>;
    };

    const uploadResume = async (e) => {
        const file = e.target.files[0];
        const base64 = await Util.convertBase64(file);
        // const reqBody = { resume: base64 };
        formik.setFieldValue('resume', base64);
        // update_heading(reqBody);
    };

    const clearForm = () => {
        setEditData({});
    };

    const createForm = () => {
        setShowNewForm(true);
    };

    const closeForm = () => {
        formik.setFieldValue("heading", editData ? editData.heading : '');
        formik.setFieldValue("summary", editData ? editData.summary : '');
        formik.setFieldValue("linkedinURL", editData ? editData.linkedinURL : '');
        formik.setFieldValue("gitURL", editData ? editData.gitURL : '');
        formik.setFieldValue("websiteURL", editData ? editData.websiteURL : '');
        formik.setFieldValue("otherURL", editData ? editData.otherURL : '');
        formik.setFieldValue("resume", editData ? editData.resume : '');
        setShowNewForm(false);
    };

    const add_heading = (data) => {
        setShowNewForm(false);
        return new Promise(resolve => {
            professionalService.addProfessional(data).then((resp) => {
                const resumeUrl = resPath + resp.data.data.resume;
                setResumePath(resumeUrl);
                resolve(resp);
            });
        })
    };

    const update_heading = (data) => {
        setShowNewForm(false);
        return new Promise(resolve => {
            professionalService.updateProfessional(data).then((resp) => {
                const resumeUrl = resPath + resp.data.data.resume;
                setResumePath(resumeUrl);
                resolve(resp);
            });
        })
    };

    let count = 0;

    useEffect(() => {
        if (count === 0){
            count++;
        const resumeUrl = resPath + headingData[0]?.resume;
        setResumePath(resumeUrl);
        get_heading();
        }
    }, [])

    const get_heading = () => {
        professionalService.getProfessional().then(resp => {
            setHeadingData(resp.data.data);
            if (resp.data.data.length > 0) {
                setEditData(resp.data.data[0]);
                formik.setFieldValue("heading", resp.data.data[0].heading);
                formik.setFieldValue("summary", resp.data.data[0].summary);
                formik.setFieldValue("linkedinURL", resp.data.data[0].linkedinURL);
                formik.setFieldValue("gitURL", resp.data.data[0].gitURL);
                formik.setFieldValue("websiteURL", resp.data.data[0].websiteURL);
                formik.setFieldValue("otherURL", resp.data.data[0].otherURL);
                formik.setFieldValue("resume", resp.data.data[0].resume);
            }
        });
    };

    const changeHandler = (e) => {
        if (e === 0) {
            setHeading(true);
            setSummary(false);
            setOther(false);
        }
        if (e === 1) {
            setHeading(false);
            setSummary(true);
            setOther(false);
        }
        if (e === 2) {
            setHeading(false);
            setSummary(false);
            setOther(true);
        }
        createForm();
    }

    const AddEditHeading = () => {
        return (
            <Fragment>
                <div className="flex align-items-center flex-column px-3">
                    <Dialog
                        header={headerName}
                        visible={showNewForm}
                        style={{ width: '500px' }}
                        closeForm={() => setShowNewForm(false)}
                        addHeading={(data) => add_heading(data)}
                        editData={editData}
                        updateHeading={async (data) => await update_heading(data)}
                        clearForm={clearForm}
                        onHide={() => setShowNewForm(false)}>

                        <form onSubmit={formik.handleSubmit} className="p-fluid p-grid" >

                            {isHeading ? <div className='p-field'>
                                <span>
                                    <label htmlFor="heading">Heading:</label>
                                    <InputTextarea
                                        id="heading"
                                        name="heading"
                                        maxLength={1000}
                                        onChange={(e) => { formik.handleChange(e); setCount1(e.target.value.length) }}
                                        autoResize
                                        value={formik.values.heading}
                                        placeholder="Enter heading"
                                        className={classNames({ 'p-invalid': isFormFieldValid('heading') })} />
                                </span>
                                {getFormErrorMessage('heading')}
                                <span style={{ float: "right" }}>{count1 === 1000 ? 1000 : 1000 - count1} Character(s) Left</span>
                            </div> : null}

                            {isSummary ? <div className='p-field'>
                                <span>
                                    <label htmlFor="summary">Summary:</label>
                                    <InputTextarea
                                        id="summary"
                                        name="summary"
                                        maxLength={1000}
                                        onChange={(e) => { formik.handleChange(e); setCount2(e.target.value.length) }}
                                        autoResize
                                        value={formik.values.summary}
                                        placeholder="Enter summary"
                                        className={classNames({ 'p-invalid': isFormFieldValid('summary') })} />
                                </span>
                                {getFormErrorMessage('summary')}
                                <span style={{ float: "right" }}>{count2 === 1000 ? 1000 : 1000 - count2} Character(s) Left</span>
                            </div> : null}

                            {isOther ?
                                <div>
                                    <div className='p-field'>
                                        <span>
                                            <label htmlFor="linkedinURL">Linkedin URL:</label>
                                            <InputText
                                                id="linkedinURL"
                                                name="linkedinURL"
                                                value={formik.values.linkedinURL}
                                                onChange={formik.handleChange}
                                                placeholder="Enter linkedin url"
                                                className={classNames({ 'p-invalid': isFormFieldValid('linkedinURL') })} />
                                        </span>
                                        {getFormErrorMessage('linkedinURL')}
                                    </div>
                                    <div className='p-field'>
                                        <span>
                                            <label htmlFor="gitURL">Git URL:</label>
                                            <InputText
                                                id="gitURL"
                                                name="gitURL"
                                                value={formik.values.gitURL}
                                                onChange={formik.handleChange}
                                                placeholder="Enter git url"
                                                className={classNames({ 'p-invalid': isFormFieldValid('gitURL') })} />
                                        </span>
                                        {getFormErrorMessage('gitURL')}
                                    </div>
                                    <div className='p-field'>
                                        <span>
                                            <label htmlFor="websiteURL">Website URL:</label>
                                            <InputText
                                                id="websiteURL"
                                                name="websiteURL"
                                                value={formik.values.websiteURL}
                                                onChange={formik.handleChange}
                                                placeholder="Enter website url"
                                                className={classNames({ 'p-invalid': isFormFieldValid('websiteURL') })} />
                                        </span>
                                        {getFormErrorMessage('websiteURL')}
                                    </div>
                                    <div className='p-field'>
                                        <span>
                                            <label htmlFor="otherURL">Other URL:</label>
                                            <InputText
                                                id="otherURL"
                                                name="otherURL"
                                                value={formik.values.otherURL}
                                                onChange={formik.handleChange}
                                                placeholder="Enter other url" />
                                        </span>
                                    </div>
                                    <div className='p-field'>
                                        <span>
                                            <label htmlFor="resume">Resume:</label>
                                            <InputText
                                                type="file"
                                                accept=".pdf"
                                                onChange={(e) => { uploadResume(e); }} />
                                        </span>
                                    </div>
                                </div>
                                : null}

                            <div className={isOther ? 'pt-3' : 'pt-5'}>
                                <div className='grid' style={{ float: 'right' }}>
                                    <div className='mr-2 mt-1'>
                                        <Button type="button" label="Cancel" className="p-button-rounded p-button-secondary" onClick={() => closeForm()} />
                                    </div>
                                    <div className='mt-1'>
                                        <Button type="submit" label="Save" className="p-button-rounded " />
                                    </div>
                                </div>
                            </div>
                        </form>
                    </Dialog>
                </div>
            </Fragment>
        )
    }

    return (
        <Fragment>
            {AddEditHeading()}
            <div className='wrapper p-3'>
                <div className='grid'>
                    <div className='col'>
                        <span className='heading'>
                            Profile Heading
                            <div className='heading-actions'>
                                <Button
                                    label={headingData.length > 0 ? "Edit" : "Add"}
                                    disabled
                                    className="p-button-text" />
                                <Button
                                    icon={headingData.length > 0 ? "pi pi-pencil" : "pi pi-plus"}
                                    onClick={() => {
                                        headingData.length > 0 ? setHeaderName("Update Heading") : setHeaderName("Add Heading")
                                        changeHandler(0)
                                    }
                                    }
                                    className="p-button-rounded p-button circle"
                                    aria-label="Edit" />
                            </div>
                        </span>
                    </div>
                </div>
                {headingData.map(item =>
                    <span style={{ color: 'black' }}>{item.heading}</span>
                )}
            </div>

            <div className='wrapper p-3 mt-3'>
                <div className='grid'>
                    <div className='col'>
                        <span className='heading'>
                            Profile Summary
                            <div className='heading-actions'>
                                <Button
                                    label={headingData.length > 0 ? "Edit" : "Add"}
                                    disabled
                                    className="p-button-text" />
                                <Button
                                    icon={headingData.length > 0 ? "pi pi-pencil" : "pi pi-plus"}
                                    onClick={() => {
                                        headingData.length > 0 ? setHeaderName("Update Summary") : setHeaderName("Add Summary")
                                        changeHandler(1)
                                    }
                                    }
                                    className="p-button-rounded p-button circle"
                                    aria-label="Edit" />
                            </div>
                        </span>
                    </div>
                </div>
                {headingData.map(item =>
                    <span style={{ color: 'black' }}>{item.summary}</span>
                )}
            </div>

            <div className='wrapper p-3 mt-3'>
                <div className='grid'>
                    <div className='col'>
                        <span className='heading'>
                            Others
                            <div className='heading-actions'>
                                <Button
                                    label={headingData.length > 0 ? "Edit" : "Add"}
                                    disabled
                                    className="p-button-text" />
                                <Button
                                    icon={headingData.length > 0 ? "pi pi-pencil" : "pi pi-plus"}
                                    onClick={() => {
                                        headingData.length > 0 ? setHeaderName("Update Others") : setHeaderName("Add Others")
                                        changeHandler(2)
                                    }
                                    }
                                    className="p-button-rounded p-button circle"
                                    aria-label="Edit" />
                            </div>
                        </span>
                    </div>
                </div>
                {headingData.map(item =>
                    <div>
                        <div className='mb-2' style={{ color: 'black' }}>
                            {item?.linkedinURL && <span>
                                <strong>Linkedin URL: </strong>
                                <a href={'http://' + item.linkedinURL}>{item.linkedinURL}</a><br />
                            </span>}

                            {item?.gitURL && <span>
                                <strong>Git URL: </strong>
                                <a href={'http://' + item.gitURL}>{item.gitURL}</a><br />
                            </span>}

                            {item?.websiteURL && <span>
                                <strong>Website URL: </strong>
                                <a href={'http://' + item.websiteURL}>{item.websiteURL}</a><br />
                            </span>}

                            {item?.otherURL && <span>
                                <strong>Other URL: </strong>
                                <a href={'http://' + item.otherURL}>{item.otherURL}</a><br />
                            </span>}
                        </div>
                    </div>
                )}
            </div>
        </Fragment>
    );
}

export default ProfileHeading;