import React from 'react'

function ChangePassword() {
    return (
        <div>ChangePassword</div>
    )
}

export default ChangePassword