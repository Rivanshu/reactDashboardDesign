import NoPermission from './no-permission/noPermission';
import PageNotFound from './page-not-found/pageNotFound';
import UnAuthorized from './un-authorized/unAuthorized';
import ChangePassword from './change-password/change-password';

import Profile from './profile/profile';
import UserManagement from './user-management';
import { UserDashboard } from './user-management/dashboard';
import { Role } from './user-management/role/role';
import { Permission } from './user-management/permission/permission';
import { RolePermission } from './user-management/role-permission/rolePermission';
import { UserMaintenance } from './user-management/user/userMaintenance';
import { UserManager } from './user-management/user-manager/userManager';

const userManagement = new UserManagement();

export {
    NoPermission, PageNotFound, UnAuthorized, ChangePassword, Profile,
    UserDashboard, UserMaintenance, RolePermission, Permission, Role,
    userManagement, UserManager
}