import React from 'react'

function UnAuthorized() {
    return (
        <div>unAuthorized</div>
    )
}

export default UnAuthorized;