import React, { useState, useEffect } from "react";
import { classNames } from "primereact/utils";
import { Dropdown } from "primereact/dropdown";
import { userService, permissionService, roleService, domainService } from "../../../../services/extensions";
import { DataTable } from "primereact/datatable";
import { Column } from "primereact/column";
import { InputText } from "primereact/inputtext";
import { Button } from "primereact/button";
import { useFormik } from "formik";
import UtilitiesService from "../../../../services/util";

export const RolePermission = () => {
  const [permissions, setPermissions] = useState([]);
  const [domainPermissions, setDomainPermissions] = useState([]);
  const [roles, setRoles] = useState([]);
  const [selAssignedPermissions, setSelAssignedPermissions] = useState([]);
  const [selDomainPermissions, setSelDomainPermissions] = useState([]);
  const [domains, setDomains] = useState([]);
  const [roleSelected, setRoleSelected] = useState(false);
  const util = new UtilitiesService();
  const formik = useFormik({
    initialValues: {
      role: null,
      domain: null,
      action: null,
      instance: null,
    },
    onSubmit: (data) => {
      formik.resetForm();
    },
  });

  const isFormFieldValid = (name) =>
    !!(formik.touched[name] && formik.errors[name]);
  const getFormErrorMessage = (name) => {
    return (
      isFormFieldValid(name) && (
        <small className="p-error">{formik.errors[name]}</small>
      )
    );
  };

  useEffect(() => {
    getRoles();
    getDomains();
  }, []);

  const getRoles = () => {
    roleService.getRoles().then((resp) => {
      setRoles(resp.data.data);
    });
  };

  const getPermissions = (roleId) => {
    permissionService.getRolePermission(roleId).then((resp) => {
      setPermissions(resp.data.data.RolePermissions);
      setRoleSelected(true)
    });
  };

  const getDomains = () => {
    domainService.getDomains().then((resp) => {
      setDomains(resp.data.data);
    });
  };

  const getDomainPermissions = (domainId) => {
    permissionService.getDomainPermissions(domainId).then((resp) => {
      setDomainPermissions(resp.data.data);
    });
  }

  const changeEvent = (e) => {
    formik.handleChange(e);
    switch (e.target.name) {
      case 'role':
        getPermissions(e.target.value?.id);
        setSelAssignedPermissions([]);
        break;
      case 'domain':
        getDomainPermissions(e.target.value?.domain_code);
        setSelDomainPermissions([]);
        break;
      default:
      // 
    }

  };

  const removePermission = () => {
    const permId = selAssignedPermissions.map(x => { return x.permission_id })
    const roleId = formik.values?.role?.id;
    permissionService.removePermission(roleId, permId.join("-")).then(resp => {
      setSelAssignedPermissions([]);
      getPermissions(roleId);
    }).catch(c => {
      console.log("Response", c)
    })
  }

  const addPermission = (v) => {
    const perIds = selDomainPermissions.map(x => { return x.id });
    const payload = { roleId: v.role.id, permissions: perIds };
    if (perIds) {
      permissionService.addRolePermission(payload).then(resp => {
        getPermissions(v.role.id);
        setSelDomainPermissions([]);
      }).catch(c => {
        console.log("Response", c)
      });
    }

  }

  return (
    <div className="p-3">
      <div className="grid">
        <div className="col">
          <div className="card-container p-3">
            <h1>Role Selection</h1>
            <div className="p-fluid">
              <div className="field">
                <label className={classNames({ "p-error": isFormFieldValid("role"), })}>Role</label>
                <span className="p-float-label">
                  <Dropdown style={{ width: '50%' }} id="role" name="role" value={formik.values.role} onChange={(e) => { changeEvent(e); }}
                    options={roles} optionLabel="role_name" placeholder="Select a Role" className={classNames({ "p-invalid": isFormFieldValid("role"), })} />
                </span>
              </div>
              <h1>Assigned Permissions for Role</h1>
              <DataTable value={permissions}
                paginator paginatorTemplate="CurrentPageReport FirstPageLink PrevPageLink PageLinks NextPageLink LastPageLink RowsPerPageDropdown"
                responsiveLayout="scroll"
                currentPageReportTemplate="Showing {first} to {last} of {totalRecords}"
                rows={10} rowsPerPageOptions={[10, 20, 50]}
                selection={selAssignedPermissions} onSelectionChange={e => setSelAssignedPermissions(e.value)} dataKey="permission_id"
              >
                <Column selectionMode="multiple" headerStyle={{ width: '3em' }}></Column>
                <Column field="domain" header="Modules" body={(rowData, options) => {
                  return util.initialCapital(rowData['Permission'][options.field], true, true)
                }} sortable></Column>
                {/* <Column field="Permission.action" header="Action" sortable></Column> */}
                <Column field="Permission.description" header="Description" sortable ></Column>
              </DataTable>
            </div>
            <div className="mt-3">
              <Button className="pt-2 p-button-rounded" label="Remove" onClick={removePermission} disabled={selAssignedPermissions.length == 0} />
            </div>
          </div>
        </div>
        <div className="col">
          <div className="card-container p-3">
            <h1>Search Available Permissions</h1>
            <div className="grid">
              <div className="col field">
                <label className={classNames({ "p-error": isFormFieldValid("domain"), })}>Modules</label>
                <span className="p-float-label">
                  <Dropdown id="domain" name="domain" value={formik.values.domain} onChange={(e) => { changeEvent(e); }} disabled={!formik.values.role}
                    options={domains} optionLabel="display_label" placeholder="Select a Domain" className={classNames({ "p-invalid": isFormFieldValid("domain"), })} />
                </span>
                {getFormErrorMessage("domain")}
              </div>
            </div>
            <div className="grid">
              <div className="col-12">
                <DataTable value={domainPermissions}
                  paginator responsiveLayout="scroll" disabled={!formik.values.domain}
                  selection={selDomainPermissions} onSelectionChange={e => setSelDomainPermissions(e.value)} dataKey="id"
                  paginatorTemplate="CurrentPageReport FirstPageLink PrevPageLink PageLinks NextPageLink LastPageLink RowsPerPageDropdown"
                  currentPageReportTemplate="Showing {first} to {last} of {totalRecords}" rows={10} rowsPerPageOptions={[10, 20, 50]}>
                  <Column selectionMode="multiple" headerStyle={{ width: '3em' }}></Column>
                  <Column field="domain" header="Modules" sortable body={(rowData, options) => {
                    return util.initialCapital(rowData[options.field], true, true)
                  }}></Column>
                  {/* <Column field="action" header="Action" sortable></Column> */}
                  <Column field="description" header="Description" sortable></Column>
                </DataTable>
              </div>
              <div className="col-12">
                <Button className="pt-2 p-button-rounded" onClick={() => addPermission(formik.values)} label="Add" disabled={selDomainPermissions.length == 0} />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
