import React, { useState, useEffect, useRef } from "react";
import { Fragment } from "react";
import { classNames } from "primereact/utils";
import { ErrorMessage, useFormik } from "formik";
import { DataTable } from "primereact/datatable";
import { Column } from "primereact/column";
import { InputText } from "primereact/inputtext";
import { InputTextarea } from "primereact/inputtextarea";
import { userService, roleService } from "../../../../services/extensions";
import { Button } from "primereact/button";
import { Dialog } from "primereact/dialog";
import { toast } from "react-toastify";
import { confirmDialog } from "primereact/confirmdialog";

const projects = ["TDS", "Timesheet", "Organisation - Bench"];
export const Role = () => {
  const [roles, setRoles] = useState([]);
  const [users, setUsers] = useState([]);
  const [showMessage, setShowMessage] = useState(false);
  const [showUsers, setShowUsers] = useState(false);
  const [currentRole, setCurrentRole] = useState({});
  const [newForm, setNewForm] = useState(false);

  const formik = useFormik({
    initialValues: {
      role_name: null,
      description: null,
    },
    validate: (data) => {
      let errors = {};

      if (!data.role_name) {
        errors.role_name = "Role is required.";
      }
      return errors;
    },
    onSubmit: (data) => {
      setShowMessage(true);
      // formik.resetForm();
      createRoles(data);
      clearRoleForm();
    },
  });

  const isFormFieldValid = (name) =>
    !!(formik.touched[name] && formik.errors[name]);
  const getFormErrorMessage = (name) => {
    return (
      isFormFieldValid(name) && (
        <small className="p-error">{formik.errors[name]}</small>
      )
    );
  };

  useEffect(() => {
    getRoles();
  }, []);

  const getRoles = () => {
    roleService.getRoles().then((resp) => {
      setRoles(resp.data.data);
    });
  };

  const clearRoleForm = () => {
    formik.setFieldValue("role_name", "");
    formik.setFieldValue("description", "");
  }

  const deleteRole = (e, rowData) => {
    confirmDialog({
      target: e.cuurentTarget,
      message: "Are you sure you want to proceed?",
      header: "Confirmation",
      icon: "pi pi-exclamation-triangle",
      accept: () => {
        roleService.deleteRole(rowData.id).then(
          (resp) => {
            toast.success("Role deleted successfully");
            getRoles();
          },
          (error) => { }
        );
      },
      reject: () => { },
    });
  };

  const ActionBody = (rowData, options) => {
    return (
      <Fragment>
        <Button
          icon="pi pi-pencil"
          className="p-button-rounded p-button-secondary p-button-text"
          onClick={() => {
            setNewForm(true);
          }}
        />
        <Button
          icon="pi pi-trash"
          className="p-button-rounded p-button-danger p-button-text"
          onClick={(e) => deleteRole(e, rowData)}
        />
        <Button
          icon="pi pi-users"
          className="p-button-rounded p-button-success p-button-text"
          onClick={() => onShow(rowData)}
        />
      </Fragment>
    );
  };

  const onHide = () => {
    setShowUsers(false);
  };

  const onShow = (rowData) => {
    // console.log(">>>", rowData)
    // getUsers();
    setCurrentRole(rowData);
    setShowUsers(true);
  };

  const getUsers = () => {
    userService.getUsers().then((resp) => {
      setUsers(resp.data);
    });
  };

  const createRoles = (data) => {
    // console.log("Role", data);

    try {
      roleService.createRoles(data).then((resp) => {
        if (resp.data.success) {
          toast.success("Role successfully created");
          getRoles();
        }
      });
    } catch (error) {
      console.log("Catch Error :", error);
    }
  };

  const cancelHandler = () => {
    formik.resetForm();
    setNewForm(false);
  };

  const NewRoleForm = () => {
    return (
      <form onSubmit={formik.handleSubmit}>
        <div className="p-fluid">
          <div className="field">
            <label
              className={classNames({
                "p-error": isFormFieldValid("role_name"),
              })}
            >
              Role
            </label>
            <span className="p-float-label p-input-icon-right">
              <InputText
                id="role_name"
                name="role_name"
                value={formik.values.role_name}
                onChange={formik.handleChange}
                className={classNames({
                  "p-invalid": isFormFieldValid("role_name"),
                })}
                placeholder="Enter your role"
              />
            </span>
            {getFormErrorMessage("role_name")}
          </div>
          <div className="field">
            <label
              className={classNames({
                "p-error": isFormFieldValid("description"),
              })}
            >
              Description
            </label>
            <span className="p-float-label">
              <InputTextarea
                id="description"
                name="description"
                rows={5}
                cols={30}
                value={formik.values.description}
                onChange={formik.handleChange}
                className={classNames({
                  "p-invalid": isFormFieldValid("description"),
                })}
                placeholder="Enter your description"
              />
            </span>
            {getFormErrorMessage("description")}
          </div>
        </div>
        <div className="col-12">
          <Button className="pt-2 p-button-rounded" label="Edit Role" />
          <Button
            type="button"
            className="pt-2 p-button-rounded p-button-secondary ml-2"
            label="Cancel"
            onClick={cancelHandler}
          />
        </div>
      </form>
    );
  };

  const renderFooter = () => {
    return (
      <div className="pt-3">
        <div className="grid">
          <div className="col" style={{ textAlign: "left" }}>
            <span className="p-input-icon-left">
              <i className="pi pi-search" />
              <InputText placeholder="Search" />
            </span>
          </div>
          <div className="col" style={{ textAlign: "right" }}>
            <Button label="Close" onClick={() => onHide()} autoFocus />
          </div>
        </div>
      </div>
    );
  };

  const accept = () => {
    toast.current.show({
      severity: "info",
      summary: "Confirmed",
      detail: "You have accepted",
      life: 3000,
    });
  };

  const reject = () => {
    toast.current.show({
      severity: "warn",
      summary: "Rejected",
      detail: "You have rejected",
      life: 3000,
    });
  };

  const UserActionBody = (rowData, options) => {
    return (
      <Fragment>
        <Button
          icon="pi pi-trash"
          className="p-button-rounded p-button-danger p-button-text"
        />
      </Fragment>
    );
  };

  const ActiveProjects = (rowData, options) => {
    let res;
    try {
      const d = projects; // rowData.data[options.field] ;
      res = d.map((x) => {
        return (
          <Button
            className={classNames(
              "p-button p-button-sm p-1 m-1",
              "p-button-secondary"
            )}
            label={x}
          />
        );
      });
    } catch (error) {
      console.log("Error", error);
    }
    return res;
  };
  const UserList = () => {
    const headerText = "Users Assigned to Role : [ " + currentRole?.role + " ]";
    return (
      <Fragment>
        <Dialog
          header={headerText}
          visible={showUsers}
          style={{ width: "900px", height: "70vh" }}
          footer={renderFooter()}
          onHide={() => onHide()}
        >
          <DataTable
            value={users}
            paginator
            responsiveLayout="scroll"
            paginatorTemplate="CurrentPageReport FirstPageLink PrevPageLink PageLinks NextPageLink LastPageLink RowsPerPageDropdown"
            currentPageReportTemplate="Showing {first} to {last} of {totalRecords}"
            rows={10}
            rowsPerPageOptions={[10, 20, 50]}
          >
            <Column field="name" header="Name" sortable></Column>
            <Column field="email" header="Email" sortable></Column>
            <Column header="Active Project" body={ActiveProjects}></Column>
            <Column
              header="Actions"
              body={UserActionBody}
              style={{ textAlign: "center", width: "80px" }}
            ></Column>
          </DataTable>
        </Dialog>
      </Fragment>
    );
  };

  const createRole = () => {
    return (
      <Fragment>
        <form onSubmit={formik.handleSubmit}>
          <div className="p-fluid">
            <div className="field">
              <label
                className={classNames({
                  "p-error": isFormFieldValid("role_name"),
                })}
              >
                Role
              </label>
              <span className="p-float-label p-input-icon-right">
                <InputText
                  id="role_name"
                  name="role_name"
                  value={formik.values.role_name}
                  onChange={formik.handleChange}
                  className={classNames({
                    "p-invalid": isFormFieldValid("role_name"),
                  })}
                  placeholder="Enter your role"
                />
              </span>
              {getFormErrorMessage("role_name")}
            </div>
            <div className="field">
              <label
                className={classNames({
                  "p-error": isFormFieldValid("description"),
                })}
              >
                Description
              </label>
              <span className="p-float-label">
                <InputTextarea
                  id="description"
                  name="description"
                  rows={5}
                  cols={30}
                  value={formik.values.description}
                  onChange={formik.handleChange}
                  className={classNames({
                    "p-invalid": isFormFieldValid("description"),
                  })}
                  placeholder="Enter your description"
                />
              </span>
              {getFormErrorMessage("description")}
            </div>
          </div>
          <Button
            type="submit"
            label="Create"
            className="pt-2 p-button-rounded"
          />
          <Button
            type="reset"
            label="Reset"
            className="pt-2 p-button-rounded p-button-secondary mt-2 ml-2"
            onClick={() => clearRoleForm()}
          />
        </form>
      </Fragment>
    );
  };

  return (
    <div className="grid">
      {UserList()}
      <div className="col-8">
        <DataTable
          value={roles}
          // header={UserHeader}
          paginator
          responsiveLayout="scroll"
          paginatorTemplate="CurrentPageReport FirstPageLink PrevPageLink PageLinks NextPageLink LastPageLink RowsPerPageDropdown"
          currentPageReportTemplate="Showing {first} to {last} of {totalRecords}"
          rows={10}
          rowsPerPageOptions={[10, 20, 50]}
        >
          <Column field="role_name" header="Role Name" sortable></Column>
          <Column field="description" header="Description" sortable></Column>
          <Column
            header="Actions"
            body={ActionBody}
            style={{ textAlign: "center", width: "150px" }}
          ></Column>
        </DataTable>
      </div>
      <div className="col-4">
        <div className="card-container p-3">
          <h1>
            {newForm ? "Edit this Role" : "Create Role"}
            {!newForm}
          </h1>
          {newForm ? NewRoleForm() : createRole()}
        </div>
      </div>
      {/* <div className='col-4 p-3'>
        <h1>Create Role</h1>
        <div className="card" style={{ padding: '10px', border: '1px solid #e4ebf2' }}>
          <form onSubmit={formik.handleSubmit}>
            <div className='p-fluid'>
              <div className="field">
                <label className={classNames({ 'p-error': isFormFieldValid('role_name') })}>Role</label>
                <span className="p-float-label p-input-icon-right">
                  <InputText id="role_name" name="role_name" value={formik.values.role_name} onChange={formik.handleChange}
                    className={classNames({ 'p-invalid': isFormFieldValid('role_name') })} placeholder="Enter your role" />
                </span>
                {getFormErrorMessage('role_name')}
              </div>
              <div className="field">
                <label className={classNames({ 'p-error': isFormFieldValid('description') })}>Description</label>
                <span className="p-float-label">
                  <InputTextarea id="description" name="description" rows={5} cols={30}
                    value={formik.values.description} onChange={formik.handleChange}
                    className={classNames({ 'p-invalid': isFormFieldValid('description') })} placeholder="Enter your description" />
                </span>
                {getFormErrorMessage('description')}
              </div>
            </div>
            <Button type="submit" label="Create" className="p-button-sm mt-2" />
            <Button type="reset" label="Reset" className="p-button-sm p-button-secondary mt-2 ml-2" />
          </form>
        </div>
      </div> */}
    </div>
  );
};
