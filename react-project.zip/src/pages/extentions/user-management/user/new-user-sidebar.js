import React, { useState, useEffect, Fragment } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { selectUser } from '../../../../services/store/userSlice';
import { Sidebar } from 'primereact/sidebar';
import { classNames } from 'primereact/utils';
import { DataTable } from 'primereact/datatable';
import { Column } from 'primereact/column';
import { InputText } from 'primereact/inputtext';
import { userService } from '../../../../services/extensions';
import { Checkbox } from 'primereact/checkbox';
import { Button } from 'primereact/button';
import { Dialog } from 'primereact/dialog';
import { PickList } from 'primereact/picklist';
import Profile from '../../profile/profile';
import { useFormik } from 'formik';
import { Password } from 'primereact/password';
import { toast } from 'react-toastify';

import './style.scss';

export const NewUserSidebar = ({ mode = 'employee', show = false, setShow, getUsers }) => {
    const user = useSelector(selectUser);
    const [isEmployeeDashboard, setDashboard] = useState(false);
    const [projects, setProjects] = useState([]);
    const [newForm, setNewForm] = useState(false);
    const [showMessage, setShowMessage] = useState(false);

    const formik = useFormik({
        initialValues: { firstName: '', lastName: '', email: '', password: '', ecn: '', phone: '' },
        validate: (data) => {
            let errors = {};
            if (!data.firstName) { errors.firstName = 'First Name is required.'; }
            if (!data.lastName) { errors.lastName = 'Last Name is required.'; }
            if (!data.email) { errors.email = 'Email is required.'; }
            else if (!/^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,4}$/i.test(data.email)) { errors.email = 'Invalid email address. E.g. example@espire.com'; }
            if (!data.password) { errors.password = 'Password is required.'; }
            if (!data.ecn) { errors.ecn = 'ECN is required.'; }
            if (!data.phone) { errors.phone = 'Phone is required.'; }
            return errors;
        },
        onSubmit: (data) => {
            setShowMessage(true);
            registerUser(data);
            formik.resetForm();
        }
    });

    const isFormFieldValid = (name) => !!(formik.touched[name] && formik.errors[name]);
    const getFormErrorMessage = (name) => {
        return isFormFieldValid(name) && <small className="p-error">{formik.errors[name]}</small>;
    };

    useEffect(() => {
        const empIndex = user.roles.indexOf('employee')
        setDashboard(empIndex !== -1);

    }, [])

    const registerUser = (data) => {
        try {
            userService.register(data).then(resp => {
                if (resp.data.success) {
                    toast.success(resp.data.message);
                } else {
                    toast.success('Process failed while creating new user...');
                }
                formik.resetForm();
                setNewForm(false);
                getUsers();
            }, error => {
                toast.success('Process failed while creating new user...');
            })
        } catch (error) {
            toast.success('Process failed while creating new user...');
        }
    }

    const cancelHandler = () => {
        formik.resetForm();
        setNewForm(false);
    }

    const NewForm = () => {
        return (
            <form onSubmit={formik.handleSubmit}>
                <div className='grid p-fluid'>
                    <div className="col-12 field">
                        <label htmlFor="ecn" className={classNames({ 'p-error': isFormFieldValid('ecn') })}>ECN*</label>
                        <span className="p-float-label">
                            <InputText id="ecn" name="ecn"
                                value={formik.values.name} onChange={formik.handleChange}
                                className={classNames({ 'p-invalid': isFormFieldValid('ecn') })} />
                        </span>
                        {getFormErrorMessage('ecn')}
                    </div>
                    <div className="col-12 field">
                        <label htmlFor="firstName" className={classNames({ 'p-error': isFormFieldValid('firstName') })}>First Name*</label>
                        <span className="p-float-label">
                            <InputText id="firstName" name="firstName"
                                value={formik.values.name} onChange={formik.handleChange}
                                className={classNames({ 'p-invalid': isFormFieldValid('firstName') })} />
                        </span>
                        {getFormErrorMessage('firstName')}
                    </div>
                    <div className="col-12 field">
                        <label htmlFor="lastName" className={classNames({ 'p-error': isFormFieldValid('lastName') })}>Last Name*</label>
                        <span className="p-float-label">
                            <InputText id="lastName" name="lastName"
                                value={formik.values.name} onChange={formik.handleChange}
                                className={classNames({ 'p-invalid': isFormFieldValid('lastName') })} />
                        </span>
                        {getFormErrorMessage('lastName')}
                    </div>
                    <div className="col-12 field">
                        <label htmlFor="email" className={classNames({ 'p-error': isFormFieldValid('email') })}>Espire Email*</label>
                        <span className="p-float-label">
                            <InputText id="email" name="email"
                                value={formik.values.name} onChange={formik.handleChange}
                                className={classNames({ 'p-invalid': isFormFieldValid('email') })} />
                        </span>
                        {getFormErrorMessage('email')}
                    </div>
                    <div className="col-12 field">
                        <label htmlFor="phone" className={classNames({ 'p-error': isFormFieldValid('phone') })}>Phone*</label>
                        <span className="p-float-label">
                            <InputText id="phone" name="phone"
                                value={formik.values.name} onChange={formik.handleChange}
                                className={classNames({ 'p-invalid': isFormFieldValid('phone') })} />
                        </span>
                        {getFormErrorMessage('phone')}
                    </div>
                    <div className="col-12 field">
                        <label htmlFor="password" className={classNames({ 'p-error': isFormFieldValid('password') })}>Password*</label>
                        <span className="p-float-label">
                            <Password id="password" name="password" feedback={false}
                                value={formik.values.name} onChange={formik.handleChange}
                                className={classNames({ 'p-invalid': isFormFieldValid('password') })} />
                        </span>
                        {getFormErrorMessage('password')}
                    </div>

                </div>
                <div className='col-12'>
                    <Button className='pt-2 p-button-rounded' label='Add User' />
                    <Button type='button' className='pt-2 p-button-rounded p-button-secondary ml-2' label='Cancel' onClick={cancelHandler} />

                </div>
            </form>
        )
    }


    return (
        <div>
            <Sidebar className='p-sidebar-md' position="right" visible={show} onHide={() => setShow(false)}>
                <h1 className='p-2'>Add User</h1>
                <div className=''>

                </div>
            </Sidebar>
        </div>
    )
}
