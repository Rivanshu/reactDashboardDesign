import React from "react";
import { Button } from "primereact/button";
import { Dropdown } from "primereact/dropdown";
import { useState, useEffect } from "react";
import { timesheetApi, allocationService, Util } from "../../../../services";
import { DataTable } from "primereact/datatable";
import { Column } from "primereact/column";
import { InputText } from "primereact/inputtext";
import { Checkbox } from "primereact/checkbox";
import { Calendar } from "primereact/calendar";
import { Fragment } from "react";
import { toast } from "react-toastify";
import { confirmDialog } from "primereact/confirmdialog";

const UserAllocationDialog = ({ assignAlloc, onClose, projectData }) => {
  const [selectedProject, setSelectedProject] = useState([]);
  const [buttonDisabled, setButtonDisabled] = useState(true);
  const [allocType, setAllocType] = useState([]);
  const [updatedAllocationType, setUpdatedAllocationType] = useState("");
  const [isCount, setIsCount] = useState(1);
  const [employeeList, setEmployeeList] = useState([]);

  let count = 0;

  useEffect(() => {
    if(count === 0) {
      count++;
      getAllocationtypes();
      getManagerUserInfo();
    }
  }, []);

  const getAllocationtypes = () => {
    allocationService.getAllocationtypes().then((resp) => {
      setAllocType(resp.data.data);
    });
  };

  const getManagerUserInfo = () => {
    timesheetApi.getUsersBySuperior().then((resp) => {
      try {
        setEmployeeList(resp.data.data);
      } catch (error) {
        // Error handle
      }
    });
  };

  const onCloseMethod = () => {
    onClose();
  };

  const projectBodyTemplate = (rowData) => {
    return rowData.Project.title;
  };

  const changeBillable = (e) => {
    projectData.map((item) => {
      if (item.id === e.target.id) {
        item.isBillable = !item.isBillable;
      }
    });
    setIsCount(isCount + 1);
  };

  const fetchBillable = (i) => {
    var isBillable;
    projectData.map((item) => {
      if (item.id === i) {
        isBillable = item.isBillable;
      }
    });

    return isBillable;
  };

  const billableBodyTemplate = (rowData) => {
    return (
      <Checkbox
        id={rowData.id}
        checked={rowData.isBillable}
        onChange={changeBillable}
      />
    );
  };

  const deleteBodyTemplate = () => {
    return (
      <React.Fragment>
        <Button
          icon="pi pi-trash"
          className="p-button-rounded p-button-danger" 
          onClick={(e) => deAllocateProject(e)}
          disabled={buttonDisabled}
        ></Button>
      </React.Fragment>
    );
  };

  const selectProjectList = (e) => {
    setSelectedProject(e.value);
    e.value.length > 0 ? setButtonDisabled(false) : setButtonDisabled(true);
  };

  const reject = () => {
    onCloseMethod();
  };

  const deAllocateProject = () => {
    confirmDialog({
      message: "Do you want to deallocate this record?",
      header: "Deallocation Confirmation",
      icon: "pi pi-info-circle",
      acceptClassName: "p-button-danger",
      accept,
      reject,
    });
  };

  const accept = () => {
    let projectId = selectedProject.map((a) => a.id);
    let param = {
      ids: projectId,
    };
    timesheetApi.updateDeallocation(param).then(
      (resp) => {
        if (resp) {
          onClose();
          toast.success("Allocation deleted successfully!");
        }
      },
      (error) => {}
    );
  };

  const endDateEditor = (options) => {
    let dateArray = options.rowData.startDate.split("-");
    let dateObj = new Date(`${dateArray[2]}-${dateArray[1]}-${dateArray[0]}`);
    return (
      <Calendar
        showIcon
        // placeholder="Select end date"
        placeholder={options.value}
        dateFormat="dd-mm-yy"
        value={options.value}
        minDate={dateObj}
        onChange={(e) => options.editorCallback(e.value)}
      />
    );
  };

  const listEditor = (options) => {
    let list = [];
    let field = "title";
    let fieldval = "id";
    switch (options.field) {
      case "allocationType":
        list = allocType;
        fieldval = "id";
        field = "title";
        setUpdatedAllocationType(options.value);
        return (
          <Fragment>
            <Dropdown
              value={options.value}
              options={list}
              optionLabel={field}
              optionValue={fieldval}
              onChange={(e) => options.editorCallback(e.value)}
              placeholder="Select One"
              itemTemplate={(option) => {
                return <span>{option[field]}</span>;
              }}
            />
          </Fragment>
        );
        break;
      case "percentage":
        if (updatedAllocationType === 1) {
          return (
            <InputText
              style={{ width: "50px" }}
              type="integer"
              value="100"
              maxLength="2"
              onChange={(e) => options.editorCallback(parseInt(e.target.value))}
              disabled
            />
          );
        } else if (updatedAllocationType === 2) {
          return (
            <InputText
              style={{ width: "50px" }}
              type="integer"
              value={options.value}
              maxLength="2"
              onChange={(e) =>
                options.editorCallback(
                  parseInt(e.target.value ? e.target.value : 0)
                )
              }
              // onKeyPress={Util.preventCharWithMinus}
              // onPaste={Util.preventPasteChar}
            />
          );
        } else if (updatedAllocationType === 3) {
          return (
            <InputText
              style={{ width: "50px" }}
              type="integer"
              value="0"
              maxLength="2"
              onChange={(e) => options.editorCallback(parseInt(e.target.value))}
              disabled
            />
          );
        } else {
          return options.value ? options.value : 0;
        }
        break;
      case "hours":
        if (updatedAllocationType === 1) {
          return (
            <InputText
              style={{ width: "50px" }}
              type="integer"
              value="0"
              maxLength="2"
              onChange={(e) => options.editorCallback(parseInt(e.target.value))}
              disabled
            />
          );
        } else if (updatedAllocationType === 2) {
          return (
            <InputText
              style={{ width: "50px" }}
              type="integer"
              value="0"
              maxLength="2"
              onChange={(e) => options.editorCallback(parseInt(e.target.value))}
              disabled
            />
          );
        } else if (updatedAllocationType === 3) {
          return (
            <InputText
              style={{ width: "50px" }}
              type="integer"
              value={options.value}
              maxLength="2"
              onChange={(e) =>
                options.editorCallback(
                  parseInt(e.target.value ? e.target.value : 0)
                )
              }
              // onKeyPress={Util.preventCharWithMinus}
              // onPaste={Util.preventPasteChar}
            />
          );
        } else {
          return options.value ? options.value : 0;
        }
        break;
      default:
        return "";
    }
  };

  const listBodyTemplate = (options, name) => {
    let listName = "";
    switch (name) {
      case "alType":
        var obj = allocType.find((x) => {
          return x.id === options.allocationType;
        });
        listName = obj?.title;
        break;
      case "percentage":
        // listName = options.allocationType === 1 ? '100%' : options.allocationType === 2 ? '50%' : options?.percentage;
        listName = options?.percentage;
        break;
      case "hours":
        listName = options?.hour;
        break;
      default:
        listName = "";
    }
    return listName;
  };

  const editRowComplete = (e) => {
    // console.log(e,"eeeeeeeee")
    let _projectData = [...projectData];
    let { newData, index } = e;
    _projectData[index] = newData;

    const allcPercentage =
      _projectData[index].allocationType === 1
        ? 100
        : _projectData[index].allocationType === 2
        ? _projectData[index].percentage
        : 0;

    const allcHours =
      _projectData[index].allocationType === 3 ? _projectData[index].hours : 0;

    let allcEndDate;
    if (e.data.endDate === e.newData.endDate) {
      allcEndDate = e.data.endDate;
    } else {
      allcEndDate = Util.dateConverter(_projectData[index].endDate);
    }

    let param = {
      id: _projectData[index].id,
      allocationType: _projectData[index].allocationType,
      percentage: allcPercentage,
      hour: allcHours,
      endDate: allcEndDate,
      isBillable: fetchBillable(_projectData[index].id),
    };
    try {
      allocationService.updateAllocation(param).then(
        (resp) => {
          if (resp) {
            onClose();
            toast.success("Allocation updated successfully!");
          }
        },
        (err) => {
          toast.error("Unable to update allocation");
        }
      );
    } catch (error) {
      toast.error("Unable to update allocation");
    }
  };

  return (
    <div className="fields">
      {/* <span>
          <Dropdown
            filter
            id="projectId"
            name="projectId"
            value={formik.values.projectId}
            placeholder="Select project"
            options={projects}
            optionValue="projectId"
            optionLabel="title"
            onChange={(e) => {
              changeEvent(e);
            }}
            style={{ width: "360px" }}
            className={classNames({
              "p-invalid": isFormFieldValid("projectId"),
            })}
          />
          {getFormErrorMessage("projectId")}
        </span> */}
      {/* <div className="pt-4">
          <div className="grid" style={{ float: "right" }}>
            <div className="mr-2">
                <Button label="Create Allocation" ></Button>
            </div>
          </div>
        </div> */}
      <div className="grid">
        <div className="col-12">
          {/* <div style={{width: "900px" , height:"200px"}}>  */}
          <DataTable
            responsiveLayout="scroll"
            paginator
            selection={selectedProject}
            onSelectionChange={(e) => selectProjectList(e)}
            paginatorTemplate="CurrentPageReport FirstPageLink PrevPageLink PageLinks NextPageLink LastPageLink RowsPerPageDropdown"
            currentPageReportTemplate="Showing {first} to {last} of {totalRecords}"
            value={projectData}
            rows={10}
            rowsPerPageOptions={[10, 20, 50]}
            dataKey="id"
            editMode="row"
            onRowEditComplete={editRowComplete}
          >
            <Column
              selectionMode="multiple"
              headerStyle={{ width: "4rem" }}
              exportable={false}
            ></Column>
            <Column
              header="Project"
              body={projectBodyTemplate}
              sortable
            ></Column>
            <Column
              header="Allocation Type"
              field="allocationType"
              editor={(options) => listEditor(options)}
              body={(options) => listBodyTemplate(options, "alType")}
            ></Column>
            <Column
              header="Percentage(%)"
              field="percentage"
              editor={(options) => listEditor(options)}
              body={(options) => listBodyTemplate(options, "percentage")}
            ></Column>
            <Column
              header="Hours"
              field="hours"
              editor={(options) => listEditor(options)}
              body={(options) => listBodyTemplate(options, "hours")}
            ></Column>
            <Column
              header="Start Date"
              field="startDate"
            ></Column>
            <Column
              header="End date"
              field="endDate"
              editor={(options) => endDateEditor(options)}
            ></Column>
            <Column
              header="Billable"
              body={billableBodyTemplate}
            ></Column>
            <Column
              rowEditor
            ></Column>
            <Column body={deleteBodyTemplate}></Column>
          </DataTable>
        </div>
      </div>
    </div>
    // </div>
  );
};

export default UserAllocationDialog;
