import React from "react";
import { Button } from "primereact/button";
import { Dropdown } from "primereact/dropdown";
import { useFormik } from "formik";
import { useState, useEffect } from "react";
import { userService } from "../../../../services/extensions";
import { classNames } from "primereact/utils";

const DesignAction = ({ assignDesign, onClose }) => {
  const [designation, setDesignation] = useState([]);
  const [showMessage, setShowMessage] = useState(false);

  const formik = useFormik({
    initialValues: {
      designation: null,
    },
    validate: (data) => {
      let errors = {};
      if (!data.designation) {
        errors.designation = 'Please select designation.';
      }
      return errors;
    },
    onSubmit: (data) => {
      // assignManager(data);
      setShowMessage(true);
      assignDesign(data);
      // formik.resetForm();
    },
  });

  const isFormFieldValid = (name) =>
    !!(formik.touched[name] && formik.errors[name]);
  const getFormErrorMessage = (name) => {
    return (
      isFormFieldValid(name) && (
        <small className="p-error">{formik.errors[name]}</small>
      )
    );
  };

  useEffect(() => {
    getDesignations();
  }, []);

  const onCloseMethod = () => {
    onClose();
  };

  const getDesignations = (param = {}) => {
    userService.getDesignations().then((resp) => {
      setDesignation(resp.data.data);
    });
  };

  const changeEvent = (e) => {
    formik.handleChange(e);
  };

  return (
    <form onSubmit={formik.handleSubmit}>
      <div className="fields">
        <span>
          <Dropdown
            filter
            id="designation"
            name="designation"
            value={formik.values.designation}
            placeholder="Select designation"
            options={designation}
            optionLabel="title"
            onChange={(e) => {
              changeEvent(e);
            }}
            style={{ width: "390px" }}
            className={classNames({ 'p-invalid': isFormFieldValid('designation') })}
          />
          {getFormErrorMessage("designation")}
        </span>
        <div className='pt-4'>
          <div className='grid' style={{ float: 'right' }}>
            <div className='mr-2'>
              <Button
                type="button"
                label="Cancel"
                className="p-button-rounded p-button-secondary"
                onClick={(e) => onCloseMethod(e)}
              />
            </div>
            <div>
              <Button
                type="submit"
                label="Submit"
                className="p-button-rounded"
              />
            </div>
          </div>
        </div>
      </div>
    </form>
  );
};

export default DesignAction;