import React from "react";
import { Button } from "primereact/button";
import { Dropdown } from "primereact/dropdown";
import { useFormik } from "formik";
import { useState, useEffect } from "react";
import { classNames } from "primereact/utils";
import { timesheetApi, allocationService, Util } from "../../../../services";
import { InputText } from "primereact/inputtext";
import { Checkbox } from "primereact/checkbox";
import { Calendar } from "primereact/calendar";
import { toast } from "react-toastify";
import moment from "moment";
import properties from "../../../../config/environmentProperties";

const UserCreateAllocationDialog = ({ onClose, userData, projects }) => {
  const [allocType, setAllocType] = useState([]);
  const [checkBillable, setCheckBillable] = useState(false);
  const imgPath = properties.currentEnvironment.docPath + "images/";

  let count = 0;

  useEffect(() => {
    if(count === 0){
      count++;
      getAllocationTypes();
    }
    }
  , []);

  let userListDetails = [
    {
      name:
        userData.firstName.toUpperCase() +
        " " +
        userData.lastName.toUpperCase(),
      id: userData.id,
      isBillable: checkBillable,
      designation: userData?.Designation?.title,
    },
  ];

  const getAllocationTypes = () => {
    allocationService.getAllocationtypes().then((resp) => {
      setAllocType(resp.data.data);
    });
  };

  const formik = useFormik({
    initialValues: {
      projects: "",
      allocation: null,
      alloc100: true,
      alloc50: false,
      alloc25: false,
      allocOther: "",
      allocPartial: false,
      ot: false,
      hours: "",
      startDate: "",
      endDate: "",
      user: "",
      reason: "",
    },
    validate: (data) => {
      let errors = {};
      if (!data.projects) {
        errors.projects = "Please select project";
      }
      if (!data.startDate) {
        errors.startDate = "Start Date is required*";
      }
      if (!data.endDate) {
        errors.endDate = "End Date is required*";
      }
      if (data.endDate && data.startDate) {
        if (moment(data.startDate) > moment(data.endDate)) {
          errors.endDate = "End Date is must be above than start date";
        }
      }
      return errors;
    },
    onSubmit: (data) => {
      createAllocation(data);
      formik.resetForm();
    },
  });

  const isFormFieldValid = (name) =>
    !!(formik.touched[name] && formik.errors[name]);
  const getFormErrorMessage = (name) => {
    return (
      isFormFieldValid(name) && (
        <small className="p-error">{formik.errors[name]}</small>
      )
    );
  };

  const createAllocation = async (data) => {
    // setShow(false);
    const dataobj = {
      projectId: data.projects.id,
      startDate: moment(data.startDate).format("DD-MM-YYYY"),
      endDate: moment(data.endDate).format("DD-MM-YYYY"),
      allocationType: fetchAllocation(data),
      percentage: fetchPercentage(data),
      hour: data.hours ? parseInt(data.hours) : 0,
      users: userListDetails,
    };
    if (
      formik.values.alloc100 ||
      formik.values.alloc50 ||
      formik.values.alloc25 ||
      formik.values.allocOther > 0 ||
      formik.values.hours > 0
    ) {
      try {
        allocationService.createManagerAllocation(dataobj).then(
          (resp) => {
            onClose();
            toast.success("Allocated successfully");
          },
          (err) => {
            toast.error(err.response.data.error);
          }
        );
      } catch (error) {
        toast.error("Unable to create allocation...");
      }
    } else {
      toast.error("Allocation percentage not selected properly");
    }
  };

  const fetchAllocation = (data) => {

    var code = "100";
    if (data) {
      if (data.alloc100) {
        code = "100";
      } else if (data.allocPartial) {
        code = "PT";
      } else if (data.ot) {
        code = "OT";
      } else {
        code = "";
      }
    }

    var result = allocType.filter((obj) => {
      return obj.code === code;
    });
    return result[0].id;
  };

  const fetchPercentage = (data) => {
    var result = null;
    if (data) {
      if (data.alloc100) {
        result = 100;
      } else if (data.allocPartial) {
        if (data.alloc50) {
          result = 50;
        } else if (data.alloc25) {
          result = 25;
        } else {
          result = data.allocOther;
        }
      } else {
        result = 0;
      }
    }
    return result;
  };

  const allocHandler = (e) => {
    formik.handleChange(e);
    if (e.target.name === "alloc50") {
      formik.setFieldValue("alloc25", false);
      formik.setFieldValue("allocOther", "");
    }
    if (e.target.name === "alloc25") {
      formik.setFieldValue("alloc50", false);
      formik.setFieldValue("allocOther", "");
    }
    if (e.target.name === "allocOther") {
      formik.setFieldValue("alloc50", false);
      formik.setFieldValue("alloc25", false);
    }
    if (!formik.values.ot) {
      formik.values.hours = "";
    }
    if (!formik.values.allocPartial) {
      formik.values.allocOther = "";
    }
    switch (e.target.name) {
      case "allocPartial":
        formik.setFieldValue("alloc100", false);
        formik.setFieldValue("ot", false);
        formik.values.hours = 0;
        break;
      case "alloc100":
        formik.setFieldValue("allocPartial", false);
        formik.setFieldValue("ot", false);
        formik.values.hours = 0;
        break;
      case "ot":
        formik.setFieldValue("alloc100", false);
        formik.setFieldValue("allocPartial", false);
        break;
      default:
      //
    }
  };

  const handleDateChange = (date) => {
    formik.setFieldValue("startDate", date);
    formik.setFieldValue("endDate", "");
  };

  const handleBillable = (e) => {
    if (userData) {
      if (checkBillable) {
        setCheckBillable(false);
      } else {
        setCheckBillable(true);
      }
    }
  };

  return (
    <form onSubmit={formik.handleSubmit} className="mt-5">
      <div className="p-fluid" style={{ paddingBottom: "20px" }}>
        <div className="field">
          <label
            htmlFor="name"
            className={classNames({ "p-error": isFormFieldValid("name") })}
          >
            Project*
          </label>
          <span className="p-float-label">
            <Dropdown
              filter
              id="projects"
              name="projects"
              placeholder="Select Project"
              optionLabel="title"
              // options={filteredProjects}
              options={projects}
              onChange={formik.handleChange}
              value={formik.values.projects}
              appendTo="self"
            />
          </span>
          {getFormErrorMessage("projects")}
        </div>
        <div className="grid date-selection">
          <div className="col">
            <div className="field">
              <label htmlFor="date">Start Date*</label>
              <span className="p-float-label">
                <Calendar
                  type="date"
                  id="date"
                  name="startDate"
                  value={formik.values.startDate}
                  onChange={(e) => handleDateChange(e.target.value)}
                  dateFormat="dd/mm/yy"
                  mask="99/99/9999"
                  showIcon
                  placeholder="Start Date"
                  minDate={new Date()}
                />
                {getFormErrorMessage("startDate")}
              </span>
            </div>
          </div>
          <div className="col">
            <div className="field">
              <label htmlFor="date">End Date*</label>
              <span className="p-float-label">
                <Calendar
                  id="date"
                  type="date"
                  name="endDate"
                  value={formik.values.endDate}
                  onChange={formik.handleChange}
                  dateFormat="dd/mm/yy"
                  mask="99/99/9999"
                  showIcon
                  placeholder="End Date"
                  minDate={new Date(formik.values.startDate)}
                  disabled={!formik.values.startDate}
                />
                {getFormErrorMessage("endDate")}
              </span>
            </div>
          </div>
        </div>

        {userData && (
          <div className="user-container">
            {userListDetails.map((item, i) => {
              return (
                <div className="formgrid grid">
                  <div className="field col-2 mt-2">
                    <div className="flex align-items-center gap-2">
                      {userData?.photo === "" || userData?.photo === null ? (
                        <span
                          className="photo-span"
                          style={{
                            height: "40px",
                            width: "40px",
                            borderRadius: "50%",
                            border: "3px solid #d7e9ff",
                            Top: "16px",
                            bottom: "16px",
                            left: "16px",
                            display: "block",
                            textAlign: "center",
                            fontSize: "22px",
                            fontWeight: "600",
                            color: "#1369b6",
                          }}
                        >
                          {userData.firstName.toUpperCase().substr(0, 1)}
                          {userData.lastName.toUpperCase().substr(0, 1)}
                        </span>
                      ) : (
                        <img
                          style={{
                            height: "50px",
                            width: "50px",
                            borderRadius: "50%",
                            border: "3px solid #d7e9ff",
                            Top: "16px",
                            bottom: "16px",
                            left: "16px",
                          }}
                          src={imgPath + userData?.photo || ""}
                          alt=""
                        />
                      )}
                    </div>
                  </div>

                  <div className="field col-7 mt-3">
                    <span className="userName">
                      <b> {item.name}</b>{" "}
                    </span>
                    <br />
                    <span
                      className="userName"
                    // style={{ paddingRight: "200px" }}
                    >
                      {item.designation}
                    </span>
                  </div>
                  <div className="field col-3 mt-4">
                    <Checkbox
                      // className="userCheckbox"
                      id={item.id}
                      name={item.name}
                      checked={checkBillable}
                      onChange={handleBillable}
                    />
                    <span className="ml-2">Billable </span>
                  </div>
                </div>
              );
            })}
          </div>
        )}

        <div className="grid mt-2">
          <div className="col-4">
            <div className="field-checkbox">
              <Checkbox
                className="commonCheckbox"
                inputId="alloc100"
                name="alloc100"
                checked={formik.values.alloc100}
                onChange={allocHandler}
              />
            </div>
            <label className="checkbox-label" htmlFor="alloc100">
              100% Allocation
            </label>
            {getFormErrorMessage("allocations")}
          </div>
          <div className="col-4">
            <div className="field-checkbox">
              <Checkbox
                className="commonCheckbox"
                inputId="allocPart"
                name="allocPartial"
                checked={formik.values.allocPartial}
                onChange={allocHandler}
              />
            </div>
            <label className="checkbox-label" htmlFor="allocPart">
              Partial Allocation
            </label>
          </div>
          <div className="col-4">
            <div className="field-checkbox mr-4">
              <Checkbox
                className="commonCheckbox"
                inputId="allocOt"
                name="ot"
                checked={formik.values.ot}
                onChange={allocHandler}
              />
            </div>
            <label className="checkbox-label ml-3" htmlFor="allocOt">
              OT
            </label>
          </div>
        </div>
        {formik.values.allocPartial && (
          <div className="partial-container">
            <div className="grid">
              <div className="col-4 pt-4">
                <label htmlFor="all50">50% Allocation</label>
              </div>
              <div className="col-8">
                <div className="field-checkbox">
                  <Checkbox
                    className="commonCheckbox"
                    inputId="alloc50"
                    name="alloc50"
                    checked={formik.values.alloc50}
                    onChange={allocHandler}
                  />
                </div>
              </div>
            </div>
            <div className="grid mt-3">
              <div className="col-4 pt-4">
                <label htmlFor="all50">25% Allocation</label>
              </div>
              <div className="col-8">
                <div className="field-checkbox">
                  <Checkbox
                    className="commonCheckbox"
                    inputId="alloc25"
                    name="alloc25"
                    checked={formik.values.alloc25}
                    onChange={allocHandler}
                  />
                </div>
              </div>
            </div>
            <div className="grid mt-3">
              <div className="col-4 pt-4">
                <label htmlFor="other">Other %</label>
              </div>
              <div className="col-8">
                <InputText
                  inputId="allocOther"
                  name="allocOther"
                  style={{ width: "100px" }}
                  value={formik.values.allocOther}
                  onKeyPress={Util.preventChar}
                  onChange={(e) => {
                    if (e.target.value < 100) {
                      formik.handleChange(e);
                      formik.setFieldValue("alloc50", false);
                      formik.setFieldValue("alloc25", false);
                    }
                  }}
                />
              </div>
            </div>
          </div>
        )}
        {formik.values.ot && (
          <div className="partial-container">
            <div className="grid mt-0">
              <div className="col-4 pt-4">
                <label htmlFor="other">Hours</label>
              </div>
              <div className="col-8">
                <span className="p-float-label">
                  <InputText
                    name="hours"
                    style={{ width: "100px" }}
                    value={formik.values.hours}
                    onKeyPress={Util.preventChar}
                    onChange={(e) => {
                      if (e.target.value < 10) {
                        formik.handleChange(e);
                      }
                    }}
                  />
                </span>
              </div>
            </div>
          </div>
        )}
      </div>
      <div
        className=""
        style={{ textAlign: "right", marginTop: "20px", marginBottom: "10px" }}
      >
        <Button
          type="button"
          label="Cancel"
          className="p-button-rounded p-button-secondary"
          onClick={() => {
            onClose();
            formik.resetForm();
          }}
        />
        <Button label="Allocate Now" className="p-button-rounded ml-2" />
      </div>
    </form>
  );
};

export default UserCreateAllocationDialog;