import React, { useState, useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
// import { selectUser } from '../../services/store/userSlice';
// import { allocationService } from '../../services';
import { Sidebar } from 'primereact/sidebar';
import './style.scss';

export const SearchUserSidebar = ({ mode = 'employee', show = false, setShow }) => {
    // const user = useSelector(selectUser);
    const [isEmployeeDashboard, setDashboard] = useState(false);
    const [projects, setProjects] = useState([]);
    // const [showMessage, setShowMessage] = useState(false);

    // const formik = useFormik({
    //     initialValues: { firstName: '', lastName: '', email: '', password: '', ecn: '', phone: '' },
    //     validate: (data) => {
    //         let errors = {};
    //         if (!data.firstName) { errors.firstName = 'First Name is required.'; }
    //         if (!data.lastName) { errors.lastName = 'Last Name is required.'; }
    //         if (!data.email) { errors.email = 'Email is required.'; }
    //         else if (!/^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,4}$/i.test(data.email)) { errors.email = 'Invalid email address. E.g. example@espire.com'; }
    //         if (!data.password) { errors.password = 'Password is required.'; }
    //         if (!data.ecn) { errors.ecn = 'ECN is required.'; }
    //         if (!data.phone) { errors.phone = 'Phone is required.'; }
    //         return errors;
    //     },
    //     onSubmit: (data) => {
    //         setShowMessage(true);
    //         registerUser(data);
    //         formik.resetForm();
    //     }
    // });

    // const isFormFieldValid = (name) => !!(formik.touched[name] && formik.errors[name]);
    // const getFormErrorMessage = (name) => {
    //     return isFormFieldValid(name) && <small className="p-error">{formik.errors[name]}</small>;
    // };


    // const getProjects = () => {
    //     allocationService.getProjects().then(resp => {
    //         setProjects(resp.data.data);

    //     })
    // }

    // const cancelHandler = () => {
    //     formik.resetForm();
    //     setNewForm(false);
    // }

    // const SearchForm = () => {
    //     return (
    //         <Fragment>
    //             <div className='grid p-fluid'>
    //                 <div className='col-12 field'>
    //                     <label >ECN</label>
    //                     <span className="p-float-label">
    //                         <InputText />
    //                     </span>
    //                 </div>
    //                 <div className='col-12 field'>
    //                     <label >First Name</label>
    //                     <span className="p-float-label">
    //                         <InputText />
    //                     </span>
    //                 </div>
    //                 <div className='col-12 field'>
    //                     <label >Last Name</label>
    //                     <span className="p-float-label">
    //                         <InputText />
    //                     </span>
    //                 </div>
    //                 <div className='col-12 field'>
    //                     <label >Email Address</label>
    //                     <span className="p-float-label">
    //                         <InputText />
    //                     </span>
    //                 </div>
    //                 <div className='col-12 field'>
    //                     <label >Designation</label>
    //                     <span className="p-float-label">
    //                         <InputText />
    //                     </span>
    //                 </div>
    //                 <div className='col-12 field'>
    //                     <label >BU</label>
    //                     <span className="p-float-label">
    //                         <InputText />
    //                     </span>
    //                 </div>
    //                 <div className='col-12 field'>
    //                     <label >Country</label>
    //                     <span className="p-float-label">
    //                         <InputText />
    //                     </span>
    //                 </div>
    //             </div>
    //             <div className='col-12'>
    //                 <Button className='pt-2 p-button-rounded' label='Search' />
    //             </div>
    //         </Fragment>
    //     )
    // }


    return (
        <div>
            <Sidebar className='p-sidebar-md' position="right" visible={show} onHide={() => setShow(false)}>
                <h1 className='p-2'>Search User</h1>
                <div className=''>
                    {/* {SearchForm()} */}
                </div>
            </Sidebar>
        </div>
    )
}
