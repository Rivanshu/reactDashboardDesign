import React, { useState, useEffect, useRef } from "react";
import { Fragment } from "react";
import { classNames } from "primereact/utils";
import { DataTable } from "primereact/datatable";
import { Column } from "primereact/column";
import { InputText } from "primereact/inputtext";
import { userService, roleService } from "../../../../services/extensions";
import { Button } from "primereact/button";
import { Dialog } from "primereact/dialog";
import { Menu } from 'primereact/menu';
import { PickList } from "primereact/picklist";
import Profile from "../../profile/user_profile";
import { useFormik } from "formik";
import { toast } from "react-toastify";
import { Dropdown } from "primereact/dropdown";
import NewProfile from "../../profile/newProfile";
import { FilterMatchMode, FilterOperator } from 'primereact/api';
import properties from "../../../../config/environmentProperties";
import { SplitButton } from "primereact/splitbutton";
import './style.scss';
import { capitalize } from "../../../../services/utility/helper";

export const UserMaintenance = () => {
  const menu = useRef(null);
  const [users, setUsers] = useState([]);
  const [roles, setRoles] = useState([]);
  const [showUsers, setShowUsers] = useState(false);
  const [userProfile, setUserProfile] = useState(false);
  const [source, setScouce] = useState([]);
  const [target, setTarget] = useState([]);
  const [currentRole, setCurrentRole] = useState({});
  const [newForm, setNewForm] = useState(false);
  const [showMessage, setShowMessage] = useState(false);
  const [businessUnit, setBusinessUnit] = useState([]);
  const [designation, setDesignation] = useState([]);
  const [reportingManager, setReportingManager] = useState([]);
  const [clickedUserId, setClickedUserId] = useState("");
  const [clickedUserECN, setClickedUserECN] = useState("");
  const [clickedUserData, setClickedUserData] = useState([]);
  const [selectBu, setSelectBu] = useState(false); //used in onBuAction
  const [mAction, setmAction] = useState(false); //used in onManagerAction
  const [mDesignation, setmDesignation] = useState(false); // used in assignDesignation
  const [showButton, setShowButton] = useState(false);
  const [userProfileDetails, setUserProfileDetails] = useState([]);
  const [vProfile, setvProfile] = useState(false);
  const [newUserDialog, setNewUserDialog] = useState(false);
  const [searchUserDialog, setSearchUserDialog] = useState(false);
  const imgPath = properties.currentEnvironment.docPath + "images/";
  const [projects, setProjects] = useState([]);
  const [userAllocation, setUserAllocation] = useState(false); //used for Allocation
  const [clickAlloc, setClickAlloc] = useState([]);
  const [employeeList, setEmployeeList] = useState([]);
  const [userReAllocation, setUserReAllocation] = useState(false);
  const [userCreateAllocation, setUserCreateAllocation] = useState(false);
  const [filters1, setFilters1] = useState(null);
  const [globalFilterValue1, setGlobalFilterValue1] = useState('');
  const [filterDialog, setFilterDialog] = useState(false);
  const [currentUser, setCurrentUser] = useState({});
  const [filterObj, setFilterObj] = useState('');

  let count = 0;
  const formik = useFormik({
    initialValues: {
      firstName: "",
      lastName: "",
      email: "",
      password: "",
      ecn: "",
      phone: "",
      designation: "",
      bu: "",
      rm: ""
    },
    validate: (data) => {
      let errors = {};
      if (!data.firstName) {
        errors.firstName = "First Name is required.";
      }
      if (!data.lastName) {
        errors.lastName = "Last Name is required.";
      }
      if (!data.email) {
        errors.email = "Email is required.";
      } else if (
        !/^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,4}$/i.test(data.email)
      ) {
        errors.email = "Invalid email address. E.g. example@espire.com";
      }
      if (!data.ecn) {
        errors.ecn = "ECN is required.";
      }
      if (!data.phone) {
        errors.phone = "Phone is required.";
      }
      if (!data.designation) {
        errors.designation = "Designation is required.";
      }
      if (!data.bu) {
        errors.bu = "Business Unit is required.";
      }
      if (!data.rm) {
        errors.rm = "Reporting Manager is required.";
      }
      return errors;
    },
    onSubmit: (data) => {
      setShowMessage(true);
      newForm ? registerUser(data) : searchUser(data);
      // registerUser(data);
      formik.resetForm();
    },
  });

  const searchForm = useFormik({
    initialValues: {
      firstName: "",
      lastName: "",
      email: "",
      ecn: "",
      phone: "",
      designation: "",
      bu: "",
      rm: ""
    },
    validate: (data) => {
      let errors = {};
      return errors;
    },
    onSubmit: (data) => {
      setShowMessage(true);
      searchUser(data);
      // registerUser(data);
      searchForm.resetForm();
    },
  });

  const isFormFieldValid = (name) =>
    !!(formik.touched[name] && formik.errors[name]);
  const getFormErrorMessage = (name) => {
    return (
      isFormFieldValid(name) && (
        <small className="p-error">{formik.errors[name]}</small>
      )
    );
  };


  useEffect(() => {
    if (count == 0) { getUsers(); }
    count++;
  }, []);




  const clearFilter1 = () => {
    initFilters1();
  }

  const initFilters1 = () => {
    setFilters1({
      'global': { value: null, matchMode: FilterMatchMode.CONTAINS },
      'name': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
      'email': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }] },
      'ecn': { value: null, matchMode: FilterMatchMode.IN },
      'type': { operator: FilterOperator.AND, constraints: [{ value: null, matchMode: FilterMatchMode.DATE_IS }] }
    });
    setGlobalFilterValue1('');
  }


  const searchUser = (data) => {
    setShowButton(true);
    var dataObj = {};
    if (data.ecn !== "") {
      dataObj.ecn = data.ecn;
    }
    if (data.firstName !== "") {
      dataObj.firstName = data.firstName;
    }
    if (data.lastName !== "") {
      dataObj.lastName = data.lastName;
    }
    if (data.email !== "") {
      dataObj.email = data.email;
    }
    if (data.designation !== "") {
      dataObj.designationId = data.designation.id;
    }
    if (data.bu !== "") {
      dataObj.businessUnitId = data.bu.id;
    }
    if (data.rm !== "") {
      dataObj.superiorId = data.rm.id;
    }
    let isClear = true;
    for (let v of Object.keys(data)) {
      if (data[v] != undefined && data[v] != '') {
        isClear = false
      }
    }
    if (isClear) { setShowMessage(false) }

    try {
      setFilterObj(dataObj);
      userService.searchUsers(dataObj).then(
        (resp) => {
          if (resp.status === 200) {
            setUsers(resp.data.data);
            setShowButton(false);
            searchForm.resetForm();
            setFilterDialog(false);
          }
        },
        (error) => {
          setUsers();
          setShowButton(true);
        }
      );
    } catch (error) { }
  };

  const getRoles = () => {
    roleService.getRoles().then((resp) => {
      const data = resp.data.data;
      setRoles(data);
      const sourceData = data.map((x) => { return { id: x.id, name: x.role_name } });
      setScouce(sourceData);

    });
  };

  const getUsers = () => {
    userService.getUsers().then((resp) => {
      setUsers(resp.data.data);
    });
  };

  const getDesignation = () => {
    userService.getDesignation().then((resp) => {
      setDesignation(resp.data.data);
    });
  };

  const getBusinessUnit = () => {
    userService.getBusinessUnit().then((resp) => {
      setBusinessUnit(resp.data.data);
    });
  };

  const getReportingManager = () => {
    userService.getManagers().then((resp) => {
      try {
        resp.data.data.map(
          (user, index) =>
          (reportingManager[index] = {
            id: user.id,
            name:
              user.firstName.charAt(0).toUpperCase() +
              user.firstName.slice(1) +
              " " +
              user.lastName.charAt(0).toUpperCase() +
              user.lastName.slice(1),
          })
        );
      } catch (error) {
        // Error handle
      }
    });
  };


  const onHide = () => {
    setShowUsers(false);
  };

  const onShowRoles = (rowData) => {
    getRoles();
    try {
      const targetData = currentUser.UserRoles.map(x => { return { id: x.role_id, name: x.Role.role_name } });
      setTarget(targetData);
    } catch (error) {
      console.log("Error on setting assigned roles", error);
    }
    setShowUsers(true);
  };

  const assignDesignation = (rowData) => {
    setClickedUserId(currentUser.id);
    setmDesignation(true);
  };

  const onManagerAction = (rowData) => {
    setClickedUserId(currentUser.id);
    setmAction(true);
  };

  const onBuAction = (rowData) => {
    setClickedUserId(currentUser.id);
    setSelectBu(true);
  };

  const getCurrentUserDetails = (rowData) => {
    setClickedUserECN(currentUser.ecn);
    setUserProfile(true);
    setClickedUserId(currentUser.id);
    setvProfile(true);
  };

  const assignEmployeeBu = (data) => {
    let param = {
      userIds: [clickedUserId],
      businessUnitId: data.bu.id,
    };
    try {

    } catch (error) {
      toast.error("Unable to assigned Business Unit!");
    }
  };

  const assignEmployeeManager = (data) => {
    let param = {
      userIds: [clickedUserId],
      superiorId: data.manager.id,
    };
    try {

    } catch (error) {
      toast.error("Unable to assigned Reporting Manager!");
    }
  };

  const assignEmployeeDesignation = (data) => {
    let param = {
      userIds: [clickedUserId],
      designationId: data.designation.id,
    };
    try {

    } catch (error) {
      toast.error("Unable to assign Designation!");
    }
  };


  const header = (clickedUserData) => {
    return (
      <div className="grid">
        <div className="col-9">
          <h1 style={{ fontSize: "23px" }}>Allocation Management: {capitalize(clickedUserData.firstName)} {capitalize(clickedUserData.lastName)}</h1>
        </div>
        <div className="col-3 mt-3">
          <Button
            icon="pi pi-plus-circle"
            label="Create Allocation"
            className="p-button-sm p-button-rounded p-button-icon"
            // style={{ marginLeft: "5px" }}
            style={{ float: 'right' }}
            onClick={() => {
              setUserReAllocation(true);
              setUserAllocation(false);
            }}
          ></Button>
        </div>
      </div>
    );
  };

  const onChange = (event) => {
    setRoles(event.source);
    setTarget(event.target);
  };

  const fetchStatus = (status) => {
    if (status === 0) return "INACTIVE";
    if (status === 1) return "ACTIVE";
  };

  const fetchStatusColor = (status) => {
    if (status === 0) return "red";
    if (status === 1) return "#008000";
  };

  const statusBodyTemplate = (data) => {
    return (
      <span
        style={{
          color: fetchStatusColor(data.status),
          borderRadius: "8px",
          fontSize: "12px",
          fontWeight: "700",
        }}
      >
        {fetchStatus(data.status)}
      </span>
    );
  };


  const ActionTemplate = (rowData) => {
    const items = [
      {
        label: 'Views',
        items: [
          { label: "View Profile", icon: "pi pi-user", command: () => { getCurrentUserDetails(rowData); }, },
        ]
      }
    ];
    return (
      <>
        <Menu id={"m-" + rowData.id} model={items} popup ref={menu} />
        <Button className="p-button-rounded p-button-text" id={"b-" + rowData.id} icon="pi pi-ellipsis-v"
          onClick={(event) => { setCurrentUser(rowData); menu.current.toggle(event) }} aria-controls={"m-" + rowData.id} aria-haspopup />
      </>

    );
  };

  const itemBody = (item) => {
    return <span>{item.name}</span>;
  };

  const assignRole = (e) => {
    const payload = {
      userId: currentUser.id,
      roleIds: target.map(x => { return x.id })
    }
    userService.assignRoleToEmployee(payload).then(resp => {
      getUsers();
      setShowUsers(false);
    })

  }
  const RoleList = () => {
    const headerText = "Assign Roles";

    return (
      <Fragment>
        <div className="flex align-items-center flex-column">
          <Dialog header={headerText} visible={showUsers} onHide={() => onHide()} style={{ width: "500px" }}>
            <PickList
              source={source}
              target={target}
              itemTemplate={itemBody}
              sourceHeader="Available Roles"
              targetHeader="Assigned Roles"
              showSourceControls={false}
              showTargetControls={false}
              sourceStyle={{ height: "250px" }}
              targetStyle={{ height: "250px" }}
              onChange={onChange}
            />
            <div className="pt-4">
              <div className="grid" style={{ float: "right" }}>
                <div>
                  <Button type="button" label="submit" className="p-button-rounded" onClick={assignRole} />
                </div>
              </div>
            </div>
          </Dialog>
        </div>
      </Fragment>
    );
  };

  const UserProfile = () => {
    const headerText = "Profile";
    return (
      <Fragment>
        <Dialog
          header={headerText}
          visible={userProfile}
          onHide={() => setUserProfile(false)}
          style={{ width: "70%", height: "70%" }}
        >
          {/* <h1>{currentUser.ecn}</h1> */}
          <Profile
            // currentUserDetail={() => currentUserDetails(clickedUserId)}
            userECN={currentUser.ecn}
            userDetails={userProfileDetails}
            onClose={(e) => setUserProfile(false)}
          />
          {/* <h1>{currentUser.id}</h1> */}
          <NewProfile getRowId={currentUser.id} />
        </Dialog>
      </Fragment>
    );
  };

  const UserView = () => {
    const headerText = "Profile";
    return (
      <Fragment>
        <Dialog
          header={headerText}
          visible={vProfile}
          onHide={() => setvProfile(false)}
          style={{ width: "70%", height: "70%" }}
        >
          <NewProfile getRowId={clickedUserId} />
        </Dialog>
      </Fragment>
    );
  };

  const changeEvent = (e) => {
    formik.handleChange(e);
  };



  const SearchForm = () => {
    return (
      <Fragment>
        <Dialog header="User Filter" visible={filterDialog} position="right" modal style={{ width: '500px' }}
          onHide={() => setFilterDialog(false)}
          draggable={false} resizable={false}>
          <form onSubmit={searchForm.handleSubmit}>
            <div className="grid p-fluid">
              <div className="col-6 field">
                <label htmlFor="firstName" className={classNames({ "p-error": isFormFieldValid("firstName"), })}>First Name</label>
                <span className="p-float-label">
                  <InputText name="firstName" value={searchForm.values.firstName} onChange={searchForm.handleChange} />
                </span>
              </div>
              <div className="col-6 field">
                <label htmlFor="lastName" className={classNames({ "p-error": isFormFieldValid("lastName"), })}>Last Name</label>
                <span className="p-float-label">
                  <InputText name="lastName" value={searchForm.values.lastName} onChange={searchForm.handleChange} />
                </span>
              </div>
              <div className="col-6 field">
                <label htmlFor="ecn" className={classNames({ "p-error": isFormFieldValid("ecn"), })}>ECN</label>
                <span className="p-float-label">
                  <InputText name="ecn" value={searchForm.values.ecn} onChange={searchForm.handleChange} />
                </span>
              </div>
              <div className="col-6 field">
                <label className={classNames({ "p-error": isFormFieldValid("email") })}>Email Address</label>
                <span className="p-float-label">
                  <InputText name="email" value={searchForm.values.email} onChange={searchForm.handleChange} />
                </span>
              </div>
              <div className="col-6 field">
                <label className={classNames({ "p-error": isFormFieldValid("bu") })}>Business Unit</label>
                <span className="p-float-label">
                  <InputText name="bu" value={searchForm.values.bu} onChange={searchForm.handleChange} />
                  {/* <Dropdown filter id="bu" name="bu" value={searchForm.values.bu} optionLabel="code" onChange={searchForm.handleChange}
                    options={businessUnit} placeholder="Select a Business Unit" /> */}
                </span>
              </div>
              <div className="col-6 field">
                <label className={classNames({ "p-error": isFormFieldValid("designation") })}>Designation</label>
                <span className="p-float-label">
                  <InputText name="designation" value={searchForm.values.designation} onChange={searchForm.handleChange} />
                  {/* <Dropdown filter id="designation" name="designation" value={searchForm.values.designation} optionLabel="title"
                    onChange={searchForm.handleChange} options={designation} placeholder="Select a Designation" /> */}
                </span>
              </div>
              <div className="col-6 field">
                <label className={classNames({ "p-error": isFormFieldValid("rm") })}>Reporting Manager</label>
                <span className="p-float-label">
                  <InputText name="rm" value={searchForm.values.rm} onChange={searchForm.handleChange} />
                  {/* <Dropdown filter id="rm" name="rm" value={searchForm.values.rm} optionLabel="name" onChange={searchForm.handleChange}
                    options={reportingManager} placeholder="Select a Reporting Manager" /> */}
                </span>
              </div>
            </div>
            <div className="col-12">
              <Button type="submit" icon="pi pi-search" label="Search" className="p-button-rounded" />
            </div>
          </form>
        </Dialog>
      </Fragment>
    );
  };

  const cancelHandler = () => {
    formik.resetForm();
    setNewUserDialog(false);
    setNewForm(false);
  };
  const registerUser = (data) => {
    data = {
      ...data,
      "designationId": data.designation.id,
      "businessUnitId": data.bu.id,
      "superiorId": data.rm.id
    }
    try {
      userService.register(data).then(
        (resp) => {
          if (resp.data.success) {
            toast.success(resp.data.message);
          } else {
            toast.success("Process failed while creating new user...");
          }
          formik.resetForm();
          setNewForm(false);
          getUsers();
        },
        (error) => {
          toast.success("Process failed while creating new user...");
        }
      );
    } catch (error) {
      toast.success("Process failed while creating new user...");
    }
  };
  const NewForm = () => {
    return (
      <form onSubmit={formik.handleSubmit}>
        <div className="grid p-fluid">
          <div className="col-6 field">
            <label
              htmlFor="ecn"
              className={classNames({
                "p-error": isFormFieldValid("ecn")
              })}
            >
              ECN*
            </label>
            <span className="p-float-label">
              <InputText
                id="ecn"
                name="ecn"
                value={formik.values.ecn}
                onChange={formik.handleChange}
                className={classNames({ "p-invalid": isFormFieldValid("ecn") })}
              />
            </span>
            {getFormErrorMessage("ecn")}
          </div>
          <div className="col-6"></div>
          <div className="col-6 field">
            <label
              htmlFor="firstName"
              className={classNames({
                "p-error": isFormFieldValid("firstName"),
              })}
            >
              First Name*
            </label>
            <span className="p-float-label">
              <InputText
                id="firstName"
                name="firstName"
                value={formik.values.firstName}
                onChange={formik.handleChange}
                className={classNames({ "p-invalid": isFormFieldValid("firstName") })}
              />
            </span>
            {getFormErrorMessage("firstName")}
          </div>
          <div className="col-6 field">
            <label
              htmlFor="lastName"
              className={classNames({
                "p-error": isFormFieldValid("lastName")
              })}
            >
              Last Name*
            </label>
            <span className="p-float-label">
              <InputText
                id="lastName"
                name="lastName"
                value={formik.values.lastName}
                onChange={formik.handleChange}
                className={classNames({ "p-invalid": isFormFieldValid("lastName") })}
              />
            </span>
            {getFormErrorMessage("lastName")}
          </div>
          <div className="col-6 field">
            <label
              htmlFor="email"
              className={classNames({
                "p-error": isFormFieldValid("email")
              })}
            >
              Email Address*
            </label>
            <span className="p-float-label">
              <InputText
                id="email"
                name="email"
                value={formik.values.email}
                onChange={formik.handleChange}
                className={classNames({ "p-invalid": isFormFieldValid("email") })}
              />
            </span>
            {getFormErrorMessage("email")}
          </div>
          <div className="col-6 field">
            <label
              htmlFor="phone"
              className={classNames({
                "p-error": isFormFieldValid("phone")
              })}
            >
              Phone*
            </label>
            <span className="p-float-label">
              <InputText
                id="phone"
                name="phone"
                value={formik.values.phone}
                onChange={formik.handleChange}
                className={classNames({ "p-invalid": isFormFieldValid("phone") })}
              />
            </span>
            {getFormErrorMessage("phone")}
          </div>
          <div className="col-6 field">
            <label
              htmlFor="designation"
              className={classNames({
                "p-error": isFormFieldValid("designation")
              })}
            >
              Designation*
            </label>
            <span className="p-float-label">
              <Dropdown
                filter
                id="designation"
                name="designation"
                value={formik.values.designation}
                optionLabel="title"
                onChange={formik.handleChange}
                options={designation}
                placeholder="Select designation"
                className={classNames({ "p-invalid": isFormFieldValid("designation") })}
              />
            </span>
            {getFormErrorMessage("designation")}
          </div>
          <div className="col-12 field">
            <label
              htmlFor="bu"
              className={classNames({
                "p-error": isFormFieldValid("bu")
              })}
            >
              Business Unit*
            </label>
            <span className="p-float-label">
              <Dropdown
                filter
                id="bu"
                name="bu"
                value={formik.values.bu}
                optionLabel="code"
                onChange={formik.handleChange}
                options={businessUnit}
                placeholder="Select business unit"
                className={classNames({ "p-invalid": isFormFieldValid("bu") })}
              />
            </span>
            {getFormErrorMessage("bu")}
          </div>
          <div className="col-12 field">
            <label
              htmlFor="rm"
              className={classNames({
                "p-error": isFormFieldValid("rm")
              })}
            >
              Reporting Manager*
            </label>
            <span className="p-float-label">
              <Dropdown
                filter
                id="rm"
                name="rm"
                value={formik.values.rm}
                optionLabel="name"
                onChange={formik.handleChange}
                options={reportingManager}
                placeholder="Select reporting nanager"
                className={classNames({ "p-invalid": isFormFieldValid("rm") })}
              />
            </span>
            {getFormErrorMessage("rm")}
          </div>
        </div>
        <div className="col-12">
          <Button
            type="submit"
            icon="pi pi-plus"
            label="Add User"
            className="p-button-rounded"
          />
          <Button
            type="button"
            icon="pi pi-times"
            label="Cancel"
            className="p-button-rounded p-button-secondary ml-2"
            onClick={cancelHandler}
          />
        </div>
      </form>
    );
  };

  const SideCard = () => {
    return (
      // <div className="col-3">
      <div className="card-container p-3">
        <h1>
          {newForm ? "Add New User" : "Search User"}
          {!newForm && (
            <div style={{ float: "right" }}>
              <Button
                className="p-button-rounded"
                icon="pi pi-user-plus"
                onClick={() => {
                  setNewForm(true);
                }}
              />
            </div>
          )}
        </h1>
        {newForm ? NewForm() : SearchForm()}
      </div>
      // </div>
    );
  };

  const tableHeader = () => {
    return (
      <Fragment>
        <div className="grid">
          <div
            className="col mt-3 mb-2"
            style={{ paddingLeft: "25px", paddingRight: "21px" }}
          >
            <span className="heading">
              User's List
              <div className="heading-actions">
                <Button icon="pi pi-replay" className="p-button-rounded p-button-help p-button-text" aria-label="Replay" onClick={() => { setFilterObj(''); getUsers() }} />
                <Button icon="pi pi-filter" className="p-button-rounded p-button-help p-button-text" aria-label="Filter" onClick={() => setFilterDialog(true)} />
                {/* <Button
                  icon="pi pi-times"
                  label="Clear"
                  className="p-button-rounded p-button-secondary"
                  style={{ width: "42%" }}
                  // onClick={searchUser} 
                  onClick={getUsers}
                  onHide={() => setShowButton(true)}
                /> */}
              </div>
            </span>
          </div>
        </div>
      </Fragment>
    );
  };

  const imageBodyTemplate = (item) => {
    return (
      <div className="flex align-items-center gap-2">
        {item?.photo === "" || item?.photo === null ? (
          <span className="photo-span profile-icon-text ">
            {item.firstName.toUpperCase().substr(0, 1)}
            {item.lastName.toUpperCase().substr(0, 1)}
          </span>
        ) : (
          <img
            style={{
              height: "40px",
              width: "40px",
              borderRadius: "50%",
              border: "3px solid #d7e9ff",
              Top: "16px",
              bottom: "16px",
              left: "16px",
            }}
            src={imgPath + item?.photo || ""}
            alt=""
          />
        )}
        <div>{item.firstName + " " + item.lastName}</div>
      </div>
    );
  };



  return (
    <div className="grid">
      {RoleList()}
      {UserProfile()}
      {SearchForm()}
      {/* {UserView()} */}
      {/* {NewUserSidebar({ mode: 'employee', show: newForm, setShow: setNewForm, getUsers: getUsers })} */}
      {/* {SearchUserSidebar()} */}
      <div className="col-12">
        <div className="card-container p-3">
          <DataTable value={users} paginator responsiveLayout="scroll"
            header={tableHeader} paginatorTemplate="CurrentPageReport FirstPageLink PrevPageLink PageLinks NextPageLink LastPageLink RowsPerPageDropdown"
            currentPageReportTemplate="Showing {first} to {last} of {totalRecords}"
            rows={10} rowsPerPageOptions={[10, 20, 50]}
            filters={filters1} filterDisplay="menu"
            globalFilterFields={['name', 'email', 'ecn', 'type']}
          >
            <Column field="" header="Name" body={imageBodyTemplate} sortable className="initCap"></Column>
            <Column field="email" header="Email Address" sortable ></Column>
            <Column field="ecn" header="ECN" sortable></Column>
            <Column field="type" header="Role" sortable ></Column>
            <Column field="" header="Status" body={statusBodyTemplate} ></Column>
            <Column header="Actions" body={ActionTemplate} ></Column>
          </DataTable>
        </div>
      </div>
    </div>
  );
};