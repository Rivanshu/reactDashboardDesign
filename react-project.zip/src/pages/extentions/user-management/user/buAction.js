import React from "react";
import { Button } from "primereact/button";
import { Dropdown } from "primereact/dropdown";
import { useFormik } from "formik";
import { useState, useEffect } from "react";
import { userService } from "../../../../services/extensions";
import { classNames } from "primereact/utils";

const BuAction = ({ assignBu, onClose }) => {
    const [businessUnit, setBusinessUnit] = useState([]);
    const [showMessage, setShowMessage] = useState(false);

    const formik = useFormik({
        initialValues: {
            bu: null,
        },
        validate: (data) => {
            let errors = {};
            if (!data.bu) {
                errors.bu = 'Please select business unit.';
            }
            return errors;
        },
        onSubmit: (data) => {
            setShowMessage(true);
            assignBu(data);
        },
    });

    const isFormFieldValid = (name) =>
        !!(formik.touched[name] && formik.errors[name]);
    const getFormErrorMessage = (name) => {
        return (
            isFormFieldValid(name) && (
                <small className="p-error">{formik.errors[name]}</small>
            )
        );
    };

    useEffect(() => {
        getBusinessUnit();
    }, []);

    const onCloseMethod = () => {
        onClose();
    };

    const getBusinessUnit = () => {
        userService.getBusinessUnit().then((resp) => {
            setBusinessUnit(resp.data.data);
        });
    };

    const changeEvent = (e) => {
        formik.handleChange(e);
    };

    return (
        <form onSubmit={formik.handleSubmit}>
            <div className="fields">
                <span>
                    <Dropdown
                        filter
                        id="bu"
                        name="bu"
                        value={formik.values.bu}
                        placeholder="Select business unit"
                        options={businessUnit}
                        optionLabel="code"
                        onChange={(e) => {
                            changeEvent(e);
                        }}
                        style={{ width: "390px" }}
                        className={classNames({ 'p-invalid': isFormFieldValid('bu') })}
                    />
                    {getFormErrorMessage("bu")}
                </span>
                <div className='pt-4'>
                    <div className='grid' style={{ float: 'right' }}>
                        <div className='mr-2'>
                            <Button
                                type="button"
                                label="Cancel"
                                className="p-button-rounded p-button-secondary"
                                onClick={(e) => onCloseMethod(e)}
                            />
                        </div>
                        <div>
                            <Button
                                type="submit"
                                label="Submit"
                                className="p-button-rounded"
                            />
                        </div>
                    </div>
                </div>
            </div>
        </form>
    );
};

export default BuAction;