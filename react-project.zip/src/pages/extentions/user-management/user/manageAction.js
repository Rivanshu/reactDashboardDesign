import React from "react";
import { Button } from "primereact/button";
import { Dropdown } from "primereact/dropdown";
import { useState, useEffect } from "react";
import { useFormik } from "formik";
import { userService } from "../../../../services/extensions";
import { classNames } from "primereact/utils";

const ManageActionPopup = ({ assignManager, onClose }) => {
  const [managers, setManagers] = useState([]);
  const [showMessage, setShowMessage] = useState(false);

  const formik = useFormik({
    initialValues: {
      manager: null,
    },
    validate: (data) => {
      let errors = {};
      if (!data.manager) {
        errors.manager = 'Please select reporting manager.';
      }
      return errors;
    },
    onSubmit: (data) => {
      assignManager(data);
    },
  });

  const isFormFieldValid = (name) =>
    !!(formik.touched[name] && formik.errors[name]);
  const getFormErrorMessage = (name) => {
    return (
      isFormFieldValid(name) && (
        <small className="p-error">{formik.errors[name]}</small>
      )
    );
  };

  useEffect(() => {
    getManagers();
  }, []);

  const onCloseMethod = () => {
    onClose();
  };

  const getManagers = () => {
    userService.getManagers().then((resp) => {
      try {
        resp.data.data.map(
          (user, index) =>
          (managers[index] = {
            id: user.id,
            name:
              user.firstName.charAt(0).toUpperCase() +
              user.firstName.slice(1) +
              " " +
              user.lastName.charAt(0).toUpperCase() +
              user.lastName.slice(1),
          })
        );
      } catch (error) {
        // Error handle
      }
    });
  };

  const changeEvent = (e) => {
    formik.handleChange(e);
  };

  return (
    <form onSubmit={formik.handleSubmit}>
      <div className="fields">
        <span>
          <Dropdown
            filter
            id="manager"
            name="manager"
            value={formik.values.manager}
            options={managers}
            placeholder="Select reporting manager"
            optionLabel="name"
            onChange={(e) => {
              changeEvent(e);
            }}
            style={{ width: "390px" }}
            className={classNames({ 'p-invalid': isFormFieldValid('manager') })}
          />
          {getFormErrorMessage("manager")}
        </span>
        <div className='pt-4'>
          <div className='grid' style={{ float: 'right' }}>
            <div className='mr-2'>
              <Button
                type="button"
                label="Cancel"
                className="p-button-rounded p-button-secondary"
                onClick={(e) => onCloseMethod(e)}
              />
            </div>
            <div>
              <Button
                type="submit"
                label="Submit"
                onSubmit={formik.handleChange}
                className="p-button-rounded"
              />
            </div>
          </div>
        </div>
      </div>
    </form>
  );
};

export default ManageActionPopup;