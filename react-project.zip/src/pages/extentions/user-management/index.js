import { UserDashboard } from "./dashboard";
import './style.scss';
class UserManagement {

    constructor() {
        this.Dashboard = UserDashboard;
    }

}

export default UserManagement