import React, { useState, useEffect } from "react";
import { classNames } from "primereact/utils";
import { Dropdown } from "primereact/dropdown";
import {
  managerService,
  permissionService,
  userService,
} from "../../../../services/extensions";
import { DataTable } from "primereact/datatable";
import { Column } from "primereact/column";
import { InputText } from "primereact/inputtext";
import { Button } from "primereact/button";
import { toast } from "react-toastify";
import { ErrorMessage, useFormik } from "formik";
import properties from "../../../../config/environmentProperties";

export const UserManager = () => {
  const [permissions, setPermissions] = useState([]);
  const [managerList, setManagerList] = useState([]);
  const [userList, setUserList] = useState([]);
  const [currentmanagerList, setCurrentManagerList] = useState([]);
  const [selectedManager, setSelectedManager] = useState(null);
  const [businessUnit, setBusinessUnit] = useState(null);
  const [selectedCurrentManager, setSelectedCurrentManager] = useState(null);
  const [assignUserList, setAssignUserList] = useState([]);
  const [selectedAssignUserList, setSelectedAssignUserList] = useState([]);
  const [user, setUser] = useState([]);
  const [filterUserList, setFilterUserList] = useState([]);
  const [selectedFilterUserList, setSelectedFilterUserList] = useState([]);
  const [showMessage, setShowMessage] = useState(false);
  const [designation, setDesignation] = useState([]);

  const imgPath = properties.currentEnvironment.docPath + "images/";

  const formik = useFormik({
    initialValues: {
      currentReportingManager: null,
      firstName: null,
      lastName: null,
      designation: null,
      ecn: null,
      email: null,
    },
    validate: (data) => {
      let errors = {};

      if (!data.currentReportingManager) {
        errors.currentReportingManager = "Reporting manager is required.";
      }
      if (!data.firstName) {
        errors.firstName = "First Name is required.";
      }
      if (!data.lastName) {
        errors.lastName = "Last Name is required.";
      }
      if (!data.designation) {
        errors.designation = "Designation is required.";
      }
      if (!data.email) {
        errors.email = "Email is required.";
      } else if (
        !/^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,4}$/i.test(data.email)
      ) {
        errors.email = "Invalid email address. E.g. example@email.com";
      }
      return errors;
    },
    onSubmit: (data) => {
      setShowMessage(true);
      // formik.resetForm();
    },
  });

  const isFormFieldValid = (name) =>
    !!(formik.touched[name] && formik.errors[name]);
  const getFormErrorMessage = (name) => {
    return (
      isFormFieldValid(name) && (
        <small className="p-error">{formik.errors[name]}</small>
      )
    );
  };


  const getDesignations = (param = {}) => {
    userService.getDesignations().then((resp) => {
      setDesignation(resp.data.data);
    });
  };


  const resetData = () => {
    setSelectedCurrentManager("");
    setState({
      ecn: "",
      firstName: "",
      lastName: "",
      email: "",
    });
    formik.setFieldValue("designation", "");
  };

  const [state, setState] = useState({
    currentReportingManager: null,
    ecn: null,
    firstName: null,
    lastName: null,
    email: null,
  });

  const handleChange = (e) => {
    let obj = {
      ...state,
      [e.target.name]: e.target.value,
    };
    setState(obj);
  };

  const searchUser = (param = {}) => {
    if (state.ecn) {
      param = {
        ecn: state.ecn,
      };
    } else if (state.email) {
      param = {
        email: state.email,
      };
    } else if (state.firstName) {
      param = {
        firstName: state.firstName,
      };
    } else if (state.lastName) {
      param = {
        lastName: state.lastName,
      };
    } else if (selectedCurrentManager && selectedCurrentManager.id) {
      param = {
        superiorId: selectedCurrentManager.id,
      };
    } else if (formik.values.designation) {
      param = {
        designationId: formik.values.designation,
      };
    }

  };


  const EmpName = (rowData, options) => {
    const name = rowData.firstName + " " + rowData.lastName;
    return name;
  };


  const imageBodyTemplate = (item) => {
    return (
      <div className="flex align-items-center gap-2">
        {item?.photo === "" || item?.photo === null ? (
          <span
            className="photo-span"
            style={{
              height: "40px",
              width: "40px",
              borderRadius: "50%",
              border: "3px solid #d7e9ff",
              Top: "16px",
              bottom: "16px",
              left: "16px",
              display: "block",
              textAlign: "center",
              fontSize: "22px",
              fontWeight: "600",
              color: "#1369b6",
            }}
          >
            {item.firstName.toUpperCase().substr(0, 1)}
            {item.lastName.toUpperCase().substr(0, 1)}
          </span>
        ) : (
          <img
            style={{
              height: "40px",
              width: "40px",
              borderRadius: "50%",
              border: "3px solid #d7e9ff",
              Top: "16px",
              bottom: "16px",
              left: "16px",
            }}
            src={imgPath + item?.photo || ""}
            alt=""
          />
        )}
        <div>{item.firstName + " " + item.lastName}</div>
      </div>
    );
  };

  return (
    <div className="p-3">
      <div className="grid">
        <div className="col">
          <div className="card-container p-3">
            <h1>User Manager</h1>
            <div className="p-fluid">
              <label>Manager</label>{" "}
              <div className="grid" style={{ marginTop: "10px" }}>
                <span className="p-float-label">
                  <Dropdown
                    style={{ width: "180%" }}
                    filter
                    id="manager"
                    name="manager"
                    value={selectedManager}
                    optionLabel="name"
                    options={managerList}
                    placeholder="Select a Manager"
                    appendTo="self"
                  />
                </span>

                <hr />

                <div className="grid p-fluid">
                  <div className="col">
                    <div className="mb-3 ">
                      <Button
                        icon="pi pi-trash"
                        label="Remove"
                        className="p-button p-button-rounded"
                        style={{ width: "55%", marginLeft: "-7px" }}
                        disabled={selectedAssignUserList.length === 0}
                      />
                    </div>
                  </div>
                </div>

              </div>
              <h1>Assigned Users Under Manager</h1>
              <DataTable
                value={assignUserList}
                selection={selectedAssignUserList}
                onSelectionChange={(e) => setSelectedAssignUserList(e.value)}
                paginator
                responsiveLayout="scroll"
                paginatorTemplate="CurrentPageReport FirstPageLink PrevPageLink PageLinks NextPageLink LastPageLink RowsPerPageDropdown"
                currentPageReportTemplate="Showing {first} to {last} of {totalRecords}"
                rows={10}
                rowsPerPageOptions={[10, 20, 50]}
              >
                <Column selectionMode="multiple" headerStyle={{ width: "50px" }} ></Column>
                <Column field="ecn" header="ECN" sortable ></Column>
                <Column field="firstName" header="Name" body={imageBodyTemplate} sortable ></Column>
                <Column field="email" header="Email" sortable ></Column>
              </DataTable>
            </div>
          </div>
        </div>
        <div className="col">
          <div className="card-container p-3">
            <h1>Search Available Users</h1>
            <div className="grid p-fluid">
              <div className="col field">
                <label>First Name</label>
                <span className="p-float-label">
                  <InputText
                    id="firstName"
                    name="firstName"
                    value={state.firstName}
                    onChange={handleChange}
                    placeholder="Enter first name"
                  />
                </span>
              </div>
              <div className="col field">
                <label>Last Name</label>
                <span className="p-float-label">
                  <InputText
                    id="lastName"
                    name="lastName"
                    value={state.lastName}
                    onChange={handleChange}
                    placeholder="Enter last name"
                  />
                </span>
              </div>
            </div>

            <div className="grid p-fluid">
              <div className="col field">
                <label>ECN</label>
                <span className="p-float-label">
                  <InputText
                    id="ecn"
                    name="ecn"
                    value={state.ecn}
                    onChange={handleChange}
                    placeholder="Enter ECN"
                  />
                </span>
              </div>
              <div className="col field">
                <label>Email ID</label>
                <span className="p-float-label">
                  <InputText
                    id="email"
                    name="email"
                    value={state.email}
                    onChange={handleChange}
                    placeholder="Enter your email id"
                  />
                </span>
              </div>
            </div>

            <div className="grid p-fluid">
              <div className="col field">
                <label>Designation</label>
                <span className="p-float-label">
                  <Dropdown
                    filter
                    id="designation"
                    name="designation"
                    value={formik.values.designation}
                    placeholder="Select designation"
                    options={designation}
                    optionLabel="title"
                    optionValue="id"
                    onChange={formik.handleChange}
                  />
                </span>
              </div>
              <div className="col field">
                <label>Reporting Manager</label>
                <span className="p-float-label">
                  <Dropdown
                    filter
                    id="currentReportingManager"
                    name="currentReportingManager"
                    value={selectedCurrentManager}
                    optionLabel="name"
                    options={currentmanagerList}
                    placeholder="Select reporting manager"
                    onChange={(e) => setSelectedCurrentManager(e.value)}
                  />
                </span>
              </div>
            </div>

            <div className="grid p-fluid">
              <div className="col">
                <div className="mb-3 mt-3">
                  <Button
                    icon="pi pi-search"
                    label="Search"
                    className="p-button p-button-rounded mr-10"
                    style={{ width: "20%" }}
                    onClick={() => searchUser()}
                  />
                  <Button
                    icon="pi pi-times"
                    label="Reset"
                    className="p-button p-button-rounded"
                    style={{ width: "20%", marginLeft: "5px" }}
                    onClick={() => resetData()}
                  />
                </div>
              </div>
            </div>
            <div className="grid">
              <div className="col-12">
                <DataTable
                  value={filterUserList}
                  selectedFilterUserList
                  selection={selectedFilterUserList}
                  onSelectionChange={(e) => setSelectedFilterUserList(e.value)}
                  paginator
                  responsiveLayout="scroll"
                  paginatorTemplate="CurrentPageReport FirstPageLink PrevPageLink PageLinks NextPageLink LastPageLink RowsPerPageDropdown"
                  currentPageReportTemplate="Showing {first} to {last} of {totalRecords}"
                  rows={10}
                  rowsPerPageOptions={[10, 20, 50]}
                >
                  <Column selectionMode="multiple" headerStyle={{ width: "50px" }} ></Column>
                  <Column field="ecn" header="ECN" sortable ></Column>
                  <Column field="firstName" header="Name" body={imageBodyTemplate} sortable ></Column>
                  <Column field="email" header="Email" sortable ></Column>
                </DataTable>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};