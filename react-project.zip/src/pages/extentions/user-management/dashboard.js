import React, { useState, useEffect, Fragment } from 'react';
import { TabMenu } from 'primereact/tabmenu';
import { Role, RolePermission, UserManager, UserMaintenance, Permission } from '../index';
import { getFilteredOptions } from '../../../common/helpers/permissions';
import {
    USER_MAINTENANCE_USER_ROLE, USER_MAINTENANCE_USER_VIEW, USER_MAINTENANCE_PERMISSION_VIEW, USER_MAINTENANCE_MANAGER_VIEW,
    USER_MAINTENANCE_ROLE_PERMISSION_VIEW, USER_MAINTENANCE_MENU_VIEW
} from '../../../config/permissions';
import { ProtectedSection } from '../../../components/protected/ProtectedSection'

export const UserDashboard = () => {
    const [activeIndex, setActiveIndex] = useState(0);
    const [items, setItems] = useState([])

    useEffect(() => {
        const fItems = getFilteredOptions([
            { label: 'User Maintenance', icon: 'pi pi-users', permissions: [USER_MAINTENANCE_MENU_VIEW] },
            { label: 'Roles', icon: 'pi pi-users', permissions: [USER_MAINTENANCE_USER_ROLE] },
            { label: 'Permissions', icon: 'pi pi-users', permissions: [USER_MAINTENANCE_PERMISSION_VIEW] },
            { label: 'Role Permission', icon: 'pi pi-users', permissions: [USER_MAINTENANCE_ROLE_PERMISSION_VIEW] },
            { label: 'User Manager', icon: 'pi pi-users', permissions: [USER_MAINTENANCE_MANAGER_VIEW] }
        ]);
        setItems(fItems);
    }, [])

    const ActiveTab = () => {
        switch (activeIndex) {
            case 0:
                return <ProtectedSection permissions={[USER_MAINTENANCE_MENU_VIEW]}><UserMaintenance /></ProtectedSection>;
            case 1:
                return <ProtectedSection permissions={[USER_MAINTENANCE_USER_ROLE]}><Role /></ProtectedSection>;
            case 2:
                return <ProtectedSection permissions={[USER_MAINTENANCE_PERMISSION_VIEW]}><Permission /></ProtectedSection>;
            case 3:
                return <ProtectedSection permissions={[USER_MAINTENANCE_ROLE_PERMISSION_VIEW]}><RolePermission /></ProtectedSection>;
            case 4:
                return <ProtectedSection permissions={[USER_MAINTENANCE_MANAGER_VIEW]}><UserManager /></ProtectedSection>;
            default:
                return <ProtectedSection permissions={[USER_MAINTENANCE_MENU_VIEW]}><UserMaintenance /></ProtectedSection>;
        }
    }

    return (
        <Fragment>
            <div className="card">
                <TabMenu model={items} activeIndex={activeIndex} onTabChange={(e) => setActiveIndex(e.index)} />
            </div>
            <div style={{ background: '#fff', border: '1px solid rgb(228 235 242)' }}>
                <ActiveTab />
            </div>
        </Fragment>

    )
}
