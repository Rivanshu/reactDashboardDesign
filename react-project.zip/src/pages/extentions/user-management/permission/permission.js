import React, { useState, useEffect } from 'react'
import { Fragment } from 'react'
import { classNames } from 'primereact/utils';
import { useFormik } from 'formik';
import { DataTable } from 'primereact/datatable';
import { Column } from 'primereact/column';
import { InputText } from 'primereact/inputtext';
import { InputTextarea } from 'primereact/inputtextarea';
import { userService, permissionService, domainService } from '../../../../services/extensions';
import { Button } from 'primereact/button';
import { toast } from 'react-toastify';
import { Dropdown } from 'primereact/dropdown';
import { confirmDialog } from 'primereact/confirmdialog';

const actions = ['Create', 'Update', 'Delete', 'Export', 'Import'];
export const Permission = () => {
    const [permissions, setPermissions] = useState([]);
    const [domains, setDomains] = useState([]);
    const [showMessage, setShowMessage] = useState(false);
    const [newForm, setNewForm] = useState(false);


    const formik = useFormik({
        initialValues: {
            domain: null,
            action: null,
            instance: null,
            description: null
        },
        validate: (data) => {
            let errors = {};

            if (!data.domain) { errors.domain = 'Domain is required.'; }
            if (!data.action) { errors.action = 'Action is required.'; }
            if (!data.instance) { errors.instance = 'Instance is required.'; }

            return errors;
        },
        onSubmit: (data) => {
            setShowMessage(true);
            // formik.resetForm();
            createPermissions(data);
        }
    });

    const isFormFieldValid = (name) => !!(formik.touched[name] && formik.errors[name]);
    const getFormErrorMessage = (name) => {
        return isFormFieldValid(name) && <small className="p-error">{formik.errors[name]}</small>;
    };

    useEffect(() => {
        getPermissions();
        getDomains();
    }, [])

    const getPermissions = () => {
        permissionService.getPermissions().then(resp => {
            setPermissions(resp.data.data);
        })
    }

    const getDomains = (param = {}) => {
        domainService.getDomains().then(resp => {
            setDomains(resp.data.data);
        })
    }

    const changeEvent = (e) => {
        formik.handleChange(e);
    }

    const createPermissions = (data) => {
        try {
            const payload = { ...data, domain: data.domain.domain_code }
            permissionService.createPermissions(payload).then(resp => {
                // console.log("resp", resp);
                if (resp.data.success) {
                    toast.success("Permission successfully created");
                }
            })
        } catch (error) {
            console.log("Catch Error :", error);
        }
    }

    const ActionBody = (rowData, options) => {
        return (
            <Fragment>
                <Button icon="pi pi-pencil" className="p-button-rounded p-button-secondary p-button-text" onClick={() => { setNewForm(true) }} />
                <Button icon="pi pi-trash" className="p-button-rounded p-button-danger p-button-text" onClick={deletePermision} />
            </Fragment>
        )
    }

    const deletePermision = () => {
        confirmDialog({
            message: 'Are you sure you want to proceed?',
            header: 'Confirmation',
            icon: 'pi pi-exclamation-triangle',
            accept: () => { toast.success('accept') },
            reject: () => { toast.error('reject') },
        });
    }

    const NewPermissionForm = () => {
        return (
            <form onSubmit={formik.handleSubmit}>
                <div className='p-fluid'>
                    <div className="field">
                        <label className={classNames({ 'p-error': isFormFieldValid('domain') })}>Domain</label>
                        <span className="p-float-label">
                            <Dropdown id="domain" name="domain" value={formik.values.domain} optionLabel="display_label" onChange={(e) => { changeEvent(e) }}
                                options={domains} placeholder="Select a Domain"
                                className={classNames({ 'p-invalid': isFormFieldValid('domain') })} />
                        </span>
                        {getFormErrorMessage('domain')}
                    </div>
                    <div className="field">
                        <label className={classNames({ 'p-error': isFormFieldValid('action') })}>Actions</label>
                        <span className="p-float-label">
                            <Dropdown id="action" name="action" value={formik.values.action} onChange={formik.handleChange}
                                options={actions} placeholder="Select a Action"
                                className={classNames({ 'p-invalid': isFormFieldValid('action') })} />
                        </span>
                        {getFormErrorMessage('action')}
                    </div>
                    <div className="field">
                        <label className={classNames({ 'p-error': isFormFieldValid('instance') })}>Instance</label>
                        <span className="p-float-label">
                            <InputText id="instance" name="instance" value={formik.values.instance} onChange={formik.handleChange}
                                className={classNames({ 'p-invalid': isFormFieldValid('instance') })} placeholder="Enter your instance" />
                        </span>
                        {getFormErrorMessage('instance')}
                    </div>
                    <div className="field">
                        <label className={classNames({ 'p-error': isFormFieldValid('description') })}>Description</label>
                        <span className="p-float-label">
                            <InputTextarea id="description" name="description" rows={5} cols={30}
                                value={formik.values.description} onChange={formik.handleChange}
                                className={classNames({ 'p-invalid': isFormFieldValid('description') })} placeholder="Enter your description" />
                        </span>
                        {getFormErrorMessage('description')}
                    </div>
                </div>
                <div className='col-12'>
                    <Button className='pt-2 p-button-rounded' label='Edit Permission' />
                    <Button type='button' className='pt-2 p-button-rounded p-button-secondary ml-2' label='Cancel' onClick={cancelHandler} />
                </div>
            </form>
        )

    }

    const cancelHandler = () => {
        formik.resetForm();
        setNewForm(false);
    }

    const createPermission = () => {
        return (
            <Fragment>
                <form onSubmit={formik.handleSubmit}>
                    <div className='p-fluid'>
                        <div className="field">
                            <label className={classNames({ 'p-error': isFormFieldValid('role') })}>Domain</label>
                            <span className="p-float-label">
                                <Dropdown id="domain" name="domain" value={formik.values.domain} optionLabel="display_label" onChange={(e) => { changeEvent(e) }}
                                    options={domains} placeholder="Select a Domain"
                                    className={classNames({ 'p-invalid': isFormFieldValid('domain') })} />
                            </span>
                            {getFormErrorMessage('domain')}
                        </div>
                        <div className="field">
                            <label className={classNames({ 'p-error': isFormFieldValid('action') })}>Actions</label>
                            <span className="p-float-label">
                                <Dropdown id="action" name="action" value={formik.values.action} onChange={formik.handleChange}
                                    options={actions} placeholder="Select a Action"
                                    className={classNames({ 'p-invalid': isFormFieldValid('action') })} />
                            </span>
                            {getFormErrorMessage('action')}
                        </div>
                        <div className="field">
                            <label className={classNames({ 'p-error': isFormFieldValid('instance') })}>Instance</label>
                            <span className="p-float-label">
                                <InputText id="instance" name="instance" value={formik.values.instance} onChange={formik.handleChange}
                                    className={classNames({ 'p-invalid': isFormFieldValid('instance') })} placeholder="Enter your instance" />
                            </span>
                            {getFormErrorMessage('instance')}
                        </div>
                        <div className="field">
                            <label className={classNames({ 'p-error': isFormFieldValid('description') })}>Description</label>
                            <span className="p-float-label">
                                <InputTextarea id="description" name="description" rows={5} cols={30}
                                    value={formik.values.description} onChange={formik.handleChange}
                                    className={classNames({ 'p-invalid': isFormFieldValid('description') })} placeholder="Enter your description" />
                            </span>
                            {getFormErrorMessage('description')}
                        </div>
                    </div>
                    <Button type="submit" label="Create" className="pt-2 p-button-rounded" />
                    <Button type="reset" label="Reset" className='pt-2 p-button-rounded p-button-secondary mt-2 ml-2' />
                </form>
            </Fragment>
        )
    }

    return (
        <div className='grid' >
            <div className='col-8'>
                <DataTable value={permissions}
                    paginator responsiveLayout="scroll"
                    paginatorTemplate="CurrentPageReport FirstPageLink PrevPageLink PageLinks NextPageLink LastPageLink RowsPerPageDropdown"
                    currentPageReportTemplate="Showing {first} to {last} of {totalRecords}" rows={10} rowsPerPageOptions={[10, 20, 50]}>
                    <Column field="domain" header="Domain" sortable></Column>
                    <Column field="action" header="Action" sortable></Column>
                    <Column field="instance" header="Instance" sortable></Column>
                    <Column field="description" header="Description" sortable></Column>
                    <Column header="Actions" body={ActionBody} style={{ textAlign: 'center', width: '120px' }}></Column>
                </DataTable>
            </div>
            <div className='col-4'>
                <div className='card-container p-3'>
                    <h1>
                        {newForm ? 'Edit this Permission' : 'Create Permission'}
                        {!newForm}
                    </h1>
                    {newForm ? NewPermissionForm() : createPermission()}

                </div>
            </div>
            {/* <div className='col-4 p-3'>
                <h1>Create Permission</h1>
                <div className="card" style={{ padding: '10px', border: '1px solid #e4ebf2' }}>
                    <form onSubmit={formik.handleSubmit}>
                        <div className='p-fluid'>
                            <div className="field">
                                <label className={classNames({ 'p-error': isFormFieldValid('role') })}>Domain</label>
                                <span className="p-float-label">
                                    <Dropdown id="domain" name="domain" value={formik.values.domain} optionLabel="display_label" onChange={(e) => { changeEvent(e) }}
                                        options={domains} placeholder="Select a Domain"
                                        className={classNames({ 'p-invalid': isFormFieldValid('domain') })} />
                                </span>
                                {getFormErrorMessage('domain')}
                            </div>
                            <div className="field">
                                <label className={classNames({ 'p-error': isFormFieldValid('action') })}>Actions</label>
                                <span className="p-float-label">
                                    <Dropdown id="action" name="action" value={formik.values.action} onChange={formik.handleChange}
                                        options={actions} placeholder="Select a Action"
                                        className={classNames({ 'p-invalid': isFormFieldValid('action') })} />
                                </span>
                                {getFormErrorMessage('action')}
                            </div>
                            <div className="field">
                                <label className={classNames({ 'p-error': isFormFieldValid('instance') })}>Instance</label>
                                <span className="p-float-label">
                                    <InputText id="instance" name="instance" value={formik.values.instance} onChange={formik.handleChange}
                                        className={classNames({ 'p-invalid': isFormFieldValid('instance') })} placeholder="Enter your instance" />
                                </span>
                                {getFormErrorMessage('instance')}
                            </div>
                            <div className="field">
                                <label className={classNames({ 'p-error': isFormFieldValid('description') })}>Description</label>
                                <span className="p-float-label">
                                    <InputTextarea id="description" name="description" rows={5} cols={30}
                                        value={formik.values.description} onChange={formik.handleChange}
                                        className={classNames({ 'p-invalid': isFormFieldValid('description') })} placeholder="Enter your description" />
                                </span>
                                {getFormErrorMessage('description')}
                            </div>
                        </div>
                        <Button type="submit" label="Create" className="p-button-sm mt-2" />
                        <Button type="reset" label="Reset" className="p-button-sm p-button-secondary mt-2 ml-2" />
                    </form>
                </div>
            </div> */}
        </div>

    )
}
