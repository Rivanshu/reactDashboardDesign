import React from 'react'

function NoPermission() {
    return (
        <div>NoPermission</div>
    )
}

export default NoPermission