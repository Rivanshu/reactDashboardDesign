import React from 'react';
import { Card } from 'primereact/card';
import { classNames } from 'primereact/utils';

const jsonData = [
  {
    id: 1,
    title: 'Card 1',
    description: 'Description 1',
    image: 'path/to/image1.jpg',
  },
  {
    id: 2,
    title: 'Card 2',
    description: 'Description 2',
    image: 'path/to/image2.jpg',
  },
  {
    id: 3,
    title: 'Card 3',
    description: 'Description 3',
    image: 'path/to/image3.jpg',
  },
  {
    id: 4,
    title: 'Card 4',
    description: 'Description 4',
    image: 'path/to/image4.jpg',
  },
  // Add more JSON data as needed
];

const pipelineDashboard = () => {
  const renderCards = () => {
    return jsonData.map((data) => (
      <div key={data.id} className="p-col-12 p-md-6 p-lg-3">
        <Card className="card">
          <img
            src={data.image}
            alt={data.title}
            className="p-card-image"
          />
          <h3>{data.title}</h3>
          <p>{data.description}</p>
        </Card>
      </div>
    ));
  };

  const getCardClassName = () => {
    return classNames('p-grid', {
      'p-grid-cols-1': jsonData.length <= 1,
      'p-grid-cols-2': jsonData.length > 1 && jsonData.length <= 2,
      'p-grid-cols-3': jsonData.length > 2 && jsonData.length <= 3,
      'p-grid-cols-4': jsonData.length > 3 && jsonData.length <= 4,
    });
  };

  return <div className={getCardClassName()}>{renderCards()}</div>;
};

export default pipelineDashboard;