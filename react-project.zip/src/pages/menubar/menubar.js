import React from 'react';
import { Menu } from 'primereact/menu';
import { useNavigate, useLocation } from 'react-router-dom';
import './style.css';
import 'primereact/resources/themes/saga-blue/theme.css';
import 'primereact/resources/primereact.min.css';
import 'primeicons/primeicons.css';

function MenuBar() {
  const navigate = useNavigate();
  const location = useLocation();

  const isLoggedIn = location.pathname !== '/';

  const handleNavigate = (path) => {
    navigate(path);
  };
  const items = [
    {
      
      icon: 'pi pi-fw pi-th-large',
      command: () => handleNavigate('/dashboard'),
    },
   

    {
      icon: 'pi pi-file',
      command: () => handleNavigate('/create-new-pipeline'),
    },

    {
      icon: 'pi pi-fw pi-user-plus',
      command: () => handleNavigate('/usermaintenance'),
    },
    
    {
      icon: 'pi pi-image',
      command: () => handleNavigate('/source'),
    },
    // {
    //   icon: 'pi pi-file-export',
    //   command: () => handleNavigate('/destination'),
    // },
  ];

  return (
    <>
      {isLoggedIn && (
        <div className="custom-menu" style={{width:'60px'}} >
          <Menu style={{padding:'1px', backgroundColor:'white', border:'none'}} model={items.map(item => ({
            icon: item.icon,
            command: () => {
              item.command();
            },
            style: { height: '50px', marginTop:'10px', width: '50px', marginLeft:'6px' } // Adjust the values as needed
          }))} />
        </div>
      )}
    </>
  );
}

export default MenuBar;
