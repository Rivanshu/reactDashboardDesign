import Home from "./home/home";
import Login from "./user/login";
import Dashboard from './dashboard/dashboard';
import Pipeline from "./pipeline/pipeline";
import CreatePipeline from "./pipeline/create-pipeline";
import Help from './help/help';
import AddNew from "./addnew/addnew.js";
import UserMaintenance from "./usermaintenance/usermaintenance";
import PipelineDashboard from "./pipeline_Dashboard/pipeline_dashboard";

export {
    Home, Login, Dashboard, Pipeline, Help, CreatePipeline, UserMaintenance, AddNew, PipelineDashboard
}