import React, { useState, useEffect } from 'react';
import { DataView, DataViewLayoutOptions } from 'primereact/dataview';
import { Avatar } from 'primereact/avatar';
import "../style.scss";
import { Card } from 'primereact/card';
import { Button } from 'primereact/button';
import { fakeData } from '../../services';
import { useNavigate } from 'react-router-dom';
import 'primereact/resources/themes/saga-blue/theme.css';
import 'primereact/resources/primereact.min.css';
import 'primeicons/primeicons.css';
import sourceService from '../../services/source/sourceService';

import { ScrollTop } from 'primereact/scrolltop';
 

function Source({ formats, onSelection }) {
    const navigate = useNavigate();
    const [layout, setLayout] = useState('grid');
    const [file, setFile] = useState([]);

    useEffect(() => {
        // fetchData();
        getSourceFile();
    }, []);

    const fetchData = async () => {
        try {
            const response = await fetch('/assets/data/file.json'); // Valid path
            const jsonData = await response.json();
            setFile(jsonData);

        } catch (error) {
            console.error('Error fetching data:', error);
        }
    };

    const getSourceFile = () => {
        try {
            sourceService.getAllSource().then(resp => {
                if(resp.status == 200 ){
                    setFile(resp?.data?.data);
                }
            })
        } catch (error) {
            console.error('Error fetching data:', error);
        }
    };

    function StepItem({ number, text }) {
        return (
            <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
                <div style={{ display: 'flex', alignItems: 'center' }}>
                    <div style={{ width: '20px', height: '20px', borderRadius: '50%', backgroundColor: 'white', color: 'grey', display: 'flex', justifyContent: 'center', alignItems: 'center', marginRight: '10px', border: '1px solid grey' }}>
                        {number}
                    </div>
                    <p>{text}</p>
                </div>
            </div>
        );
    }

    const handleCheckboxClick = (file) => {
        navigate('/destination');
    };

    return (
        <div  style={{ backgroundColor:'whitesmoke', marginLeft: '20px', marginTop:'20px' }}>
            <div style={{ display: 'flex', marginLeft: '200px', alignItems: 'center', marginTop: '20px', gap: '100px' }}>
                <StepItem number="1" text="Configure Source" />
                <StepItem number="2" text="Step 2" />
                <StepItem number="3" text="Configure Destination" />
                <StepItem number="4" text="Final Settings" />
            </div>
            <div>
                {/* Top Section */}
                <div style={{ textAlign: 'center', marginTop: '20px' }}>
                    <h1><b style={{ fontSize: '15px' }}>Select your Source</b></h1>
                </div>
                <div style={{ textAlign: 'center', marginBottom: '30px' }}>
                    <p>
                        Select the source from the list to proceed
                        {/* <Button label="Create New" style={{ backgroundColor: '#007BFF', color: 'white', border: 'none', height: '25px', marginTop: '10px', marginLeft: '10px' }} /> */}
                    </p>
                </div>

                <div style={{ display: 'flex', alignItems: 'flex-start', marginBottom: '20px' }}>
                    <div style={{ marginLeft: '10px', width: '250px' }}>
                        <h2>All Sources</h2>
                        <p>Database and File Systems</p>
                        <p>Engineering and Analytics</p>
                        <p>Finance & Accounting Analytics</p>
                        <p>Product</p>
                    </div>

                    <div style={{ display: 'flex', flexWrap: 'wrap', justifyContent: 'flex-start', gap: '20px', marginLeft: '50px' }}>
                        {file.map((file) => (
                            <Card key={file.id} style={{ border: '1px ', borderRadius: '5px', width: '180px', height: '180px' }}>
                                <div style={{ display: 'flex', flexDirection: 'column', height: '50%', justifyContent: 'center' }}>
                                    <div style={{ display: 'flex', alignItems: 'flex-start'}}>
                                        <input type="checkbox" onClick={() => handleCheckboxClick(file)} />
                                    </div>
                                    <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center' }}>
                                        <img style={{ width: '80px', height: '80px', objectFit: 'contain', borderRadius: 'none' }} src={`/assets/images/file/${file.name}`} alt="File" className="avatar-img" />
                                    </div>
                                    <div style={{ textAlign: 'center', marginTop: '10px' }}>
                                        <span className="user-name">{file.description}</span>
                                    </div>
                                </div>
                            </Card>
                        ))}
                    </div>
                </div>
            </div>
        </div>
    );
}

export default Source;
