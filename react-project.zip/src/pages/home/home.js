import React from 'react';
import './style.css';

function Home() {
    return (
        <div className="welcomeLbl">
            <div className="welcome-secondary">
                Welcome to the
            </div>
            <div className="welcome-primary">
                Employee Self Service Portal
            </div>
        </div>
    )
}

export default Home