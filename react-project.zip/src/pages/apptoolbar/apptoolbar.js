import React, { useEffect } from 'react';
import { Button } from 'primereact/button';
import { Menubar } from 'primereact/menubar';
import { Menu } from 'primereact/menu';
import { useNavigate, useLocation } from 'react-router-dom';
import { Dropdown } from 'primereact/dropdown';
import { useState } from 'react';
import { Avatar } from 'primereact/avatar';
import loginService from '../../services/login/loginService';
import AddNewOrganization from '../addOrganization/addOrganization';
import 'primereact/resources/themes/saga-blue/theme.css';
import 'primereact/resources/primereact.min.css';
import 'primeicons/primeicons.css';

const AppToolbar = ({ onLogout, onProfileClick, onChangePasswordClick }) => {
  const navigate = useNavigate();
  const location = useLocation();
  const [user, setUser] = useState('')
  const [usertype, setUserType]=useState('')
  const isLoggedIn = location.pathname !== '/';
  useEffect(() => {
    setUser(localStorage.getItem('useremail'));
    setUserType(localStorage.getItem('userType'));
    setuserImage('user2.png')

  })
 
  const items = [
    {
      label: (
        <Dropdown
          model={[
            { label: 'Profile', icon: 'pi pi-user', command: onProfileClick },
            { label: 'Change Password', icon: 'pi pi-lock', command: onChangePasswordClick },
            { label: 'Logout', icon: 'pi pi-sign-out', command: onLogout },
          ]}
          appendTo={document.body}
        />
      ),
      escape: false,
      style: { padding: 0 },
    },
  ];

  const openOrgForm = () => {
    console.log("test")
    return (
      <div>
        <AddNewOrganization />
      </div>
    )
  }
  const [userimage, setuserImage] = useState('')


  const [menuVisible, setMenuVisible] = useState(false);
  const menuRef = React.createRef();

  const itemss = [

    {
      label: 'Add Organisation',
      icon: 'pi pi-fw pi-home',
      command: () => {
        openOrgForm();
        setMenuVisible(false);

      },
      visible: user === 'lavi'
    },
    {
      label: 'Add User',
      icon: 'pi pi-fw pi-cog',
      command: () => {
        // Handle option 2 click
        setMenuVisible(false);
      },
      visible: user === 'deebendu'
    }
  ];
  const checkUser=()=>{
    if (user==='lavi'){
      navigate('/adduser')
    }
    if (user==='deebendu'){
      navigate('/addorganisation')
    }
  }

  return (
    <>
      {isLoggedIn && (

        <div style={{ display: 'flex', borderBottom: "3px solid rgb(212, 212, 212)" }}>
          <div className='logo' style={{ width: '85%', backgroundColor: 'white' }}>
            <img onClick={() => navigate('/')} src='/assets/images/product-logo.png' style={{ height: '48px' }} />
          </div>
          <div style={{ width: '15%', marginLeft: '20px' }} className="p-toolbar-group-right p-d-flex p-flex-column p-jc-center p-ai-end">
         {usertype!='user' ? <div className="p-mt-2" style={{width:'20%'}}>
              <Button style={{color:'grey'}} icon="pi pi-cog" className="p-button-rounded p-button-text p-mr-2" onClick={(e) =>{checkUser()}
            } 
              />
              <Menu model={itemss} ref={menuRef} popup appendTo={document.body} onHide={() => setMenuVisible(false)} visible={menuVisible} />

            </div> : <></>}   
            <div style={{width:'50%', textAlign:'center', display:'inline'}} className="p-mt-2">
              <span style={{ marginLeft: '20px'}}> 
              <b >{user}</b> 
              <br/>
              <b style={{marginLeft:'20px', fontSize:'small'}}>{usertype}</b>
              </span>
              </div>
            <div style={{width:'30%', marginLeft:'10px'}} className="p-mt-2">
              <img style={{ height: '40px', width: '40px', marginLeft: '30px' }} src={`/assets/images/user/${userimage}`} alt="User" className="avatar" />
            </div>

          </div>
        </div>

      )}
    </>
  );
};

export default AppToolbar;
