import { Fragment, useState } from "react";
import { InputText } from 'primereact/inputtext';
import { Password } from 'primereact/password';
import { Checkbox } from 'primereact/checkbox';
import { Button } from 'primereact/button';
import { classNames } from 'primereact/utils';
import { useCookies } from 'react-cookie';
import { useDispatch } from 'react-redux';
import { useNavigate } from 'react-router';
import { toast } from 'react-toastify';
import { useFormik } from 'formik';
import { login, setRoles, setPermissions } from '../../services/store/userSlice';
import { AuthService } from "../../services";
import { fakeData } from "../../services";
import './style.scss';
import SSOLogin from "../../components/sso_login/sso_login";
import properties from "../../config/environmentProperties";
import { parseRolePermission } from '../../services/utility/helper';
import pkg from '../../../package.json';
// const pkg = require('../../../package.json');
const INIT_FORM_VAL = { tenant : null, email: null, password: null, accept: false }
const Login = ({ screen }) => {
    const navigate = useNavigate();
    const dispatch = useDispatch();
    const [showMessage, setShowMessage] = useState(false);
    const [formData, setFormData] = useState({});
    const [cookies, setCookie] = useCookies(['user']);
    const conf = properties.currentEnvironment;
    const formik = useFormik({
        initialValues: INIT_FORM_VAL,
        validate: (data) => {
            let errors = {};

            if (!data.tenant) {
                errors.tenant = 'tenant is required.';
            }
            if (!data.email) {
                errors.email = 'Email/Username is required.';
            }
            // else if (!/^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,4}$/i.test(data.email)) {
            //     errors.email = 'Invalid email address. E.g. example@email.com';
            // }

            if (!data.password) {
                errors.password = 'Password is required.';
            }
            return errors;
        },
        onSubmit: (data) => {
            setFormData(data);
            getLogin(data);
            setShowMessage(true);
            // formik.resetForm();
        }
    });

    const isFormFieldValid = (name) => !!(formik.touched[name] && formik.errors[name]);
    const getFormErrorMessage = (name) => {
        return isFormFieldValid(name) && <small className="p-error">{formik.errors[name]}</small>;
    };

    function save2Local(obj) {
        localStorage.setItem('userPrinciple', obj.user.email)
        localStorage.removeItem('inactive')
    }

    const getLogin = async (data) => {
        const payload = { ...data };
        payload.email = data.email.includes('@') ? data.email : data.email + '@espire.com';
        try {
            fakeData.fakeAuthService.login(payload).then(resp => {
                let userObj = resp.data;

                if (userObj.success) {
                    const { roles, permissions } = parseRolePermission(userObj.user.UserRoles);
                    userObj.user['roles'] = roles;
                    userObj.user['show_roles'] = roles;
                    userObj.user['permissions'] = permissions;
                    userObj.user['loggedIn'] = true;
                    delete (userObj.user['password']);
                    const info = null;
                    const result = { ...userObj, ...info }
                    dispatch(login(result));
                    dispatch(setRoles([...roles]));
                    dispatch(setPermissions(permissions));
                    save2Local(result);
                    navigate('/dashboard');
                } else {
                    toast.error("User not found...");
                }
            }, err => {
                const errResp = err.response.data;
                toast.error(errResp.error);
            })
        } catch (error) {
            console.log("error on calling api", error)
        }


    }

    const LoginWrapper = () => {
        return (
            <div className="login-wrapper">
                <div className="login-form">
                    <p>
                        <img className="logo" src="/public/assets/images/logo.png" />
                    </p>
                    {conf.enableSSO == "true" ? <><h1>Self Service Portal</h1><SSOLogin /></> : <>
                        <form onSubmit={formik.handleSubmit} className="p-fluid">
                            <h3>Welcome</h3>
                            <p>Enter your credentials to access your account</p>
                            <div className="field">
                                <label className={classNames({ 'p-error': isFormFieldValid('tenant') })}>tenant</label>
                                <span className="p-float-label p-input-icon-right">
                                    <i className="pi pi-user" />
                                    <InputText name="tenant" value={formik.values.tenant} onChange={formik.handleChange}
                                        className={classNames({ 'p-invalid': isFormFieldValid('tenant') })} placeholder="Enter tenant" />
                                </span>
                                {getFormErrorMessage('tenant')}
                            </div>
                            <div className="field">
                                <label className={classNames({ 'p-error': isFormFieldValid('email') })}>Email Address/Username</label>
                                <span className="p-float-label p-input-icon-right">
                                    <i className="pi pi-envelope" />
                                    <InputText name="email" value={formik.values.email} onChange={formik.handleChange}
                                        className={classNames({ 'p-invalid': isFormFieldValid('email') })} placeholder="Enter your email address/username" />
                                </span>
                                {getFormErrorMessage('email')}
                            </div>
                            <div className="field">
                                <label className={classNames({ 'p-error': isFormFieldValid('password') })}>Password</label>
                                <span className="p-float-label">
                                    <Password name="password" value={formik.values.password} onChange={formik.handleChange} toggleMask feedback={false}
                                        className={classNames({ 'p-invalid': isFormFieldValid('password') })} placeholder="Enter your password" />
                                </span>
                                {getFormErrorMessage('password')}
                            </div>

                            <div className="field-checkbox">
                                <Checkbox inputId="accept" name="accept" checked={formik.values.accept} onChange={formik.handleChange} className={classNames({ 'p-invalid': isFormFieldValid('accept') })} />
                                <label htmlFor="accept" className={classNames({ 'p-error': isFormFieldValid('accept') })}>Remember me</label>
                            </div>

                            <Button type="submit" label="Login" className="mt-2" />
                        </form>
                    </>}

                </div>
                <p><small style={{ textTransform: 'uppercase' }}>{pkg.framework} V {pkg.version}</small></p>


            </div>
        )
    }

    return (
        <div className="grid full-screen lg-screen">
            <div className="col-6 banner">
                <div className="image"></div>
                <h1>EUniCA Portal</h1>
                <p>
                    <em>
                        <small style={{ textTransform: 'uppercase' }}>{pkg.framework} V {pkg.version}</small>
                    </em>
                    <small>@2023, Espire Infolab Pvt. Ltd. All Rights Reserved</small>
                </p>
            </div>
            <div className="col-6 login-area">
                {LoginWrapper()}
            </div>
        </div>
    )
}

export default Login;