import { Fragment, useState } from "react";
import { InputText } from 'primereact/inputtext';
import { Password } from 'primereact/password';
import { Checkbox } from 'primereact/checkbox';
import { Button } from 'primereact/button';
import { classNames } from 'primereact/utils';
import { useFormik } from 'formik';
import './style.scss';

const Reset = ({ screen }) => {
    const [showMessage, setShowMessage] = useState(false);
    const [formData, setFormData] = useState({});

    const formik = useFormik({
        initialValues: {
            email: null,
        },
        validate: (data) => {
            let errors = {};

            if (!data.email) {
                errors.email = 'Email is required.';
            }
            else if (!/^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,4}$/i.test(data.email)) {
                errors.email = 'Invalid email address. E.g. example@email.com';
            }

            return errors;
        },
        onSubmit: (data) => {
            setFormData(data);
            setShowMessage(true);
            formik.resetForm();
        }
    });

    const isFormFieldValid = (name) => !!(formik.touched[name] && formik.errors[name]);
    const getFormErrorMessage = (name) => {
        return isFormFieldValid(name) && <small className="p-error">{formik.errors[name]}</small>;
    };


    return (
        <Fragment>
            <div className="login-wrapper">
                <img className="logo" src="/assets/images/logo.png" />
                <div className="login-form">
                    <form onSubmit={formik.handleSubmit} className="p-fluid">
                        <h3>Reset Password</h3>
                        <div className="field">
                            <label className={classNames({ 'p-error': isFormFieldValid('email') })}>Email Address</label>
                            <span className="p-float-label p-input-icon-right">
                                <i className="pi pi-envelope" />
                                <InputText id="email" name="email" value={formik.values.email} onChange={formik.handleChange}
                                    className={classNames({ 'p-invalid': isFormFieldValid('email') })} placeholder="Enter your email address" />
                            </span>
                            {getFormErrorMessage('email')}
                        </div>

                        <Button type="submit" label="Submit" className="mt-2" />
                    </form>
                </div>

            </div>
        </Fragment>

    )
}

export default Reset;